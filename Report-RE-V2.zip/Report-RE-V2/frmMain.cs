﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Report_RE_V2
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void canadaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCanada frm = new frmCanada();
            frm.MdiParent = this;

            frm.Show();
        }

        private void adminToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Admin.frmAdmin frm = new Admin.frmAdmin();
            frm.MdiParent = this;

            frm.Show();
            frm.WindowState = FormWindowState.Maximized;
        }
    }
}
