﻿using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Report_RE_V2.Admin
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }
        public class AdminRateModel
        {

            public string connectionid;
            public string machinename;
            public string channel;
            public string eventname;
            public string firstime;
            public int as_of_yr;
            public int as_of_mm;
            public string encrk;
        }
        private void button1_Click(object sender, EventArgs e)
        {

            //Client selection
            using (StreamReader r = new StreamReader("../../Json/Admin.json"))
            {
                string json = r.ReadToEnd();
                List<AdminRateModel> items = JsonConvert.DeserializeObject<List<AdminRateModel>>(json);
                foreach (AdminRateModel item in items)
                {
                    richTextBox1.Clear();
                    GenerateReport(item.machinename, item.channel, item.eventname, item.firstime, item.as_of_yr, item.as_of_mm, item.connectionid, item.encrk);
                }
            }
        }
        //Web api
        public List<string> GenerateReport(string machinename, string channel, string eventname, string firstime, int as_of_yr, int as_of_mm, string signalr, string encrk)
        {

            var Encr = new EncryptStrings_admin.StringCipher_admin();
            var DL = new DataLoads_admin();

            string innerconnection = Encr.Decrypt(ConfigurationManager.ConnectionStrings["O_1"].ConnectionString, encrk);
            string hrliterconnection = Encr.Decrypt(ConfigurationManager.ConnectionStrings["O_LR"].ConnectionString, encrk);

            List<string> ReturnArray = new List<string>();

            string locationfolder = Application.StartupPath + "/excel";// HttpContext.Current.Server.MapPath("~/excel");

            string exchange = "";
            switch (eventname.ToLower().Trim())
            {
                case "rates_progression":
                    DL.ProcessRatesProgression(signalr, machinename, channel, eventname, firstime, as_of_yr, as_of_mm, innerconnection, hrliterconnection);
                    break;
            }

            return ReturnArray;
        }
        class DataLoads_admin
        {
            public void ProcessRatesProgression(string connectionid, string machinename, string channel, string eventname, string firstime, int as_of_yr, int as_of_mm,
             string innerconnection, string hrliterconnection)
            {

                var OSPS = new OracleStoredProceduresServices_admin();
                var SRSD = new SignalRSendData_admin();

                DateTime dtlt = DateTime.Now;
                string uniquid = dtlt.Day.ToString() + dtlt.Hour.ToString() + dtlt.Minute.ToString() + dtlt.Second.ToString();

                SRSD.sendInfoToClient(connectionid, channel, eventname, "loading rates started", 0);
                return;
                int monthsback = 5;
                DateTime de = DateTime.Now;
                DateTime dt = new DateTime(as_of_yr, as_of_mm, 1).AddMonths(1);

                ExcelServicesModels_admin.PreloadedIDsInfoProcess_admin v = new ExcelServicesModels_admin.PreloadedIDsInfoProcess_admin();
                int totals = 0;
                int processed = 0;
                int issues = 0;
                int nodata = 0;

                string dtstrend = ("00" + dt.Month).Substring(("00" + dt.Month).Length - 2) + "/" + ("00" + dt.Day).Substring(("00" + dt.Day).Length - 2) + "/" + dt.Year;

                string sqlPull = "";
                string tableresults = machinename + "RES";
                string tableprocessed = machinename + "PS";
                int tablecounter = 0;
                string sql = "";

                if (firstime.ToLower() == "yes")
                {
                    OSPS.RemoveTableViewTrailingServer(tableprocessed, innerconnection);
                    sql = @"CREATE TABLE " + tableresults + @"     
                                                    ( 
                                                        T2_PEO_ID NVARCHAR2(10), 
                                                        COMPANY NVARCHAR2(10), 
                                                        CLIENTID NVARCHAR2(10), 
                                                        TIMEFRAME NVARCHAR2(7), 
                                                        TIMEFRAME2 DATE, 
                                                        STATE NVARCHAR2(10), 
                                                        WORKERS_COMP_CD NVARCHAR2(10), 
                                                        PF_COST_RATE_ID NVARCHAR2(50), 
                                                        T2_WC_DISCOUNT NUMBER(28,10), 
                                                        T2_WC_MODIFIER NUMBER(28,10), 
                                                        PF_RATE NUMBER(28,10), 
                                                        BILL_RATE_CALCULATED NUMBER(28,10), 
                                                        COST_RATE NUMBER(28,10), 
                                                        MANUAL_RATE NUMBER(28,10), 
                                                        PF_RATE_CHANGED NVARCHAR2(3), 
                                                        T2_WC_DISCOUNT_CHANGED NVARCHAR2(3), 
                                                        T2_WC_MODIFIER_CHANGED NVARCHAR2(3), 
                                                        COST_RATE_CHANGED NVARCHAR2(3), 
                                                        MANUAL_RATE_CHANGED NVARCHAR2(3)
                                                    )";
                    OSPS.ExecuteSQL(sql, innerconnection);
                    sql = @"CREATE TABLE " + tableprocessed + @"     
                                                    ( 
                                                        COID NVARCHAR2(10), 
                                                        PROCESSED NVARCHAR2(20)
                                                    )";
                    OSPS.ExecuteSQL(sql, innerconnection);
                }
                else
                {
                    tablecounter = Int32.Parse(OSPS.getDataString("SELECT count(OBJECT_NAME) as x FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE') AND OWNER = 'RISK_ANALYTICS' AND TRIM(UPPER(OBJECT_NAME))  = '" + tableresults.ToUpper() + "'", innerconnection));
                    if (tablecounter == 0)
                    {
                        sql = @"CREATE TABLE " + tableresults + @"     
                                                    ( 
                                                        T2_PEO_ID NVARCHAR2(10), 
                                                        COMPANY NVARCHAR2(10), 
                                                        CLIENTID NVARCHAR2(10), 
                                                        TIMEFRAME NVARCHAR2(7), 
                                                        TIMEFRAME2 DATE, 
                                                        STATE NVARCHAR2(10), 
                                                        WORKERS_COMP_CD NVARCHAR2(10), 
                                                        PF_COST_RATE_ID NVARCHAR2(50), 
                                                        T2_WC_DISCOUNT NUMBER(28,10), 
                                                        T2_WC_MODIFIER NUMBER(28,10), 
                                                        PF_RATE NUMBER(28,10), 
                                                        BILL_RATE_CALCULATED NUMBER(28,10), 
                                                        COST_RATE NUMBER(28,10), 
                                                        MANUAL_RATE NUMBER(28,10), 
                                                        PF_RATE_CHANGED NVARCHAR2(3), 
                                                        T2_WC_DISCOUNT_CHANGED NVARCHAR2(3), 
                                                        T2_WC_MODIFIER_CHANGED NVARCHAR2(3), 
                                                        COST_RATE_CHANGED NVARCHAR2(3), 
                                                        MANUAL_RATE_CHANGED NVARCHAR2(3)
                                                    )";
                        OSPS.ExecuteSQL(sql, innerconnection);
                    }
                    tablecounter = Int32.Parse(OSPS.getDataString("SELECT count(OBJECT_NAME) as x  FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE') AND OWNER = 'RISK_ANALYTICS' AND TRIM(UPPER(OBJECT_NAME))  = '" + tableprocessed.ToUpper() + "'", innerconnection));
                    if (tablecounter == 0)
                    {
                        sql = @"CREATE TABLE " + tableprocessed + @"     
                                                    ( 
                                                        COID NVARCHAR2(10), 
                                                        PROCESSED NVARCHAR2(20)
                                                    )";
                        OSPS.ExecuteSQL(sql, innerconnection);
                    }
                }

                DataTable dtAdd;
                if (firstime.ToLower() == "yes")
                {
                    var ESM = new ExcelServicesModels_admin();
                    sql = "select distinct fff.COID, 'xxxxxxxxxx' as PROCESSED from (" + ESM.Get_SQL_All_Clients(dtstrend) + ") fff where fff.TERMDT is null or fff.TERMDT >= ADD_MONTHS(SYSDATE,-" + monthsback + ")";
                    dtAdd = OSPS.getDataTable(sql, hrliterconnection);

                    totals = dtAdd.Rows.Count;
                    tablecounter = Int32.Parse(OSPS.getDataString("select count(coid) from " + tableprocessed.ToUpper(), innerconnection));
                    if (tablecounter == 0)
                    {
                        OSPS.PutDataTableWithArrayToDb(ref dtAdd, innerconnection, false, tableprocessed, 0, "test");

                    }
                }
                else
                {
                    totals = Int32.Parse(OSPS.getDataString("select count(coid) from " + tableprocessed.ToUpper() + " where PROCESSED not in ('Y')", innerconnection));
                }

                SRSD.sendInfoToClient(connectionid, channel, eventname, "pulling clients to process -" + totals, 1);

                //////////////////////////// Parrallel pull of the data first circle
                sql = "select distinct COID from " + tableprocessed + " where PROCESSED not in ('Y')";
                DataTable temptableratesids = OSPS.getDataTable(sql, innerconnection);

                totals = temptableratesids.Rows.Count;
                List<string> list = temptableratesids.AsEnumerable().Select<DataRow, string>((Func<DataRow, string>)(r => r.Field<string>("COID"))).ToList<string>();

                SRSD.sendInfoToClient(connectionid, channel, eventname, "Entering first pull to process - " + totals, 2);

                try
                {
                    Parallel.ForEach(list, new ParallelOptions { MaxDegreeOfParallelism = 8 },
                        id =>
                        {
                            sqlPull = v.get_Final_ID_Data_SQL_RatesChange_Pull(id, dtstrend, monthsback);

                            DataTable dtAdd2 = OSPS.getDataTable(sqlPull, hrliterconnection);

                            if (dtAdd2.Rows.Count > 0)
                            {
                                if (OSPS.PutDataTableWithArrayToDb(ref dtAdd2, innerconnection, false, tableresults, 0, "test") == "t")
                                {
                                    string sqlProcessed = "update (select PROCESSED from " + tableprocessed + " where COID in ('" + id + @"')) set PROCESSED = 'Y'";
                                    OSPS.ExecuteSQL(sqlProcessed, innerconnection);
                                    processed += 1;
                                }
                                else
                                {
                                    string sqlProcessed = "update (select PROCESSED from " + tableprocessed + " where COID in ('" + id + @"')) set PROCESSED = 'ISSUE'";
                                    OSPS.ExecuteSQL(sqlProcessed, innerconnection);
                                    issues += 1;
                                }

                            }
                            else
                            {
                                string sqlProcessed = "update (select PROCESSED from " + tableprocessed + " where COID in ('" + id + @"')) set PROCESSED = 'NO DATA'";
                                OSPS.ExecuteSQL(sqlProcessed, innerconnection);
                                nodata += 1;
                            }
                            SRSD.sendInfoToClient(connectionid, channel, eventname, "Processed clients - " + processed + " out of " + totals + "; Clients with isssues -" + issues + "; Clients with no data - " + nodata, 3);
                        }
                        );

                    //////////////////////////// Parrallel pull of the data second circle
                    sql = "select distinct COID from " + tableprocessed + " where PROCESSED not in ('Y')";
                    temptableratesids = OSPS.getDataTable(sql, innerconnection);
                    list = temptableratesids.AsEnumerable().Select<DataRow, string>((Func<DataRow, string>)(r => r.Field<string>("COID"))).ToList<string>();

                    SRSD.sendInfoToClient(connectionid, channel, eventname, "Entering second pull to process - " + totals, 2);
                    try
                    {
                        Parallel.ForEach(list, new ParallelOptions { MaxDegreeOfParallelism = 8 }, id =>
                        {
                            sqlPull = v.get_Final_ID_Data_SQL_RatesChange_Pull(id, dtstrend, monthsback);
                            DataTable dtAdd2 = OSPS.getDataTable(sqlPull, hrliterconnection);
                            if (dtAdd2.Rows.Count > 0)
                            {
                                if (OSPS.PutDataTableWithArrayToDb(ref dtAdd2, innerconnection, false, tableresults, 0, "test") == "t")
                                {
                                    string sqlProcessed = "update (select PROCESSED from " + tableprocessed + " where COID in ('" + id + @"')) set PROCESSED = 'Y'";
                                    OSPS.ExecuteSQL(sqlProcessed, innerconnection);
                                    processed += 1;
                                }
                                else
                                {
                                    string sqlProcessed = "update (select PROCESSED from " + tableprocessed + " where COID in ('" + id + @"')) set PROCESSED = 'ISSUE'";
                                    OSPS.ExecuteSQL(sqlProcessed, innerconnection);
                                    issues += 1;
                                }
                            }
                            else
                            {
                                string sqlProcessed = "update (select PROCESSED from " + tableprocessed + " where COID in ('" + id + @"')) set PROCESSED = 'NO DATA'";
                                OSPS.ExecuteSQL(sqlProcessed, innerconnection);
                                nodata += 1;
                            }
                            SRSD.sendInfoToClient(connectionid, channel, eventname, "Processed clients - " + processed + " out of " + totals + "; Clients with isssues - " + issues + "; Clients with no data - " + nodata, 3);
                        });
                        //////////////////////////// Final circle executing stored procedure
                        try
                        {
                            SRSD.sendInfoToClient(connectionid, channel, eventname, "Executing stored procedure for Rates - named WEB_LOAD_DATA_RATES_PROGRESS", 1);
                            string r = OSPS.CallStoredProcedureForAdminDataLoads("WEB_LOAD_DATA_RATES_PROGRESS", innerconnection, machinename, tableresults, "", as_of_yr, as_of_mm, monthsback);
                            /////////////// Checking stored procedure if executed properly
                            if (r == "t")
                            {
                                SRSD.sendInfoToClient(connectionid, channel, eventname, "All exchanges rates progress data was loaded correctly", 2);
                            }
                            else
                            {
                                SRSD.sendInfoToClient(connectionid, channel, eventname, "ISSUE - Execution of Stored procedure WEB_LOAD_DATA_RATES_PROGRESS", 2);
                            }
                        }
                        catch (AggregateException e)
                        {
                            foreach (var ex in e.InnerExceptions)
                            {
                                //// ////// //Trace.WriteLine("!!!!!!!!!!!!!!!!!!!!!!!!!! ERRORS !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                //// ////// //Trace.WriteLine(ex.Message);
                                SRSD.sendInfoToClient(connectionid, channel, eventname, ex.Message, 4);

                            }
                        }
                    }
                    catch (AggregateException e)
                    {
                        foreach (var ex in e.InnerExceptions)
                        {
                            //// ////// //Trace.WriteLine("!!!!!!!!!!!!!!!!!!!!!!!!!! ERRORS !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            //// ////// //Trace.WriteLine(ex.Message);
                            SRSD.sendInfoToClient(connectionid, channel, eventname, ex.Message, 4);

                        }
                    }
                }
                catch (AggregateException e)
                {
                    foreach (var ex in e.InnerExceptions)
                    {
                        //// ////// //Trace.WriteLine("!!!!!!!!!!!!!!!!!!!!!!!!!! ERRORS !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        //// ////// //Trace.WriteLine(ex.Message);
                        SRSD.sendInfoToClient(connectionid, channel, eventname, ex.Message, 5);

                    }
                }
            }
        }
        public class EncryptStrings_admin
        {
            public class StringCipher_admin
            {
                public string Decrypt(string con, string encrk)
                {
                    return "decrypt";
                }

            }
        }
        public class OracleStoredProceduresServices_admin
        {
            private int tryings = 10;
            private int sleeptime = 3000;
            public string RemoveTableViewTrailingServer(string tableview, string c)
            {
                ////// // ////// //Trace.WriteLine("Inside RemoveTemporaryObjectsTV call");
                int trynow = 0;
                string ReturnInfo = "f";
                OracleConnection Conn = new OracleConnection(c);
                OracleCommand OraCommand = Conn.CreateCommand();
                OraCommand.CommandText = "RemoveTemporaryObjectsTV";
                OraCommand.CommandType = CommandType.StoredProcedure;

                OracleParameter TV = new OracleParameter();
                TV.ParameterName = "TV";
                TV.OracleDbType = OracleDbType.Varchar2;
                TV.Direction = ParameterDirection.Input;
                TV.Value = tableview;
                OraCommand.Parameters.Add(TV);
            label:
                trynow++;
                try
                {
                    Conn.Open();
                    OraCommand.ExecuteNonQuery();
                    ReturnInfo = "t";
                    ////////// // ////// //Trace.WriteLine("Done Deleting");
                    Conn.Close();
                    Conn.Dispose();
                }
                catch (Exception ex)
                {
                    Conn.Close();
                    //////////// // ////// //Trace.WriteLine(ex.Message);
                    if (trynow < tryings)
                    {
                        Thread.Sleep(sleeptime);
                        goto label;
                    }
                    else
                    {
                        return ex.Message;
                    }
                }
                return ReturnInfo;

            }
            public string ExecuteSQL(string sql, string c)
            {
                int trynow = 0;
                string ReturnInfo = "f";
                OracleConnection Conn = new OracleConnection(c);
                OracleCommand OraCommand = Conn.CreateCommand();
                OraCommand.CommandText = "EXECUTESQL";
                OraCommand.CommandType = CommandType.StoredProcedure;

                OracleParameter strSQL = new OracleParameter();
                strSQL.ParameterName = "strSQL";
                strSQL.OracleDbType = OracleDbType.Varchar2;
                strSQL.Direction = ParameterDirection.Input;
                strSQL.Value = sql;
                OraCommand.Parameters.Add(strSQL);
            label:
                trynow++;
                try
                {
                    Conn.Open();
                    OraCommand.ExecuteNonQuery();
                    ReturnInfo = "t";
                    Conn.Close();
                    Conn.Dispose();
                }
                catch (Exception ex)
                {
                    Conn.Close();
                    if (trynow < tryings)
                    {
                        Thread.Sleep(sleeptime);
                        goto label;
                    }
                    else
                    {
                        ////// // ////// //Trace.WriteLine(ex.Message);
                        return ex.Message;
                    }
                }
                return ReturnInfo;
            }
            public DataTable getDataTable(string ss, string c)
            {
                int trynow = 0;
                DataTable dt = new DataTable();
                string SQLstr = ss;
                using (OracleConnection Conn = new OracleConnection(c))
                {
                    OracleConnection.ClearAllPools();
                    using (OracleCommand OraCommand = new OracleCommand(SQLstr, Conn))
                    {
                    //DataSet ds = new DataSet();
                    label:
                        trynow++;
                        try
                        {

                            Conn.Open();
                            OracleDataAdapter OraAdapter = new OracleDataAdapter(SQLstr, Conn);
                            OraAdapter.Fill(dt);
                            Conn.Close();
                            Conn.Dispose();
                            OraAdapter.Dispose();
                            //dt = ds.Tables[0];
                            ////// // ////// //Trace.WriteLine("Data pulled " + SQLstr);
                        }
                        catch (Exception ex)
                        {
                            Conn.Close();
                            ////// // ////// //Trace.WriteLine("Data issue " + SQLstr);
                            ////// // ////// //Trace.WriteLine("Data issue here " + ex.Message);
                            if (trynow < tryings)
                            {
                                Thread.Sleep(sleeptime);
                                goto label;
                            }
                            else
                            {
                                DataTable dataTable2 = new DataTable("returnInfo");
                                dataTable2.Columns.Add(new DataColumn()
                                {
                                    DataType = Type.GetType("System.String"),
                                    ColumnName = "returnInfo",
                                    AutoIncrement = false,
                                    Caption = "returnInfo",
                                    ReadOnly = false,
                                    Unique = false
                                });
                                DataRow row = dataTable2.NewRow();
                                row["returnInfo"] = ex.Message;
                                dataTable2.Rows.Add(row);
                                return dataTable2;
                            }
                        }
                    }
                }
                return dt;
            }
            public string getDataString(string sql, string c)
            {
                int trynow = 0;
                string r = "";
                OracleConnection Conn = new OracleConnection(c);
                OracleCommand OraCommand = Conn.CreateCommand();
                OraCommand.CommandText = sql;
                OraCommand.CommandType = CommandType.Text;
            label:
                trynow++;
                try
                {
                    Conn.Open();
                    r = Convert.ToString(OraCommand.ExecuteScalar());
                    Conn.Close();
                    Conn.Dispose();
                }
                catch (Exception ex)
                {
                    Conn.Close();
                    if (trynow < tryings)
                    {
                        Thread.Sleep(sleeptime);
                        goto label;
                    }
                    else
                    {
                        //////// // ////// //Trace.WriteLine(ex.Message);
                        return ex.Message;
                    }
                }
                return r;
            }
            public string PutDataTableWithArrayToDb(ref DataTable dt, string c, Boolean init, string TableName, int processcount, string sql)
            {
                //////string dumpfile = HttpContext.Current.Server.MapPath("~/ManagedFiles") + "/" + TableName + ".txt";
                //////////////// // ////// //Trace.WriteLine(dumpfile);
                //////CustomExcel.DeleteExcelFile(dumpfile);
                int trynow = 0;
                int multiplicator = 1;
                ///////// recreate table here
                ////////////////// // ////// //Trace.WriteLine("????????????????????????????????????");
                if (init == true)
                {
                    //////////////// // ////// //Trace.WriteLine("OKOKOKOKOKO");
                    return CreateDataTableInServer(ref dt, c, TableName);
                }
                else
                {
                //////////////// // ////// //Trace.WriteLine("!!!!!!!");
                label:
                    trynow++;
                    if (dt.Rows.Count > 0)
                    {
                        // create and open connection object
                        OracleConnection Conn = new OracleConnection(c);
                        Conn.Close();
                        Conn.Open();
                        try
                        {

                            ////http://www.oracle.com/technetwork/issue-archive/2009/09-sep/o59odpnet-085168.html
                            OracleCommand cmd = Conn.CreateCommand();
                            //////// Dictionary<string, dynamic> d = new Dictionary<string, dynamic>();
                            int arr_counter = 0;
                            string sql_command = "INSERT /*+ NOLOGGING PARALLEL(p,21) */ INTO " + TableName + " p (";
                            string temp_sql_command_coloumns = "";
                            string temp_sql_command_arraies = " VALUES (";
                            foreach (DataColumn col in dt.Columns)
                            {
                                arr_counter++;
                                OracleParameter orac_p = new OracleParameter();
                                temp_sql_command_coloumns = temp_sql_command_coloumns + "\"" + col.ColumnName.ToString() + "\"" + ",";
                                temp_sql_command_arraies = temp_sql_command_arraies + ":" + arr_counter + ", ";
                                // //////////////// // ////// //Trace.WriteLine(col.DataType.FullName.ToString().ToUpper());
                                //string[] stringTest = dt.AsEnumerable().Select(r => r.Field<string>(col.ColumnName.ToString())).ToArray();
                                switch (col.DataType.FullName.ToString().ToUpper())
                                {
                                    case "SYSTEM.STRING":
                                        string[] stringArrStr = dt.AsEnumerable().Select(r => r.Field<string>(col.ColumnName.ToString())).ToArray();
                                        // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrStr, Formatting.Indented));
                                        orac_p.OracleDbType = OracleDbType.Varchar2;
                                        orac_p.Value = stringArrStr;
                                        if (arr_counter == 1)
                                        {
                                            cmd.ArrayBindCount = stringArrStr.Length;
                                        }
                                        break;
                                    case "SYSTEM.DATETIME":
                                        DateTime?[] stringArrDateTime = dt.AsEnumerable().Select(r => r.Field<DateTime?>(col.ColumnName.ToString())).ToArray();
                                        orac_p.OracleDbType = OracleDbType.Date;
                                        orac_p.Value = stringArrDateTime;
                                        // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrDateTime, Formatting.Indented));
                                        if (arr_counter == 1)
                                        {
                                            cmd.ArrayBindCount = stringArrDateTime.Length;
                                        }
                                        break;
                                    case "SYSTEM.INT16":
                                        Int16?[] stringArrInt16 = dt.AsEnumerable().Select(r => r.Field<Int16?>(col.ColumnName.ToString())).ToArray();
                                        orac_p.OracleDbType = OracleDbType.Int16;
                                        orac_p.Value = stringArrInt16;
                                        if (arr_counter == 1)
                                        {
                                            cmd.ArrayBindCount = stringArrInt16.Length;
                                        }
                                        break;
                                    case "SYSTEM.INT32":
                                        Int32?[] stringArrInt32 = dt.AsEnumerable().Select(r => r.Field<Int32?>(col.ColumnName.ToString())).ToArray();
                                        orac_p.OracleDbType = OracleDbType.Int32;
                                        orac_p.Value = stringArrInt32;
                                        // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrInt32, Formatting.Indented));
                                        if (arr_counter == 1)
                                        {
                                            cmd.ArrayBindCount = stringArrInt32.Length;
                                        }
                                        break;
                                    case "SYSTEM.INT64":
                                        Int64?[] stringArrInt64 = dt.AsEnumerable().Select(r => r.Field<Int64?>(col.ColumnName.ToString())).ToArray();
                                        orac_p.OracleDbType = OracleDbType.Int64;
                                        orac_p.Value = stringArrInt64;
                                        // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrInt64, Formatting.Indented));
                                        if (arr_counter == 1)
                                        {
                                            cmd.ArrayBindCount = stringArrInt64.Length;
                                        }
                                        break;
                                    case "SYSTEM.DOUBLE":
                                        Double?[] stringArrDouble = dt.AsEnumerable().Select(r => r.Field<Double?>(col.ColumnName.ToString())).ToArray();
                                        orac_p.OracleDbType = OracleDbType.Double;
                                        orac_p.Value = stringArrDouble;
                                        // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrDouble, Formatting.Indented));
                                        if (arr_counter == 1)
                                        {
                                            cmd.ArrayBindCount = stringArrDouble.Length;
                                        }
                                        break;
                                    case "SYSTEM.DECIMAL":
                                        Decimal?[] stringArrDecimal = dt.AsEnumerable().Select(r => r.Field<Decimal?>(col.ColumnName.ToString())).ToArray();
                                        orac_p.OracleDbType = OracleDbType.Decimal;
                                        orac_p.Value = stringArrDecimal;
                                        // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrDecimal, Formatting.Indented));
                                        if (arr_counter == 1)
                                        {
                                            cmd.ArrayBindCount = stringArrDecimal.Length;
                                        }
                                        break;
                                    case "SYSTEM.SINGLE":
                                        Single?[] stringArrSingle = dt.AsEnumerable().Select(r => r.Field<Single?>(col.ColumnName.ToString())).ToArray();
                                        orac_p.OracleDbType = OracleDbType.Decimal;
                                        orac_p.Value = stringArrSingle;
                                        ////////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrSingle, Formatting.Indented));
                                        if (arr_counter == 1)
                                        {
                                            cmd.ArrayBindCount = stringArrSingle.Length;
                                        }
                                        break;
                                    default:
                                        string[] stringArrStrDef = dt.AsEnumerable().Select(r => r.Field<string>(col.ColumnName.ToString())).ToArray();
                                        orac_p.OracleDbType = OracleDbType.Varchar2;
                                        orac_p.Value = stringArrStrDef;
                                        // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrStrDef, Formatting.Indented));
                                        if (arr_counter == 1)
                                        {
                                            cmd.ArrayBindCount = stringArrStrDef.Length;
                                        }
                                        break;
                                }
                                cmd.Parameters.Add(orac_p);
                            }
                            sql_command = sql_command + temp_sql_command_coloumns;
                            sql_command = sql_command.Substring(0, sql_command.Length - 1) + ")";
                            sql_command = sql_command + temp_sql_command_arraies;
                            sql_command = sql_command.Substring(0, sql_command.Length - 2) + ")";
                            cmd.CommandText = sql_command;
                            cmd.ExecuteNonQuery();
                            cmd.Dispose();
                            Conn.Close();
                            Conn.Dispose();
                            return "t";
                        }
                        catch (Exception ex)
                        {
                            if (trynow < (tryings * multiplicator))
                            {
                                goto label;
                            }
                            else
                            {
                                // //Trace.WriteLine(ex.Message);
                                // //Trace.WriteLine("------" + trynow + " Retrial --------");
                                // //Trace.WriteLine(sql);
                                Conn.Close();
                                Conn.Dispose();
                                return ex.Message;
                            }
                        }
                    }
                    return "done";
                }
            }
            public string CreateDataTableInServer(ref DataTable dt, string c, string TableName)
            {
                ////////// // ////// //Trace.WriteLine("!!!!!!!!!!!!!!!!!!!!!!!!!!! INSIDE");
                int trynow = 0;
                string ReturnInfo = "f";
                string procedureStr = "CREATETABLEFROMMIDLAYER";
                string tablename = TableName;
                string options = "";
                foreach (DataColumn col in dt.Columns)
                {
                    options = options + col.ColumnName.ToString() + ":" + col.DataType.FullName.ToString() + "|";
                }
                //Trace.WriteLine(options);
                options = options.Trim().TrimEnd();
                OracleConnection Conn = new OracleConnection(c);
                OracleCommand OraCommand = Conn.CreateCommand();
                OraCommand.CommandText = procedureStr;
                OraCommand.CommandType = CommandType.StoredProcedure;
                OraCommand.Parameters.Add(new OracleParameter("tablename", OracleDbType.Varchar2)).Value = tablename;
                OraCommand.Parameters.Add(new OracleParameter("options", OracleDbType.Varchar2)).Value = options;
            label:
                trynow++;
                try
                {
                    Conn.Open();
                    //Trace.WriteLine("Table creation started ");
                    OraCommand.ExecuteNonQuery();
                    ReturnInfo = "t";
                    //Trace.WriteLine("Table created");
                    Conn.Close();
                    Conn.Dispose();
                }
                catch (Exception ex)
                {
                    //Trace.WriteLine(ex.Message);
                    //Trace.WriteLine(ex.Source);
                    //Trace.WriteLine(ex.HelpLink);
                    Conn.Close();
                    if (trynow < tryings)
                    {
                        Thread.Sleep(sleeptime);
                        goto label;
                    }
                    else
                    {
                        return ex.Message;
                    }
                }
                return ReturnInfo;
            }
            public string CallStoredProcedureForAdminDataLoads(string proc, string innternallink, string username, string tablesource, string shortfilename, int asofyr, int asofmm, int monthsdiff)
            {
                int trynow = 0;
                string ReturnInfo = "f";
                OracleConnection Conn = new OracleConnection(innternallink);
                OracleCommand OraCommand = Conn.CreateCommand();
                OraCommand.CommandText = proc;
                OraCommand.CommandType = CommandType.StoredProcedure;

                OracleParameter paramusername = new OracleParameter();
                paramusername.ParameterName = "username";
                paramusername.OracleDbType = OracleDbType.Varchar2;
                paramusername.Direction = ParameterDirection.Input;
                paramusername.Value = username;
                OraCommand.Parameters.Add(paramusername);

                OracleParameter paramtablesource = new OracleParameter();
                paramtablesource.ParameterName = "tablesource";
                paramtablesource.OracleDbType = OracleDbType.Varchar2;
                paramtablesource.Direction = ParameterDirection.Input;
                paramtablesource.Value = tablesource;
                OraCommand.Parameters.Add(paramtablesource);

                OracleParameter paramshortfilename = new OracleParameter();
                paramshortfilename.ParameterName = "shortfilename";
                paramshortfilename.OracleDbType = OracleDbType.Varchar2;
                paramshortfilename.Direction = ParameterDirection.Input;
                paramshortfilename.Value = shortfilename;
                OraCommand.Parameters.Add(paramshortfilename);

                OracleParameter paramasofyr = new OracleParameter();
                paramasofyr.ParameterName = "asofyr";
                paramasofyr.OracleDbType = OracleDbType.Int16;
                paramasofyr.Direction = ParameterDirection.Input;
                paramasofyr.Value = asofyr;
                OraCommand.Parameters.Add(paramasofyr);

                OracleParameter paramasofmm = new OracleParameter();
                paramasofmm.ParameterName = "asofmm";
                paramasofmm.OracleDbType = OracleDbType.Int16;
                paramasofmm.Direction = ParameterDirection.Input;
                paramasofmm.Value = asofmm;
                OraCommand.Parameters.Add(paramasofmm);

                OracleParameter parammonthsdiff = new OracleParameter();
                parammonthsdiff.ParameterName = "monthsdiff";
                parammonthsdiff.OracleDbType = OracleDbType.Int16;
                parammonthsdiff.Direction = ParameterDirection.Input;
                parammonthsdiff.Value = monthsdiff;
                OraCommand.Parameters.Add(parammonthsdiff);

                OracleParameter paraminfo = new OracleParameter();
                paraminfo.ParameterName = "info";
                paraminfo.OracleDbType = OracleDbType.Varchar2;
                paraminfo.Direction = ParameterDirection.Output;
                paraminfo.Size = 300;
                OraCommand.Parameters.Add(paraminfo);
            label:
                trynow++;
                try
                {
                    Conn.Open();
                    OraCommand.ExecuteNonQuery();
                    ReturnInfo = OraCommand.Parameters["info"].Value.ToString();
                    ////Trace.WriteLine("INFO RETURNED FROM STORED PROCEDURE - " + ReturnInfo + "\n");
                    ////Trace.WriteLine(@"
                    //DECLARE
                    //output varchar2(3000);
                    //BEGIN
                    //" + proc + @"('" + username + @"', '" + tablesource + @"', '" + shortfilename + @"', " + asofyr + @", " + asofmm + @", , " + monthsdiff + @", output);
                    //DBMS_Output.Put_Line('Output: ' || output);
                    //END;
                    //");
                    Conn.Close();
                    Conn.Dispose();
                }
                catch (Exception ex)
                {
                    Conn.Close();
                    if (trynow < tryings)
                    {
                        goto label;
                    }
                    else
                    {
                        //Trace.WriteLine(ex.Message);
                        return ex.Message;
                    }
                }
                return ReturnInfo;

            }
        }
        class SignalRSendData_admin
        {
            public void sendInfoToClient(string connectionid, string channel, string eventname, string statusstate, int percentcomplete, List<string> filenames = null)
            {
                frmAdmin frm1 = (frmAdmin)Application.OpenForms["frmAdmin"];
                //string str = "Process info here" + "| Time of execution:" + DateTime.Now; 
                //frm1.richTextBox1.AppendText("connectionid:" + connectionid + "-channel:" + channel + "-eventname:" + eventname
                //            + "-statusstate:" + statusstate + "-percentcomplete:" + percentcomplete + "----" + DateTime.Now);

                frm1.richTextBox1.AppendText("Process info here : " + " Channel : " + channel + " | Event Name : " + eventname
                            + " | Status State : " + statusstate + " | Percent Complete : " + percentcomplete + " | Time of execution : " + DateTime.Now);
                frm1.richTextBox1.AppendText("\n");
            }
        }
        class ExcelServicesModels_admin
        {
            public string Get_SQL_All_Clients(string dt)
            {
                string init = @"
            select ff.* from (
            select 
            TRIM(UPPER(a.PF_CLIENT)) as CLIENTID,
            TRIM(UPPER(a.COMPANY)) as COID,
            COALESCE(TRIM(UPPER(b.T2_LEGAL_NAME)),TRIM(UPPER(a.DESCR))) as ORACLECLIENT,
            COALESCE(TRIM(UPPER(a.DESCR)),TRIM(UPPER(b.T2_LEGAL_NAME))) as NAMES,
            COALESCE(TRIM(UPPER(b.T2_LEGAL_NAME)),TRIM(UPPER(a.DESCR))) as LEGALNAME,
            b.T2_COMP_LIVE_DT AS STDT, 
            b.T2_COMP_TERM_DT AS TERMDT, 
            a.EFF_STATUS AS STATUS,
            CASE WHEN TRIM(UPPER(b.T2_WC_COVRG_OPTN)) = 'Y' THEN 'N' ELSE 'Y' END as CARVEOUT,
            substr('000000' || REPLACE(REPLACE(REPLACE(TRIM(UPPER(c.NAICS)),'N/A','000'),'NA','00'),'.','0'),-6,6) as NAICS,
            '' as NAICSDESCR,
            '' AS SIC,
            '' AS SICDESCR,
            '' AS VERTICAL,
            TRIM(UPPER(a.PF_CORP)) as PFCORP,
            TRIM(UPPER(b.T2_PEO_ID)) as T2PEOID 
            from (
            select bb.* from (
            select a.*, MAX(a.EFFDT) OVER (PARTITION BY a.COMPANY) as MAXDT from PS_COMPANY_TBL a where a.EFFDT <= TO_DATE('REPLACEDATE','mm/dd/yyyy')
            ) bb
            where bb.EFFDT = bb.MAXDT
            ) a
            LEFT JOIN PS_T2_CLIENTOPTION b
            on TRIM(UPPER(a.COMPANY)) = TRIM(UPPER(b.COMPANY)) and TRIM(UPPER(a.PF_CLIENT)) = TRIM(UPPER(b.PF_CLIENT))
            LEFT JOIN (
            select dd.* from (
            select ddd.*,MAX(ddd.EFFDT) OVER (PARTITION BY ddd.ESTABID) as MAXDT from PS_ESTAB_TBL_USA ddd where ddd.EFFDT <= TO_DATE('REPLACEDATE','mm/dd/yyyy')
            ) dd where dd.EFFDT = dd.MAXDT
            ) c
            on TRIM(UPPER(a.COMPANY)) = TRIM(UPPER(c.ESTABID))
            ) ff WHERE UPPER(LEGALNAME) not like '%TRINET%' and CLIENTID NOT IN ('0000')";
                return init.Replace("REPLACEDATE", dt);
            }
            public class PreloadedIDsInfoProcess_admin
            {
                public string get_Final_ID_Data_SQL_RatesChange_Pull(string id, string enddate, int monthsback)
                {
                    
                        string r = "";
                        r += "select finaldata.T2_PEO_ID, finaldata.COMPANY, finaldata.CLIENTID, finaldata.TIMEFRAME, finaldata.TIMEFRAME2, finaldata.STATE, finaldata.WORKERS_COMP_CD, finaldata.PF_COST_RATE_ID, finaldata.T2_WC_DISCOUNT, finaldata.T2_WC_MODIFIER, finaldata.PF_RATE, finaldata.BILL_RATE_CALCULATED, finaldata.COST_RATE, finaldata.MANUAL_RATE, finaldata.PF_RATE_CHANGED, finaldata.T2_WC_DISCOUNT_CHANGED, finaldata.T2_WC_MODIFIER_CHANGED, finaldata.COST_RATE_CHANGED, finaldata.MANUAL_RATE_CHANGED ";
                        r += "from ( ";
                        r += "select finalresult.T2_PEO_ID, finalresult.COMPANY, finalresult.CLIENTID, finalresult.TIMEFRAME, finalresult.TIMEFRAME2, finalresult.STATE, finalresult.WORKERS_COMP_CD, finalresult.PF_COST_RATE_ID, finalresult.T2_WC_DISCOUNT, finalresult.T2_WC_MODIFIER, finalresult.PF_RATE, finalresult.BILL_RATE_CALCULATED, finalresult.PF_RATE_CHANGED, finalresult.T2_WC_DISCOUNT_CHANGED, finalresult.T2_WC_MODIFIER_CHANGED, finalresult.COST_RATE, finalresult.MANUAL_RATE_XX as MANUAL_RATE, ";
                        r += "CASE WHEN finalresult.COST_RATE = LAG(finalresult.COST_RATE,1,0) OVER (PARTITION BY finalresult.COMPANY, finalresult.CLIENTID, finalresult.STATE, finalresult.WORKERS_COMP_CD, finalresult.PF_COST_RATE_ID order by finalresult.COMPANY, finalresult.CLIENTID, finalresult.STATE, finalresult.WORKERS_COMP_CD, finalresult.PF_COST_RATE_ID, finalresult.TIMEFRAME) THEN 'No' ELSE  ";
                        r += "CASE WHEN ROW_NUMBER () OVER (PARTITION BY finalresult.COMPANY, finalresult.CLIENTID, finalresult.STATE, finalresult.WORKERS_COMP_CD, finalresult.PF_COST_RATE_ID order by finalresult.COMPANY, finalresult.CLIENTID, finalresult.STATE, finalresult.WORKERS_COMP_CD, finalresult.PF_COST_RATE_ID, finalresult.TIMEFRAME) = 1 THEN 'No' ELSE 'Yes' END ";
                        r += "END as COST_RATE_CHANGED, ";
                        r += "CASE WHEN finalresult.MANUAL_RATE_XX = LAG(finalresult.MANUAL_RATE_XX,1,0) OVER (PARTITION BY finalresult.COMPANY, finalresult.CLIENTID, finalresult.STATE, finalresult.WORKERS_COMP_CD, finalresult.T2_PEO_ID order by finalresult.COMPANY, finalresult.CLIENTID, finalresult.STATE, finalresult.WORKERS_COMP_CD, finalresult.T2_PEO_ID, finalresult.TIMEFRAME) THEN 'No' ELSE ";
                        r += "CASE WHEN ROW_NUMBER () OVER (PARTITION BY finalresult.COMPANY, finalresult.CLIENTID, finalresult.STATE, finalresult.WORKERS_COMP_CD, finalresult.T2_PEO_ID order by finalresult.COMPANY, finalresult.CLIENTID, finalresult.STATE, finalresult.WORKERS_COMP_CD, finalresult.T2_PEO_ID, finalresult.TIMEFRAME) = 1 THEN 'No' ELSE 'Yes' END ";
                        r += "END as MANUAL_RATE_CHANGED ";
                        r += "from ( ";
                        r += "select finalresss.*, ";
                        r += "case when finalresss.MANUAL_RATE_X is null THEN  ";
                        r += "FIRST_VALUE(finalresss.MANUAL_RATE_X IGNORE NULLS) OVER(PARTITION BY finalresss.COMPANY, finalresss.CLIENTID, finalresss.STATE, finalresss.WORKERS_COMP_CD, finalresss.T2_PEO_ID order by finalresss.COMPANY, finalresss.CLIENTID, finalresss.STATE, finalresss.WORKERS_COMP_CD, finalresss.T2_PEO_ID, finalresss.TIMEFRAME range between unbounded preceding and unbounded following) else  ";
                        r += "finalresss.MANUAL_RATE_X ";
                        r += "end as MANUAL_RATE_XX ";
                        r += "from ( ";
                        r += "select finalress.*, ";
                        r += "COALESCE(CASE WHEN finalress.MANUAL_RATE is not null THEN finalress.MANUAL_RATE ELSE LAG(finalress.MANUAL_RATE IGNORE NULLS) OVER(PARTITION BY finalress.COMPANY, finalress.CLIENTID, finalress.STATE, finalress.WORKERS_COMP_CD, finalress.T2_PEO_ID order by finalress.COMPANY, finalress.CLIENTID, finalress.STATE, finalress.WORKERS_COMP_CD,  finalress.T2_PEO_ID, finalress.TIMEFRAME) END,null) as MANUAL_RATE_X ";
                        r += "from ( ";
                        r += "select finalres.*, ";
                        r += "coalesce(manualrate.T2_WC_RT,manualrate2.T2_WC_RT) as MANUAL_RATE ";
                        r += "from ( ";
                        r += "select ";
                        r += "finalbase.T2_PEO_ID, ";
                        r += "finalbase.COMPANY, finalbase.CLIENTID, ";
                        r += "finalbase.TIMEFRAME, ";
                        r += "finalbase.TIMEFRAME2, ";
                        r += "finalbase.STATE, finalbase.WORKERS_COMP_CD, ";
                        r += "finalbase.PF_COST_RATE_ID_XX as PF_COST_RATE_ID, ";
                        r += "finalbase.T2_WC_DISCOUNT_X as T2_WC_DISCOUNT, ";
                        r += "finalbase.T2_WC_MODIFIER_X as T2_WC_MODIFIER, ";
                        r += "finalbase.PF_RATE_X as PF_RATE, ";
                        r += "finalbase.BILL_RATE_CALCULATED, ";
                        r += "finalbase.PF_RATE_CHANGED, ";
                        r += "finalbase.T2_WC_DISCOUNT_CHANGED, ";
                        r += "finalbase.T2_WC_MODIFIER_CHANGED, ";
                        r += "finalbase.COST_RATE_XX as COST_RATE ";
                        r += "from ( ";
                        r += "select fffff.*, ";
                        r += "case when fffff.COST_RATE_X is null THEN  ";
                        r += "FIRST_VALUE(fffff.COST_RATE_X IGNORE NULLS) OVER(PARTITION BY fffff.COMPANY, fffff.CLIENTID, fffff.STATE, fffff.WORKERS_COMP_CD order by fffff.COMPANY, fffff.CLIENTID, fffff.STATE, fffff.WORKERS_COMP_CD, fffff.TIMEFRAME range between unbounded preceding and unbounded following) else  ";
                        r += "fffff.COST_RATE_X ";
                        r += "end as COST_RATE_XX, ";
                        r += "case when fffff.PF_COST_RATE_ID_X is null THEN  ";
                        r += "FIRST_VALUE(fffff.PF_COST_RATE_ID_X IGNORE NULLS) OVER(PARTITION BY fffff.COMPANY, fffff.CLIENTID, fffff.STATE, fffff.WORKERS_COMP_CD order by fffff.COMPANY, fffff.CLIENTID, fffff.STATE, fffff.WORKERS_COMP_CD, fffff.TIMEFRAME range between unbounded preceding and unbounded following) else  ";
                        r += "fffff.PF_COST_RATE_ID_X ";
                        r += "end as PF_COST_RATE_ID_XX ";
                        r += "from ( ";
                        r += "select ffff.*, ";
                        r += "COALESCE(CASE WHEN ffff.COST_RATE is not null THEN ffff.COST_RATE ELSE LAG(ffff.COST_RATE IGNORE NULLS) OVER(PARTITION BY ffff.COMPANY, ffff.CLIENTID, ffff.STATE, ffff.WORKERS_COMP_CD order by ffff.COMPANY, ffff.CLIENTID, ffff.STATE, ffff.WORKERS_COMP_CD, ffff.TIMEFRAME) END,null) as COST_RATE_X, ";
                        r += "COALESCE(CASE WHEN ffff.PF_COST_RATE_ID is not null THEN ffff.PF_COST_RATE_ID ELSE LAG(ffff.PF_COST_RATE_ID IGNORE NULLS) OVER(PARTITION BY ffff.COMPANY, ffff.CLIENTID, ffff.STATE, ffff.WORKERS_COMP_CD order by ffff.COMPANY, ffff.CLIENTID, ffff.STATE, ffff.WORKERS_COMP_CD, ffff.TIMEFRAME) END,null) as PF_COST_RATE_ID_X ";
                        r += "from ( ";
                        r += "select fff.*, ";
                        r += "(fff.T2_WC_MODIFIER_X * fff.PF_RATE_X)*(1-(fff.T2_WC_DISCOUNT_X/100)) as BILL_RATE_CALCULATED, ";
                        r += "CASE WHEN fff.T2_WC_DISCOUNT_X = LAG(fff.T2_WC_DISCOUNT_X,1,0) OVER (PARTITION BY fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD order by fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD, fff.TIMEFRAME) THEN 'No' ELSE  ";
                        r += "CASE WHEN ROW_NUMBER () OVER (PARTITION BY fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD order by fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD, fff.TIMEFRAME) = 1 THEN 'No' ELSE 'Yes' END ";
                        r += "END as T2_WC_DISCOUNT_CHANGED, ";
                        r += "CASE WHEN fff.T2_WC_MODIFIER_X = LAG(fff.T2_WC_MODIFIER_X,1,0) OVER (PARTITION BY fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD order by fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD, fff.TIMEFRAME) THEN 'No' ELSE ";
                        r += "CASE WHEN ROW_NUMBER () OVER (PARTITION BY fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD order by fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD, fff.TIMEFRAME) = 1 THEN 'No' ELSE 'Yes' END ";
                        r += "END as T2_WC_MODIFIER_CHANGED, ";
                        r += "CASE WHEN fff.PF_RATE_X = LAG(fff.PF_RATE_X,1,0) OVER (PARTITION BY fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD order by fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD, fff.TIMEFRAME) THEN 'No' ELSE  ";
                        r += "CASE WHEN ROW_NUMBER () OVER (PARTITION BY fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD order by fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD, fff.TIMEFRAME) = 1 THEN 'No' ELSE 'Yes' END ";
                        r += "END as PF_RATE_CHANGED, ";
                        r += "FIRST_VALUE(coalesce(costrate.PF_RATE,costrate2.PF_RATE) IGNORE NULLS) OVER (PARTITION BY fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD order by fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD, fff.TIMEFRAME) as COST_RATE, ";
                        r += "FIRST_VALUE(coalesce(costrate.PF_COST_RATE_ID,costrate2.PF_COST_RATE_ID) IGNORE NULLS) OVER (PARTITION BY fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD order by fff.COMPANY, fff.CLIENTID, fff.STATE, fff.WORKERS_COMP_CD, fff.TIMEFRAME) as PF_COST_RATE_ID ";
                        r += "from ( ";
                        r += "select ff.*, ";
                        r += "COALESCE(CASE WHEN ff.T2_WC_DISCOUNT is not null THEN ff.T2_WC_DISCOUNT ELSE LAG(ff.T2_WC_DISCOUNT IGNORE NULLS) OVER(PARTITION BY ff.COMPANY, ff.CLIENTID, ff.STATE, ff.WORKERS_COMP_CD order by ff.COMPANY, ff.CLIENTID, ff.STATE, ff.WORKERS_COMP_CD, ff.TIMEFRAME) END,0) as T2_WC_DISCOUNT_X, ";
                        r += "COALESCE(CASE WHEN ff.T2_WC_MODIFIER is not null THEN ff.T2_WC_MODIFIER ELSE LAG(ff.T2_WC_MODIFIER IGNORE NULLS) OVER(PARTITION BY ff.COMPANY, ff.CLIENTID, ff.STATE, ff.WORKERS_COMP_CD order by ff.COMPANY, ff.CLIENTID, ff.STATE, ff.WORKERS_COMP_CD, ff.TIMEFRAME) END,0) as T2_WC_MODIFIER_X, ";
                        r += "COALESCE(CASE WHEN ff.PF_RATE is not null THEN ff.PF_RATE ELSE LAG(ff.PF_RATE IGNORE NULLS) OVER(PARTITION BY ff.COMPANY, ff.CLIENTID, ff.STATE, ff.WORKERS_COMP_CD order by ff.COMPANY, ff.CLIENTID, ff.STATE, ff.WORKERS_COMP_CD, ff.TIMEFRAME) END,0) as PF_RATE_X, ";
                        r += "ids.T2_PEO_ID ";
                        r += "from ( ";
                        r += "select f.* from ( ";
                        r += "select alldt.*, ";
                        r += "coalesce(ratesmain0.T2_WC_DISCOUNT,ratesmain1.T2_WC_DISCOUNT) as T2_WC_DISCOUNT, ";
                        r += "coalesce(ratesmain0.T2_WC_MODIFIER,ratesmain1.T2_WC_MODIFIER) as T2_WC_MODIFIER, ";
                        r += "coalesce(ratesmain0.PF_RATE,ratesmain1.PF_RATE) as PF_RATE ";
                        r += "from ( ";
                        r += "select b.*,a.* from ( ";
                        r += "select distinct TIMEFRAME, TF as TIMEFRAME2 from ";
                        r += "( ";
                        r += "select tf.x as TF, ";
                        r += "EXTRACT (YEAR FROM tf.x) || '-' || substr('00' || EXTRACT (MONTH FROM tf.x),-2,2) as TIMEFRAME ";
                        r += "from ( ";
                        r += "SELECT ADD_MONTHS(TO_DATE('" + enddate + @"','mm/dd/yyyy'), -ROWNUM+1) - (EXTRACT(DAY from TO_DATE('" + enddate + @"','mm/dd/yyyy'))) as x FROM ( ";
                        r += "  SELECT 0 FROM DUAL ";
                        r += "  CONNECT BY LEVEL <= " + monthsback + " ";
                        r += ") ";
                        r += ") tf ";
                        r += ") ";
                        r += ") a,( ";
                        r += "select distinct COMPANY, CLIENTID, STATE, WORKERS_COMP_CD from ( ";
                        r += "select base_1_2.*, ";
                        r += "coalesce(base3.PF_BILL_RATE_ID,base4.PF_BILL_RATE_ID) as PF_BILL_RATE_ID, ";
                        r += "coalesce(base3.PF_COST_RATE_ID,base4.PF_COST_RATE_ID) as PF_COST_RATE_ID, ";
                        r += "coalesce(base3.PF_COST_MODIFIER,base4.PF_COST_MODIFIER) as PF_COST_MODIFIER, ";
                        r += "coalesce(base3.T2_WC_MODIFIER,base4.T2_WC_MODIFIER) as T2_WC_MODIFIER, ";
                        r += "coalesce(base3.EFFDT,base4.EFFDT) as EFFDT_WC_MODIFIER ";
                        r += "from ( ";
                        r += "select base1.*, ";
                        r += "coalesce(base2.EFFDT,sysdate) as EFFDT, ";
                        r += "coalesce(base2.EFFDT,sysdate) as EFFDT_WC_DISCOUNT, ";
                        r += "coalesce(base2.PF_BILL_MODIFIER,0) as PF_BILL_MODIFIER,coalesce(base2.PF_LUMPSUM_RATE,0) as PF_LUMPSUM_RATE,coalesce(base2.PF_LUMPSUM_FLG,'N') as PF_LUMPSUM_FLG,coalesce(base2.PF_CHRG_PCT,0) as PF_CHRG_PCT,coalesce(base2.T2_WC_DISCOUNT,0) as T2_WC_DISCOUNT ";
                        r += "from ( ";
                        r += "select distinct  ";
                        r += "d.COMPANY,d.CLIENTID,d.STATE,d.WORKERS_COMP_CD from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += "where d.STATE is not null and trim(d.WORKERS_COMP_CD) is not null ";
                        r += ") d ";
                        r += ") base1 ";
                        r += "LEFT JOIN   ";
                        r += "( ";
                        r += "select distinct a.COMPANY,a.EFFDT,a.STATE,a.WORKERS_COMP_CD,a.PF_BILL_MODIFIER,a.PF_LUMPSUM_RATE,a.PF_LUMPSUM_FLG,a.PF_CHRG_PCT,a.T2_WC_DISCOUNT ";
                        r += "from PS_PF_CO_WCDTL a where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") base2 on base1.COMPANY = base2.COMPANY and base1.STATE = base2.STATE and base1.WORKERS_COMP_CD = base2.WORKERS_COMP_CD ";
                        r += ") base_1_2 ";
                        r += "LEFT JOIN ";
                        r += "( ";
                        r += "select b.*   ";
                        r += "from ( ";
                        r += "select a.* ";
                        r += "from PS_PF_COMPANY_WC a where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") b  ";
                        r += ") base3 ";
                        r += "on base_1_2.COMPANY = base3.COMPANY and base_1_2.STATE = base3.STATE and base_1_2.EFFDT = base3.EFFDT ";
                        r += "LEFT JOIN   ";
                        r += "( ";
                        r += "select b.* ";
                        r += "from ( ";
                        r += "select a.*, ";
                        r += "MAX(a.EFFDT) OVER(PARTITION BY a.COMPANY, a.STATE) AS MAXDT ";
                        r += "from PS_PF_COMPANY_WC a where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") b where b.MAXDT = b.EFFDT ";
                        r += ") base4 ";
                        r += "on base_1_2.COMPANY = base4.COMPANY and base_1_2.STATE = base4.STATE ";
                        r += ")) b ";
                        r += ") alldt ";
                        r += "left join ";
                        r += "( ";
                        r += "select finalress.* ";
                        r += "from ( ";
                        r += "select finalres.*, ";
                        r += "(finalres.T2_WC_MODIFIER*finalres.PF_RATE)*(1-(finalres.T2_WC_DISCOUNT/100)) as BILL_RATE_CALCULATED, ";
                        r += "EXTRACT(YEAR FROM finalres.EFFDT) || '-' || SUBSTR('00' || EXTRACT(MONTH FROM finalres.EFFDT),-2,2) as TIMEFRAME, ";
                        r += "MAX(finalres.EFFDT) OVER(PARTITION BY finalres.COMPANY,finalres.STATE,finalres.WORKERS_COMP_CD,EXTRACT(YEAR FROM finalres.EFFDT) || '-' || SUBSTR('00' || EXTRACT(MONTH FROM finalres.EFFDT),-2,2)) AS MAXDT ";
                        r += "from ";
                        r += "( ";
                        r += "select base_1_2_3.*, ";
                        r += "base4.PF_RATE ";
                        r += "from ( ";
                        r += "select base_1_2.*, ";
                        r += "base3.T2_WC_MODIFIER, ";
                        r += "base3.PF_BILL_RATE_ID ";
                        r += "from ( ";
                        r += "select base1.*, ";
                        r += "base2.EFFDT, ";
                        r += "base2.T2_WC_DISCOUNT ";
                        r += "from ( ";
                        r += "select distinct  ";
                        r += "d.COMPANY,d.CLIENTID,d.STATE,d.WORKERS_COMP_CD from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d ";
                        r += ") base1 ";
                        r += "INNER JOIN   ";
                        r += "( ";
                        r += "select distinct a.COMPANY,a.EFFDT,a.STATE,a.WORKERS_COMP_CD,a.PF_BILL_MODIFIER,a.PF_LUMPSUM_RATE,a.PF_LUMPSUM_FLG,a.PF_CHRG_PCT,a.T2_WC_DISCOUNT ";
                        r += "from PS_PF_CO_WCDTL a where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") base2 on base1.COMPANY = base2.COMPANY and base1.STATE = base2.STATE and base1.WORKERS_COMP_CD = base2.WORKERS_COMP_CD ";
                        r += ") base_1_2 ";
                        r += "inner join ";
                        r += "( ";
                        r += "select b.*   ";
                        r += "from ( ";
                        r += "select a.* ";
                        r += "from PS_PF_COMPANY_WC a where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") b  ";
                        r += ") base3 ";
                        r += "on base_1_2.COMPANY = base3.COMPANY and base_1_2.STATE = base3.STATE and base_1_2.EFFDT = base3.EFFDT ";
                        r += ") base_1_2_3 ";
                        r += "inner join ";
                        r += "( ";
                        r += "select b4.*   ";
                        r += "from ( ";
                        r += "select a.*, ";
                        r += "MAX(a.EFFDT) OVER(PARTITION BY a.STATE,a.PF_BILL_RATE_ID ORDER BY a.STATE,a.PF_BILL_RATE_ID) AS MAXDT ";
                        r += "from PS_PF_WCBILL_RATE a WHERE a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') and a.PF_BILL_RATE_ID IN (  ";
                        r += "select distinct PF_BILL_RATE_ID   ";
                        r += "from ( ";
                        r += "select a.* from PS_PF_COMPANY_WC a where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") b ";
                        r += ")  ";
                        r += ") b4 where b4.EFFDT = b4.MAXDT ";
                        r += ") base4 ";
                        r += "on base_1_2_3.PF_BILL_RATE_ID = base4.PF_BILL_RATE_ID and base_1_2_3.STATE = base4.STATE and base_1_2_3.WORKERS_COMP_CD = base4.WORKERS_COMP_CD ";
                        r += ") finalres ";
                        r += "order by finalres.COMPANY,finalres.CLIENTID,finalres.STATE,finalres.WORKERS_COMP_CD,finalres.EFFDT ";
                        r += ") finalress ";
                        r += "where finalress.MAXDT = finalress.EFFDT ";
                        r += ") ratesmain0 ";
                        r += "on alldt.CLIENTID = ratesmain0.CLIENTID and alldt.COMPANY = ratesmain0.COMPANY and alldt.STATE = ratesmain0.STATE and alldt.WORKERS_COMP_CD = ratesmain0.WORKERS_COMP_CD and alldt.TIMEFRAME = ratesmain0.TIMEFRAME ";
                        r += "left join ";
                        r += "( ";
                        r += "select finalresss.* from ( select finalress.*, MAX(finalress.TIMEFRAME) OVER(PARTITION BY finalress.PF_BILL_RATE_ID, finalress.WORKERS_COMP_CD, finalress.STATE) as TIMEFRAME_MAX ";
                        r += "from ( ";
                        r += "select finalres.*, (finalres.T2_WC_MODIFIER*finalres.PF_RATE)*(1-(finalres.T2_WC_DISCOUNT/100)) as BILL_RATE_CALCULATED, ";
                        r += "EXTRACT (YEAR FROM (ADD_MONTHS(TO_DATE('" + enddate + @"','mm/dd/yyyy'), -(3-1)))) || '-' || substr('00' || EXTRACT (MONTH FROM (ADD_MONTHS(TO_DATE('" + enddate + @"','mm/dd/yyyy'), -(3-1)))),-2,2) as TIMEFRAME, ";
                        r += "MAX(finalres.EFFDT) OVER(PARTITION BY finalres.COMPANY,finalres.STATE,finalres.WORKERS_COMP_CD) AS MAXDT ";
                        r += "from ";
                        r += "( ";
                        r += "select base_1_2_3.*, ";
                        r += "base4.PF_RATE ";
                        r += "from ( ";
                        r += "select base_1_2.*, ";
                        r += "base3.T2_WC_MODIFIER, ";
                        r += "base3.PF_BILL_RATE_ID ";
                        r += "from ( ";
                        r += "select base1.*, ";
                        r += "base2.EFFDT, ";
                        r += "base2.T2_WC_DISCOUNT ";
                        r += "from ( ";
                        r += "select distinct  ";
                        r += "d.COMPANY,d.CLIENTID,d.STATE,d.WORKERS_COMP_CD from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d ";
                        r += ") base1 ";
                        r += "INNER JOIN   ";
                        r += "( ";
                        r += "select distinct a.COMPANY,a.EFFDT,a.STATE,a.WORKERS_COMP_CD,a.PF_BILL_MODIFIER,a.PF_LUMPSUM_RATE,a.PF_LUMPSUM_FLG,a.PF_CHRG_PCT,a.T2_WC_DISCOUNT ";
                        r += "from PS_PF_CO_WCDTL a where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") base2 on base1.COMPANY = base2.COMPANY and base1.STATE = base2.STATE and base1.WORKERS_COMP_CD = base2.WORKERS_COMP_CD ";
                        r += ") base_1_2 ";
                        r += "inner join ";
                        r += "( ";
                        r += "select b.*   ";
                        r += "from ( ";
                        r += "select a.* ";
                        r += "from PS_PF_COMPANY_WC a where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") b  ";
                        r += ") base3 ";
                        r += "on base_1_2.COMPANY = base3.COMPANY and base_1_2.STATE = base3.STATE and base_1_2.EFFDT = base3.EFFDT ";
                        r += ") base_1_2_3 ";
                        r += "inner join ";
                        r += "( ";
                        r += "select b4.*   ";
                        r += "from ( ";
                        r += "select a.*, ";
                        r += "MAX(a.EFFDT) OVER(PARTITION BY a.STATE,a.PF_BILL_RATE_ID ORDER BY a.STATE,a.PF_BILL_RATE_ID) AS MAXDT ";
                        r += "from PS_PF_WCBILL_RATE a WHERE a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') and a.PF_BILL_RATE_ID IN (  ";
                        r += "select distinct PF_BILL_RATE_ID   ";
                        r += "from ( ";
                        r += "select a.* from PS_PF_COMPANY_WC a where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") b ";
                        r += ")  ";
                        r += ") b4 where b4.EFFDT = b4.MAXDT ";
                        r += ") base4 ";
                        r += "on base_1_2_3.PF_BILL_RATE_ID = base4.PF_BILL_RATE_ID and base_1_2_3.STATE = base4.STATE and base_1_2_3.WORKERS_COMP_CD = base4.WORKERS_COMP_CD ";
                        r += ") finalres ";
                        r += "order by finalres.COMPANY,finalres.CLIENTID,finalres.STATE,finalres.WORKERS_COMP_CD,finalres.EFFDT ";
                        r += ") finalress ";
                        r += "where finalress.MAXDT = finalress.EFFDT ) finalresss where finalresss.TIMEFRAME_MAX = finalresss.TIMEFRAME ";
                        r += ") ratesmain1 ";
                        r += "on alldt.CLIENTID = ratesmain1.CLIENTID and alldt.COMPANY = ratesmain1.COMPANY and alldt.STATE = ratesmain1.STATE and alldt.WORKERS_COMP_CD = ratesmain1.WORKERS_COMP_CD ";
                        r += ") f ";
                        r += "order by f.COMPANY, f.CLIENTID, f.STATE, f.WORKERS_COMP_CD, f.TIMEFRAME ";
                        r += ") ff ";
                        r += "left join ( ";
                        r += "select distinct company, T2_PEO_ID from PS_T2_CLIENTOPTION where COMPANY IN ('" + id + @"') ";
                        r += ") ids on ff.COMPANY = ids.COMPANY ";
                        r += ") fff ";
                        r += "left join ( ";
                        r += "select distinct aa.PF_COST_RATE_ID, aa.STATE, aa.WORKERS_COMP_CD, aa.PF_RATE, aa.TIMEFRAME ";
                        r += "from ( ";
                        r += "select a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.EFFDT, a.TIMEFRAME, ";
                        r += "CASE WHEN LEAD(a.PF_RATE IGNORE NULLS) OVER(PARTITION BY a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME order by a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME, a.EFFDT) IS NULL THEN ";
                        r += "a.PF_RATE ";
                        r += "ELSE ";
                        r += "LEAD(a.PF_RATE IGNORE NULLS) OVER(PARTITION BY a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME order by a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME, a.EFFDT) ";
                        r += "END ";
                        r += "as PF_RATE ";
                        r += "from ( ";
                        r += "select PF_COST_RATE_ID, STATE, WORKERS_COMP_CD, ";
                        r += "EFFDT, ";
                        r += "PF_RATE, ";
                        r += "EXTRACT(YEAR FROM EFFDT) || '-' || SUBSTR('00' || EXTRACT(MONTH FROM EFFDT),-2,2) as TIMEFRAME ";
                        r += "from (select aa.*  ";
                        r += "from PS_PF_WCCOST_RATE aa where aa.PF_COST_RATE_ID IN (select distinct a.PF_COST_RATE_ID from  ";
                        r += "PS_PF_COMPANY_WC a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy')  ";
                        r += ") ";
                        r += "and aa.WORKERS_COMP_CD IN ( ";
                        r += "select distinct  ";
                        r += "d.WORKERS_COMP_CD from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d) ";
                        r += "and  ";
                        r += "aa.STATE IN ( ";
                        r += "select distinct  ";
                        r += "d.STATE from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d ";
                        r += ")) ";
                        r += "order by PF_COST_RATE_ID, STATE, WORKERS_COMP_CD, EFFDT ";
                        r += ") a ) aa ";
                        r += ") costrate ";
                        r += "on trim(upper(fff.STATE)) = trim(upper(costrate.STATE)) and trim(upper(fff.WORKERS_COMP_CD)) = trim(upper(costrate.WORKERS_COMP_CD)) and fff.TIMEFRAME = costrate.TIMEFRAME ";
                        r += "left join ( ";
                        r += "select distinct aaaa.PF_COST_RATE_ID, aaaa.STATE, aaaa.WORKERS_COMP_CD, aaaa.PF_RATE, aaaa.TIMEFRAME ";
                        r += "from ( ";
                        r += "select aaa.* from ( select aa.PF_COST_RATE_ID, aa.STATE, aa.WORKERS_COMP_CD, aa.PF_RATE, aa.TIMEFRAME, ";
                        r += "MAX(aa.TIMEFRAME) OVER(PARTITION BY aa.PF_COST_RATE_ID, aa.WORKERS_COMP_CD, aa.STATE) as TIMEFRAME_MAX ";
                        r += "from ( ";
                        r += "select a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.EFFDT, a.TIMEFRAME, ";
                        r += "CASE WHEN LEAD(a.PF_RATE IGNORE NULLS) OVER(PARTITION BY a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME order by a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME, a.EFFDT) IS NULL THEN ";
                        r += "a.PF_RATE ";
                        r += "ELSE ";
                        r += "LEAD(a.PF_RATE IGNORE NULLS) OVER(PARTITION BY a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME order by a.PF_COST_RATE_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME, a.EFFDT) ";
                        r += "END ";
                        r += "as PF_RATE ";
                        r += "from ( ";
                        r += "select PF_COST_RATE_ID, STATE, WORKERS_COMP_CD, ";
                        r += "EFFDT, ";
                        r += "PF_RATE, ";
                        r += "EXTRACT(YEAR FROM EFFDT) || '-' || SUBSTR('00' || EXTRACT(MONTH FROM EFFDT),-2,2) as TIMEFRAME ";
                        r += "from (select aa.*  ";
                        r += "from PS_PF_WCCOST_RATE aa where aa.PF_COST_RATE_ID IN (select distinct a.PF_COST_RATE_ID from  ";
                        r += "PS_PF_COMPANY_WC a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy')  ";
                        r += ") ";
                        r += "and aa.WORKERS_COMP_CD IN ( ";
                        r += "select distinct  ";
                        r += "d.WORKERS_COMP_CD from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d) ";
                        r += "and  ";
                        r += "aa.STATE IN ( ";
                        r += "select distinct  ";
                        r += "d.STATE from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d ";
                        r += ")) ";
                        r += "order by PF_COST_RATE_ID, STATE, WORKERS_COMP_CD, EFFDT ";
                        r += ") a ) aa ) aaa where aaa.TIMEFRAME_MAX = aaa.TIMEFRAME ) aaaa ";
                        r += ") costrate2 ";
                        r += "on trim(upper(fff.STATE)) = trim(upper(costrate2.STATE)) and trim(upper(fff.WORKERS_COMP_CD)) = trim(upper(costrate2.WORKERS_COMP_CD)) ";
                        r += ") ffff ";
                        r += ") fffff ";
                        r += ") finalbase ";
                        r += ") finalres ";
                        r += "left join ( ";
                        r += "select distinct aa.VENDOR_ID, aa.T2_PEO_ID, aa.STATE, aa.WORKERS_COMP_CD, aa.T2_WC_RT, aa.TIMEFRAME ";
                        r += "from ( ";
                        r += "select a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.EFFDT, a.TIMEFRAME, ";
                        r += "CASE WHEN LEAD(a.T2_WC_RT IGNORE NULLS) OVER(PARTITION BY a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME order by a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME, a.EFFDT) IS NULL THEN ";
                        r += "a.T2_WC_RT ";
                        r += "ELSE ";
                        r += "LEAD(a.T2_WC_RT IGNORE NULLS) OVER(PARTITION BY a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME order by a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME, a.EFFDT) ";
                        r += "END ";
                        r += "as T2_WC_RT ";
                        r += "from ( ";
                        r += "select VENDOR_ID, T2_PEO_ID, STATE, WORKERS_COMP_CD, ";
                        r += "EFFDT, ";
                        r += "TO_NUMBER(coalesce(TRIM(TRANSLATE(T2_WC_RT, ' \",abcdefghigklmnopqrstuvwxyz()ABCDEFGHIJKLMNOPQRSTUVXYZ¿-',' ')),'0')) as T2_WC_RT, ";
                        r += "EXTRACT(YEAR FROM EFFDT) || '-' || SUBSTR('00' || EXTRACT(MONTH FROM EFFDT),-2,2) as TIMEFRAME ";
                        r += "from ( ";
                        r += "select * from PS_T2_WC_RATE_TBL where ";
                        r += "WORKERS_COMP_CD IN ( ";
                        r += "select distinct  ";
                        r += "d.WORKERS_COMP_CD from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d) ";
                        r += "and  ";
                        r += "STATE IN ( ";
                        r += "select distinct  ";
                        r += "d.STATE from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d ";
                        r += ") ";
                        r += ") ";
                        r += "order by VENDOR_ID, T2_PEO_ID, STATE, WORKERS_COMP_CD, EFFDT ";
                        r += ") a ) aa ";
                        r += ") manualrate ";
                        r += "on  ";
                        r += "trim(upper(finalres.T2_PEO_ID)) = trim(upper(manualrate.T2_PEO_ID)) and trim(upper(finalres.STATE)) = trim(upper(manualrate.STATE)) and trim(upper(finalres.WORKERS_COMP_CD)) = trim(upper(manualrate.WORKERS_COMP_CD)) and finalres.TIMEFRAME = manualrate.TIMEFRAME ";
                        r += "left join ( ";
                        r += "select distinct aaaa.VENDOR_ID, aaaa.T2_PEO_ID, aaaa.STATE, aaaa.WORKERS_COMP_CD, aaaa.T2_WC_RT, aaaa.TIMEFRAME ";
                        r += "from ( select aaa.* from ( select aa.VENDOR_ID, aa.T2_PEO_ID, aa.STATE, aa.WORKERS_COMP_CD, aa.T2_WC_RT, aa.TIMEFRAME, ";
                        r += "MAX(aa.TIMEFRAME) OVER(PARTITION BY aa.T2_PEO_ID, aa.WORKERS_COMP_CD, aa.STATE) as TIMEFRAME_MAX ";
                        r += "from ( ";
                        r += "select a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.EFFDT, a.TIMEFRAME, ";
                        r += "CASE WHEN LEAD(a.T2_WC_RT IGNORE NULLS) OVER(PARTITION BY a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME order by a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME, a.EFFDT) IS NULL THEN ";
                        r += "a.T2_WC_RT ";
                        r += "ELSE ";
                        r += "LEAD(a.T2_WC_RT IGNORE NULLS) OVER(PARTITION BY a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME order by a.VENDOR_ID, a.T2_PEO_ID, a.STATE, a.WORKERS_COMP_CD, a.TIMEFRAME, a.EFFDT) ";
                        r += "END ";
                        r += "as T2_WC_RT ";
                        r += "from ( ";
                        r += "select VENDOR_ID, T2_PEO_ID, STATE, WORKERS_COMP_CD, ";
                        r += "EFFDT, ";
                        r += "TO_NUMBER(coalesce(TRIM(TRANSLATE(T2_WC_RT, ' \",abcdefghigklmnopqrstuvwxyz()ABCDEFGHIJKLMNOPQRSTUVXYZ¿-',' ')),'0')) as T2_WC_RT, ";
                        r += "EXTRACT(YEAR FROM EFFDT) || '-' || SUBSTR('00' || EXTRACT(MONTH FROM EFFDT),-2,2) as TIMEFRAME ";
                        r += "from ( ";
                        r += "select * from PS_T2_WC_RATE_TBL where ";
                        r += "WORKERS_COMP_CD IN ( ";
                        r += "select distinct  ";
                        r += "d.WORKERS_COMP_CD from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d) ";
                        r += "and  ";
                        r += "STATE IN ( ";
                        r += "select distinct  ";
                        r += "d.STATE from ( ";
                        r += "select c.EMPLID, ";
                        r += "c.EMPL_RCD, c.EFFDT, c.EFFSEQ,  ";
                        r += "c.COMPANY, ";
                        r += "c.PF_CLIENT as CLIENTID, ";
                        r += "d.STATE,  ";
                        r += "d.WORKERS_COMP_CD  ";
                        r += "from (  ";
                        r += "select ";
                        r += "distinct a.EMPLID, a.EFFDT, a.EFFSEQ, a.EMPL_RCD, a.COMPANY, a.PF_CLIENT ";
                        r += "from PS_JOB a ";
                        r += "where a.COMPANY IN ('" + id + @"') and a.EFFDT <= TO_DATE('" + enddate + @"','mm/dd/yyyy') ";
                        r += ") c  ";
                        r += "LEFT JOIN PS_PF_WCJOB d ON c.EMPLID = d.EMPLID and c.EFFDT = d.EFFDT and c.EFFSEQ = d.EFFSEQ and c.EMPL_RCD = d.EMPL_RCD ";
                        r += ") d ";
                        r += ") ";
                        r += ") ";
                        r += "order by VENDOR_ID, T2_PEO_ID, STATE, WORKERS_COMP_CD, EFFDT ";
                        r += ") a ) aa ) aaa where aaa.TIMEFRAME_MAX = aaa.TIMEFRAME ) aaaa ";
                        r += ") manualrate2 ";
                        r += "on trim(upper(finalres.T2_PEO_ID)) = trim(upper(manualrate2.T2_PEO_ID)) and trim(upper(finalres.STATE)) = trim(upper(manualrate2.STATE)) and trim(upper(finalres.WORKERS_COMP_CD)) = trim(upper(manualrate2.WORKERS_COMP_CD)) ";
                        r += ") finalress ) finalresss ";
                        r += ") finalresult ";
                        r += ") finaldata ";
                        return r;
                    }
                }
            }
        }
}