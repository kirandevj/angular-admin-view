const d = new Date();
export const Year: number = d.getFullYear();
export const Month: number = d.getMonth() + 1;
export const AccordGetDataList: Selection[] = [
  { value: 0, label: 'Claims' },
  { value: 1, label: 'Wages' },
  { value: 2, label: 'Clients' },
  { value: 3, label: 'Rates' },
  { value: 4, label: 'IDs parent-children' },
  { value: 5, label: 'WSE' },
  { value: 6, label: 'Rates progression' }
];
export const AccordGetDataListRevenueSideOnly: Selection[] = [
  { value: 1, label: 'Wages' },
  { value: 2, label: 'Clients' },
  { value: 3, label: 'Rates' },
  { value: 4, label: 'IDs parent-children' },
  { value: 5, label: 'WSE' }
];
export const AccordGetDataListClaimsOnly: Selection[] = [
  { value: 0, label: 'Claims' },
  { value: 1, label: 'Clients' },
  { value: 2, label: 'WSE' }
];
export const AccordDataIntegrityList: Selection[] = [
  { value: 0, label: 'None' }
];
export const AmbroseGetDataList: Selection[] = [
  { value: 0, label: 'Claims' },
  { value: 1, label: 'Wages' },
  { value: 2, label: 'Clients' },
  { value: 3, label: 'Rates' },
  { value: 4, label: 'IDs parent-children' },
  { value: 5, label: 'WSE' },
  { value: 6, label: 'Rates progression' }
];
export const Dummy: Selection[] = [
  { value: 0, label: 'Info' }
];
export const AmbroseGetDataListRevenueSideOnly: Selection[] = [
  { value: 1, label: 'Wages' },
  { value: 2, label: 'Clients' },
  { value: 3, label: 'Rates' },
  { value: 4, label: 'IDs parent-children' },
  { value: 5, label: 'WSE' }
];
export const AmbroseGetDataListClaimsOnly: Selection[] = [
  { value: 0, label: 'Claims' },
  { value: 2, label: 'Clients' }
];
export const AmbroseDataIntegrityList: Selection[] = [
  { value: 0, label: 'None' }
];
export const SOIGetDataList: Selection[] = [
  { value: 0, label: 'Claims - SOI' },
  { value: 1, label: 'Claims - SOI Texas Mutual' },
  { value: 2, label: 'Wages' },
  { value: 3, label: 'Clients' },
  { value: 4, label: 'Rates' },
  { value: 5, label: 'Retro bill rates' },
  { value: 6, label: 'IDs parent-children' },
  { value: 7, label: 'WSE' },
  { value: 8, label: 'Rates progression' }
];
export const SOIGetDataListRevenueSideOnly: Selection[] = [
  { value: 2, label: 'Wages' },
  { value: 3, label: 'Clients' },
  { value: 4, label: 'Rates' },
  { value: 5, label: 'Retro bill rates' },
  { value: 6, label: 'IDs parent-children' },
  { value: 7, label: 'WSE' }
];
export const SOIGetDataListClaimsOnly: Selection[] = [
  { value: 0, label: 'Claims - SOI' },
  { value: 1, label: 'Clients' },
  { value: 2, label: 'WSE' }
];
export const SOIDataIntegrityList: Selection[] = [
  { value: 0, label: 'None' }
];
export const PassportGetDataList: Selection[] = [
  { value: 0, label: 'Claims - CCMSI / Gallagher Bassett' },
  { value: 1, label: 'Claims - AIG' },
  { value: 2, label: 'Claims - CNA' },
  { value: 3, label: 'Claims - Zurich' },
  { value: 4, label: 'Claims - Wausau' },
  { value: 5, label: 'Claims - Texas Mutual' },
  { value: 7, label: 'Wages - PAD File' },
  { value: 8, label: 'Clients' },
  { value: 9, label: 'Rates' },
  { value: 10, label: 'IDs parent-children' },
  { value: 11, label: 'WSE' },
  { value: 12, label: 'Rates progression' }
];
export const PassportGetDataListRevenueSideOnly: Selection[] = [
  { value: 7, label: 'Wages - PAD File' },
  { value: 8, label: 'Clients' },
  { value: 9, label: 'Rates' },
  { value: 10, label: 'IDs parent-children' },
  { value: 11, label: 'WSE' }
];
export const PassportGetDataListClaimsOnly: Selection[] = [
  { value: 0, label: 'Claims - CCMSI / Gallagher Bassett' },
  { value: 1, label: 'Claims - AIG' },
  { value: 2, label: 'Claims - CNA' },
  { value: 3, label: 'Claims - Zurich' },
  { value: 4, label: 'Claims - Wausau' },
  { value: 5, label: 'Claims - Texas Mutual' },
  { value: 6, label: 'Clients' },
  { value: 7, label: 'WSE' }
];
export const PassportDataIntegrityList: Selection[] = [
  { value: 0, label: 'Wages – PAD vs BI Master' }
];
export const HTTPReqVerb: Selection[] = [
  { value: 0, label: 'GET' },
  { value: 1, label: 'POST' },
  { value: 2, label: 'FETCH' },
  { value: 3, label: 'UPDATE' }
];
export const ClientsOptions: Selection[] = [
  { value: 0, label: 'All' },
  { value: 1, label: 'Active' },
  { value: 2, label: 'Termed' }
];
export const ClientsCarveoutOptions: Selection[] = [
  { value: 0, label: 'All' },
  { value: 1, label: 'Carveout' },
  { value: 2, label: 'None carveout' }
];
export const Products: Selection[] = [
  { value: 0, label: 'TriNet I – Accord' },
  { value: 1, label: 'TriNet II – SOI' },
  { value: 2, label: 'TriNet III – Passport' },
  { value: 3, label: 'TriNet IV – Ambrose' }
];
export const getDataProducts: Selection[] = [
  { value: 0, label: 'TriNet I – Accord' },
  { value: 1, label: 'TriNet II – SOI' },
  { value: 2, label: 'TriNet III – Passport' },
  { value: 3, label: 'TriNet IV – Ambrose' },
  { value: 4, label: 'Salesforce' }
];
export const DataSetsToLoad: Selection[] = [
  { value: 0, label: 'Clients' },
  { value: 1, label: 'Rates progression' },
  { value: 2, label: 'Normalize data sets' },
  { value: 3, label: 'Eligibility Files' },
  { value: 4, label: 'Health Claims Lag data sets - TriNet II - BCBSFL - Medical' },
  { value: 5, label: 'Health Claims Lag data sets - TriNet III - BCBSFL - Medical' },
  { value: 6, label: 'Health Claims Lag data sets - TriNet II - BSCA - Medical' },
  { value: 7, label: 'Health Claims Lag data sets - TriNet III - BSCA - Medical' },
  { value: 8, label: 'Health Claims Lag data sets - TriNet III - UHC - Medical' },
  { value: 9, label: 'Health Claims Lag data sets - TriNet IV - UHC (A) - Medical' },
  { value: 10, label: 'Health Claims Lag data sets - TriNet IV - UHC (B) - Medical' },
  { value: 11, label: 'Health Claims Lag data sets - TriNet III - BCBSNC - Medical' },
  { value: 12, label: 'Health Claims Lag data sets - TriNet III - BCID - Medical' },
  { value: 13, label: 'Health Claims Lag data sets - TriNet III - EMPIRE - Medical' },
  { value: 14, label: 'Health Claims Lag data sets - TriNet II - AETNA - Medical' },
  { value: 15, label: 'Health Claims Lag data sets - TriNet III - AETNA - Medical' }
];
export const Servers: Selection[] = [
  { value: 0, label: 'HRLITER' },
  { value: 1, label: 'HRPROD' }
];
export const Productsall: Selection[] = [
  { value: 0, label: 'TriNet I – Accord' },
  { value: 1, label: 'TriNet II – SOI' },
  { value: 2, label: 'TriNet III – Passport' },
  { value: 3, label: 'TriNet IV – Ambrose' },
  { value: 4, label: 'All' }
];
export const Productsfull: Selection[] = [
  { value: 0, label: 'TriNet I – Accord' },
  { value: 1, label: 'TriNet II – SOI' },
  { value: 2, label: 'TriNet III – Passport' },
  { value: 3, label: 'TriNet IV – Ambrose' },
  { value: 4, label: 'TriNet XI – ALP' },
  { value: 5, label: 'All' }
];
export const Productsalllimit: Selection[] = [
  { value: 0, label: 'TriNet I – Accord' },
  { value: 1, label: 'TriNet II – SOI' },
  { value: 2, label: 'TriNet III – Passport' },
  { value: 3, label: 'TriNet IV – Ambrose' },
  { value: 4, label: 'TriNet XI – None medical' }
];
export const HealthOptionsFPF: Selection[] = [
  { value: 0, label: 'Medical' },
  { value: 1, label: 'Dental' },
  { value: 2, label: 'Vision' },
  { value: 3, label: 'Life' },
  { value: 4, label: 'Disability' }
];
export const HealthOptionsData: Selection[] = [
  { value: 0, label: 'FPF' },
  { value: 1, label: 'Eligibility' }
];
export const Deliverablesall: Selection[] = [
  { value: 0, label: 'TriNet I – Accord Actuarial data' },
  { value: 1, label: 'TriNet II – SOI Actuarial data' },
  { value: 2, label: 'TriNet III – Passport Actuarial data', additional0info: 'Enter state split', additional0lable: 'NY;CA;FL;TX' },
  {
    value: 3, label: 'Manual Rates Progression - Monthly View', additional0info: 'Enter months back', additional0lable: '36',
    additional1info: 'Enter state split', additional1lable: 'NY;CA;FL;TX'
  },
  { value: 4, label: 'Risk Loss Report', additional0info: 'Enter Company ID', additional0lable: '' },
  { value: 5, label: 'Accounting – AIG' },
  { value: 6, label: 'Accounting – CNA' }
];
export const Allstates: Selection[] = [
  { value: 0, label: 'AL | Alabama' },
  { value: 1, label: 'AK | Alaska' },
  { value: 2, label: 'AZ | Arizona' },
  { value: 3, label: 'AR | Arkansas' },
  { value: 4, label: 'CA | California' },
  { value: 5, label: 'CO | Colorado' },
  { value: 6, label: 'CT | Connecticut' },
  { value: 7, label: 'DE | Delaware' },
  { value: 8, label: 'DC | District of Columbia' },
  { value: 9, label: 'FL | Florida' },
  { value: 10, label: 'GA | Georgia' },
  { value: 11, label: 'HI | Hawaii' },
  { value: 12, label: 'ID | Idaho' },
  { value: 13, label: 'IL | Illinois' },
  { value: 14, label: 'IN | Indiana' },
  { value: 15, label: 'IA | Iowa' },
  { value: 16, label: 'KS | Kansas' },
  { value: 17, label: 'KY | Kentucky' },
  { value: 18, label: 'LA | Louisiana' },
  { value: 19, label: 'ME | Maine' },
  { value: 20, label: 'MD | Maryland' },
  { value: 21, label: 'MA | Massachusetts' },
  { value: 22, label: 'MI | Michigan' },
  { value: 23, label: 'MN | Minnesota' },
  { value: 24, label: 'MS | Mississippi' },
  { value: 25, label: 'MO | Missouri' },
  { value: 26, label: 'MT | Montana' },
  { value: 27, label: 'NE | Nebraska' },
  { value: 28, label: 'NV | Nevada' },
  { value: 29, label: 'NH | New Hampshire' },
  { value: 30, label: 'NJ | New Jersey' },
  { value: 31, label: 'NM | New Mexico' },
  { value: 32, label: 'NY | New York' },
  { value: 33, label: 'NC | North Carolina' },
  { value: 34, label: 'ND | North Dakota' },
  { value: 35, label: 'OH | Ohio' },
  { value: 36, label: 'OK | Oklahoma' },
  { value: 37, label: 'OR | Oregon' },
  { value: 38, label: 'PA | Pennsylvania' },
  { value: 39, label: 'RI | Rhode Island' },
  { value: 40, label: 'SC | South Carolina' },
  { value: 41, label: 'SD | South Dakota' },
  { value: 42, label: 'TN | Tennessee' },
  { value: 43, label: 'TX | Texas' },
  { value: 44, label: 'UT | Utah' },
  { value: 45, label: 'VT | Vermont' },
  { value: 46, label: 'VA | Virginia' },
  { value: 47, label: 'WA | Washington' },
  { value: 48, label: 'WV | West Virginia' },
  { value: 49, label: 'WI | Wisconsin' },
  { value: 50, label: 'WY | Wyoming' },
  { value: 51, label: 'AS | American Samoa' },
  { value: 52, label: 'GU | Guam' },
  { value: 53, label: 'MP | Northern Mariana Islands' },
  { value: 54, label: 'PR | Puerto Rico' },
  { value: 55, label: 'VI | Virgin Islands' },
  { value: 56, label: 'UM | U.S. Minor Outlying Islands' },
  { value: 57, label: 'FM | Federated States of Micronesia' },
  { value: 58, label: 'MH | Marshall Islands' },
  { value: 59, label: 'PW | Palau' }
];
export const Productsmedicalall: Selection[] = [
  { value: 0, label: 'TriNet I – Accord' },
  { value: 1, label: 'TriNet II – SOI' },
  { value: 2, label: 'TriNet III – Passport' },
  { value: 3, label: 'TriNet IV – Ambrose' },
  { value: 4, label: 'TriNet XI – None medical' },
  { value: 5, label: 'All' }
];
export const ExchangesAllOptions: Selection[] = [
  { value: 0, label: 'TriNet I' },
  { value: 1, label: 'TriNet II' },
  { value: 2, label: 'TriNet III' },
  { value: 3, label: 'TriNet IV' },
  { value: 4, label: 'TriNet XI' },
  { value: 5, label: 'All' }
];
export const HealthCarriers: Selection[] = [
  { value: 0, label: 'AETNA' },
  { value: 1, label: 'UHC' },
  { value: 2, label: 'BCBSFL' },
  { value: 3, label: 'BSCA' },
  { value: 4, label: 'KAISER' },
  { value: 5, label: 'TUFTS' },
  { value: 6, label: 'BCBSNC' },
  { value: 7, label: 'BCBSMN' },
  { value: 8, label: 'EMPIRE' },
  { value: 9, label: 'BCID' },
  { value: 10, label: 'All' }
];
export const HealthCategories: Selection[] = [
  { value: 0, label: 'Medical' },
  { value: 1, label: 'Dental' },
  { value: 2, label: 'Vision' },
  { value: 3, label: 'Life' },
  { value: 4, label: 'Disability' }
];
export const DIHealthEligibility: Selection[] = [
  { value: 0, label: 'Before sending to Truven eligibility files' },
  { value: 1, label: 'Truven loaded eligibility data - Client ID level only' }
];
export const LevelOfDataAnalyses: Selection[] = [
  { value: 0, label: 'ID level' },
  { value: 1, label: 'State level' },
  { value: 2, label: 'Code level' },
  { value: 3, label: 'ID-State level' },
  { value: 4, label: 'ID-Code level' },
  { value: 5, label: 'Code-State level' },
  { value: 6, label: 'State-Code level' },
  { value: 7, label: 'ID-Code-State level' },
  { value: 8, label: 'ID-State-Code level' },
  { value: 9, label: 'NAICS level' },
  { value: 10, label: 'SIC level' },
  { value: 11, label: 'Main Vertical level' },
  { value: 12, label: 'Vertical level' },
  { value: 13, label: 'Sub Vertical level' },
  { value: 14, label: 'Product level' }
];
export const LevelOfDataAnalysesHealth: Selection[] = [
  { value: 0, label: 'Client id level' },
  { value: 1, label: 'Client id – plan level' }
];
export const LossStratificationOptions: Selection[] = [
  { value: 0, label: 'Incurred' },
  { value: 1, label: 'Capped Incurred' },
  { value: 2, label: 'Net Paid' },
  { value: 3, label: 'Paid' },
  { value: 4, label: 'Capped Net Paid' },
  { value: 5, label: 'Reserves' },
  { value: 6, label: 'Capped Reserves' },
  { value: 7, label: 'Recoveries' }
];
export const ActuarialTrianglesLevels: Selection[] = [
  { value: 0, label: 'All' },
  { value: 1, label: 'Products' },
  { value: 2, label: 'Subgroups' },
  { value: 3, label: 'Individuals' }
];
export const ActuarialTrianglesOptions: Selection[] = [
  { value: 0, label: 'None' },
  { value: 1, label: 'State' },
  { value: 2, label: 'Code' },
  { value: 3, label: 'State and Code' },
  { value: 4, label: 'Code and State' }
];
export const Months: Selection[] = [
  { value: 0, label: '1' },
  { value: 1, label: '2' },
  { value: 2, label: '3' },
  { value: 3, label: '4' },
  { value: 4, label: '5' },
  { value: 5, label: '6' },
  { value: 6, label: '7' },
  { value: 7, label: '8' },
  { value: 8, label: '9' },
  { value: 9, label: '10' },
  { value: 10, label: '11' },
  { value: 11, label: '12' }
];
export const YesNo: Selection[] = [
  { value: 0, label: 'Yes' },
  { value: 1, label: 'No' }
];
export const CarveOutOptions: Selection[] = [
  { value: 0, label: 'WC Covered' },
  { value: 1, label: 'None Covered' },
  { value: 2, label: 'All' }
];
export const AscendingDescending: Selection[] = [
  { value: 0, label: 'Ascending' },
  { value: 1, label: 'Descending' }
];
export const StatesOption: Selection[] = [
  { value: 0, label: 'Benefit state' },
  { value: 1, label: 'Accident state' }
];
export const PyCy: Selection[] = [
  { value: 0, label: 'Calendar year' },
  { value: 1, label: 'Policy year' }
];
export const ClaimsAmountsStructure: Selection[] = [
  { value: 0, label: 'Mixed' },
  { value: 1, label: 'Per claim' },
  { value: 2, label: 'Per occurrence' }
];
export interface Selection {
  value: number;
  label: string;
  additional0lable?: string;
  additional0info?: string;
  additional1lable?: string;
  additional1info?: string;
}
export interface MonthlyVariance {
  product?: string;
  qryname?: string;
  fdsyr?: number;
  fdsmm?: number;
  sdsyr?: number;
  sdsmm?: number;
  c?: string;
  username?: string;
  fingerprint?: string;
  filenamesummary?: string;
  filenamerawdata?: string;
  filenamesummaryshort?: string;
  filenamerawdatashort?: string;
  imageprocess?: string;
  timeframe?: string;
  env?: string;
  includerawdata?: string;
}
export interface WccsrSlim {
  username?: string;
  Product?: string;
  qryName?: string;
  AsOfYr?: number;
  AsOfMm?: number;
  ClaimsGrouping?: string;
  YearsOrder?: string;
  StatesOpt?: string;
  env?: string;
  c?: string;
  filenameshort?: string;
  imageprocess?: string;
  timeframe?: string;
}
export interface WagesReporting {
  username?: string;
  reportname?: string;
  product?: string;
  qryname?: string;
  asofyr?: number;
  asofmm?: number;
  mmsback?: number;
  id?: string;
  env?: string;
  c?: string;
  overwritedepository?: string;
  fingerprint?: string;
  imageprocess?: string;
  filenameshort?: string;
  filename?: string;
}
export interface LossRatio {
  mmsback?: number;
  asofyr?: number;
  asofmm?: number;
  qryname?: string;
  states?: string;
  capping?: string;
  grouping?: string;
  deductopt?: string;
  sources?: string;
  pyfy?: string;
  levelanalysis?: string;
  monthlydata?: string;
  cappingamount?: number;
  username?: string;
  c?: string;
  fingerprint?: string;
  filename?: string;
  filenameshort?: string;
  imageprocess?: string;
  timeframe?: string;
  env?: string;
  signalr?: string;
  channel?: string;
  eventname?: string;
}
export interface Renewal {
  exchange?: string;
  asofyr?: number;
  asofmm?: number;
  mmsback?: number;
  qryname?: string;
  username?: string;
  machine?: string;
  c?: string;
  env?: string;
  signalr?: string;
  channel?: string;
  eventname?: string;
  fingerprint?: string;
  imageprocess?: string;
}
export interface ESAC {
  product?: string;
  active?: string;
  activeemployees?: string;
  carveout?: string;
  states?: string;
  coids?: string;
  lastdate?: string;
  qryname?: string;
  username?: string;
  c?: string;
  env?: string;
  fileloaded?: string;
}
export interface PAW {
  product?: string;
  asofyr?: string;
  asofmm?: string;
  states?: string;
  coids?: string;
  qryname?: string;
  username?: string;
  c?: string;
  env?: string;
  fileloaded?: string;
}
export interface ActuarialTriangles {
  mmsback?: number;
  asofyr?: number;
  asofmm?: number;
  qryname?: string;
  states?: string;
  capping?: string;
  grouping?: string;
  deductopt?: string;
  sources?: string;
  pyfy?: string;
  levelanalysis?: string;
  monthlydata?: string;
  cappingamount?: number;
  username?: string;
  c?: string;
  fingerprint?: string;
  filename?: string;
  filenameshort?: string;
  imageprocess?: string;
  timeframe?: string;
  env?: string;
}
export interface LossStratification {
  mmsback?: number;
  asofyr?: number;
  asofmm?: number;
  qryname?: string;
  states?: string;
  capping?: string;
  grouping?: string;
  deductopt?: string;
  sources?: string;
  pyfy?: string;
  levelanalysis?: string;
  monthlydata?: string;
  cappingamount?: number;
  username?: string;
  c?: string;
  fingerprint?: string;
  filename?: string;
  filenameshort?: string;
  imageprocess?: string;
  timeframe?: string;
  env?: string;
}
export interface ThirdPartyDeliverables {
  qryname?: string;
  deliverable?: string;
  asofyr?: number;
  asofmm?: number;
  statesplit?: string;
  monthsback?: string;
  username?: string;
  c?: string;
  env?: string;
  fingerprint?: string;
  process?: string;
  imageprocess?: string;
}
export interface WageAnalysis {
  sources?: string;
  asofyrfds?: number;
  asofmmfds?: number;
  asofyrsds?: number;
  asofmmsds?: number;
  levelanalysis?: string;
  mmsback?: number;
  qryname?: string;
  username?: string;
  c?: string;
  env?: string;
  fingerprint?: string;
  process?: string;
  imageprocess?: string;
}
export interface GetData {
  product?: string;
  option?: string;
  asofyr?: number;
  asofmm?: number;
  mmsback?: number;
  qryname?: string;
  username?: string;
  c?: string;
  c2?: string;
  fingerprint?: string;
  filename?: string;
  filenameshort?: string;
  imageprocess?: string;
  timeframe?: string;
  env?: string;
  sheetname?: string;
  signalr?: string;
  channel?: string;
  eventname?: string;
}
export interface InternalPricing {
  product?: string;
  qryname?: string;
  asofyr?: number;
  asofmm?: number;
  mmsback?: number;
  states?: string;
  cappingamount?: number;
  c?: string;
  username?: string;
  fingerprint?: string;
  filename?: string;
  filenameshort?: string;
  imageprocess?: string;
  timeframe?: string;
  env?: string;
}
export interface Wccsr {
  qryname?: string;
  asofyr?: number;
  asofmm?: number;
  groupopt?: string;
  deductopt?: string;
  ldfopt?: string;
  capopt?: number;
  maxamount?: number;
  incrstep?: number;
  yearsorder?: string;
  statesopt?: string;
  statesoptstr?: string;
  statesallaos?: string;
  switchopt?: string;
  legalopt?: string;
  includelossratio?: string;
  includecalendaryear?: string;
  dlst?: string;
  dlend?: string;
  username?: string;
  env?: string;
  c?: string;
  fingerprint?: string;
  filename?: string;
  filenameshort?: string;
  imageprocess?: string;
  timeframe?: string;
}

export const routs: any[] = [
  { url: 'riskfinance' }, { url: 'lossratio' }, { url: 'monthlyvariance' }
];

export interface UserInfo {
  module: string;
  name: string;
  email: string;
  rights: string;
  machine: string;
  signalrconnectionid: string;
}
export interface FooterInfo {
  email?: string;
  text?: string;
  modulesender?: string;
  subjectline?: string;
}
//////////////////// Maps
export interface Map {
  element?: any;
  width?: number;
  height?: number;
  margin?: any;
  option?: string;
  urlMap?: string;
  urlCSV0?: string;
  urlCSV1?: string;
  multiplicator?: number;
  color?: string;
  colorindex?: number;
  multiplicatorClient?: number;
  colorClient?: string;
  svgId?: string;
  mapkey?: string;
  nycCenterX?: number;
  nycCenterY?: number;
  nycRotateX?: number;
  nycRotateY?: number;
  nycTranslateW?: number;
  nycTranslateH?: number;
  nycScale?: number;
  nycBorough?: string;
  mapNameCache?: string;
}

export const mapProduct: string[] = [
  'All',
  'Passport',
  'SOI',
  'Accord',
  'Ambrose',
  'Passport & Ambrose',
  'Passport & Accord',
  'Passport & SOI',
  'SOI & Accord',
  'SOI & Ambrose',
  'Accord & Ambrose',
  'Passport & SOI & Accord',
  'Passport & SOI & Ambrose',
  'Passport & Accord & Ambrose',
  'SOI & Accord & Ambrose'
];

export interface CleanFileAndServer {
  fullfilename: string;
  qryname: string;
  c: string;
}
export class UsersNavigationDataLoad {
  private allowedusers: string[] = ['Lyudmil Petrov', 'Hema Ganesh'];
  protected name: string;
  constructor(name: string) { this.name = name; }
  public allowed = false;
  public CheckIfAllowed(): string[] {
    // return this.allowedusers.filter(v => (v = this.name ? 'true' : 'false') )[0];
    return this.allowedusers.filter(v => {
      if (v === this.name) {
        this.allowed = true;
        return v;
      }
    }
    );
  }
}
export interface PreloadedIDsInfoProcess {
  process?: string;
  clientid?: string;
  fileloaded?: string;
  product?: string;
  server?: string;
  startdate?: string;
  enddate?: string;
  firsttimerunprocess?: string;
  qryname?: string;
  username?: string;
  c?: string;
  env?: string;
  channel?: string;
  eventname?: string;
  signalr?: string;
}
export interface ActuarialWCModelReport {
  asofyr?: number;
  asofmm?: number;
  mmsback?: number;
  states?: string;
  pasdlr?: string;
  soidlr?: string;
  acddlr?: string;
  ambdlr?: string;
  trendfactor?: string;
  safetyincentiveplan?: string;
  internalexpenses?: string;
  surplusarray?: string;
  minallowableratechange?: string;
  maxallowableratechange?: string;
  includerawdata?: string;
  qryname?: string;
  username?: string;
  c?: string;
  env?: string;
  fingerprint?: string;
  imageprocess?: string;
}
export interface VizIncomingInitialInfo {
  Product: string;
  InfoToPresent: string;
  ID: string;
  StartDate: string;
  EndDate: string;
  Source: string;
  Option1: string;
  Option2: string;
  qryname: string;
  username: string;
  c: string;
  env: string;
  transportedinfo: string[];
}
export interface WebWorkerData {
  id: number;
  action: string;
  data: object;
}
export interface ElementDiv {
  height: number;
  width: number;
}
