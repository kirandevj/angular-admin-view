import { Component, Input, Output, EventEmitter, OnInit, Optional, SkipSelf, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { PreLoadedServices, IPreLoadedProcess } from './pre-loaded.services';
import { GlobalVariables, SharedServices } from '../../../app/common/shared.service';
import { Selection, UserInfo, CleanFileAndServer } from '../../../app/datamodels/index';

@Component({
  selector: './app-pre-loaded',
  templateUrl: './pre-loaded.html',
  styleUrls: ['./pre-loaded.css']
})
export class PreLoadedComponent implements OnInit, OnChanges {
  @Input() sentFromUser: IPreLoadedProcess;
  outputmessage: string;
  @Output() outputmessageEvent = new EventEmitter<string[]>();
  IDs: string;
  PlaceHolderIDs: string;
  Products: Array<Selection>;
  PlaceholderProducts: string;
  startdate: Date;
  enddate: Date;
  FirstTimes: Array<Selection>;
  PlaceholderFirstTimes: string;
  showspinner: boolean;
  filenames: string[];
  showfile: boolean;
  showbuttontoprocess: boolean;
  sendtofileloadermessages: any[] = ['', false];
  filetobeprocess: string;
  form: FormGroup;
  server: string;
  image0: string;
  image1: string;
  Servers: Array<Selection>;
  PlaceholderServers: string;
  transportedinfo: string[] = [];
  user: UserInfo;
  constructor(@Optional() @SkipSelf() parentModule: PreLoadedComponent,
    private ps: PreLoadedServices,
    private gv: GlobalVariables,
    private ss: SharedServices
  ) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
  }
  ngOnChanges(changes: SimpleChanges) {
    this.updateProcess();
    this.transportedinfo = this.sentFromUser.transportedinfo;
  }
  ngOnInit() {
    this.updateProcess();
  }
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
    this.filetobeprocess = this.filenames[0];
  }
  RunProcess(formValues: any) {
    const rr: IPreLoadedProcess = {
      process: this.sentFromUser.process,
      clientid: (this.ss.getFormValueInputImproved(document.getElementById('idn')['value'], '')).toLocaleUpperCase(),
      fileloaded: this.filetobeprocess,
      server: this.ss.getFormValue(formValues.Server, this.PlaceholderServers, this.Servers, 'value', 'label'),
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label'),
      startdate: this.ss.getDateFromHTMLInput(document.getElementById('startdate')['value']),
      enddate: this.ss.getDateFromHTMLInput(document.getElementById('enddate')['value']),
      qryname: this.sentFromUser.qryname,
      username: this.sentFromUser.username,
      c: this.sentFromUser.c,
      env: this.sentFromUser.env,
      signalr: this.sentFromUser.signalr,
      channel: this.sentFromUser.channel,
      eventname: this.sentFromUser.eventname,
      transportedinfo: this.transportedinfo
    };
    console.log(rr);
    this.showbuttontoprocess = true;
    this.getPreloadedIDsInfoProcess(rr);
  }
  getPreloadedIDsInfoProcess(v: IPreLoadedProcess) {
    this.ps.getPreloadedIDsInfoProcess(this.server, v)
      .subscribe(
        res => {
          // console.log(res);
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              ///////////////////////// Cleaning server and web folder
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              ///////////////////////// Cleaning all - web and oracle - END
            }, err => { });
        },
        err => {
          // // console.log(err);
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
        });
  }
  updateProcess() {
    this.startdate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.enddate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.startdate.setMonth(this.enddate.getMonth() - this.sentFromUser.mmsback);
    // this.startdate.setDate(this.startdate.getDate());
    document.getElementById('startdate')['valueAsDate'] = this.startdate;
    document.getElementById('enddate')['valueAsDate'] = this.enddate;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('ID', new FormControl());
    this.IDs = 'Enter Company ID';
    this.PlaceHolderIDs = this.IDs;
    this.form.addControl('Product', new FormControl());
    this.Products = this.ss.getProductsAllExtended();
    if (typeof this.sentFromUser.product !== 'undefined') {
      this.PlaceholderProducts = this.Products[+this.sentFromUser.product].label;
    } else {
      this.PlaceholderProducts = this.Products[0].label;
    }
    this.form.addControl('Server', new FormControl());
    this.Servers = this.ss.getServers();
    this.PlaceholderServers = this.Servers[0].label;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = false;
    this.showbuttontoprocess = false;
    this.form.addControl('FirstTime', new FormControl());
    this.FirstTimes = this.ss.getYesNo();
    this.PlaceholderFirstTimes = this.FirstTimes[0].label;
  }
}
