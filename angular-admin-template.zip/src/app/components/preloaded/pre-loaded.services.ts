import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
    HttpClient,
    HttpRequest,
    HttpEvent,
    HttpEventType,
    HttpHeaders
} from '@angular/common/http';
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';

@Injectable()
export class PreLoadedServices {
    constructor(private http: HttpClient) { }
    getPreloadedIDsInfoProcess(api: string, v: IPreLoadedProcess): Observable<string[]> {
        const apiPoint = api + 'api/MainAPI?preloadedidsinfoprocess=preloadedidsinfoprocess';
        return this.http.post(apiPoint, v).pipe(map((r: string[]) => {
            // // console.log('observable returning');
            // // console.log(r);
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
}
export interface IPreLoadedProcess {
    process?: string;
    clientid?: string;
    fileloaded?: string;
    product?: string;
    server?: string;
    startdate?: string;
    enddate?: string;
    qryname?: string;
    username?: string;
    c?: string;
    env?: string;
    mmsback?: number;
    signalr?: string;
    channel?: string;
    eventname?: string;
    firsttimerun?: string;
    transportedinfo?: string[];
}
