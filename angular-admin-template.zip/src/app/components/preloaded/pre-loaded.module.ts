import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { SelectModule } from 'angular2-select';
import { PreLoadedComponent } from './pre-loaded.component';
import { PreLoadedServices } from './pre-loaded.services';
import { FileActionModule } from '../files/file-action.module';
import { SpinnerModule } from '../spinner/spinner.module';

@NgModule({
    imports: [
        ReactiveFormsModule,
        FormsModule,
        CommonModule,
        // SelectModule,
        SpinnerModule,
        FileActionModule
    ],
    declarations: [PreLoadedComponent],
    providers: [PreLoadedServices],
    exports: [
        PreLoadedComponent
    ]
})

export class PreLoadedModule {

}
