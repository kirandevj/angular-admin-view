import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
    HttpClient,
    HttpRequest,
    HttpEvent,
    HttpEventType,
    HttpHeaders
} from '@angular/common/http';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap, delay } from 'rxjs/operators';

@Injectable()
export class FileServices {
    constructor(private http: HttpClient) { }
    postFile2(api: string, fileToUpload: File): void {
        const apiPoint = api + 'api/fileservice';
        const formData: FormData = new FormData();
        formData.append('fileKey', fileToUpload, fileToUpload.name);

        const req = new HttpRequest('POST', api, {
            reportProgress: true,
            responseType: 'json',
            body: formData
        });

        this.http.request(req).subscribe((event: HttpEvent<any>) => {
            switch (event.type) {
                case HttpEventType.Sent:
                    // console.log('Request sent!');
                    break;
                case HttpEventType.ResponseHeader:
                    // console.log('Response header received!');
                    break;
                case HttpEventType.DownloadProgress:
                    const kbLoaded = Math.round(event.loaded / 1024);
                    // console.log(`Download in progress! ${kbLoaded}Kb loaded`);
                    break;
                case HttpEventType.Response:
                    // console.log('one!', event.body);
            }
        });

        ////////////////////////////////////

    }
    postFile(api: string, fileToUpload: File): Observable<object> {
        const apiPoint = api + 'api/fileaction';
        const formData: FormData = new FormData();
        // // // console.log(formData);
        // this.postFile2(api, fileToUpload);
        formData.append('fileKey', fileToUpload, fileToUpload.name);
        // formData.append('username', 'Groucho');
        // return this.http.post(apiPoint, formData, { observe: 'response' }).map((r: HttpEvent<any>) => {
        //     return r;
        // }).catch((e: any) => Observable.throw(e || 'Server error'));
        return this.http.post(apiPoint, formData, { observe: 'response' }).pipe(map((r: HttpEvent<any>) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    deleteFile(api: string, fileToDelete: string): Observable<object> {
        // // console.log('deleting now');
        // // console.log(api);
        const apiPoint = api + 'api/fileaction/' + fileToDelete;
        // // console.log(apiPoint);
        // return this.http.delete(apiPoint).map((r: Response) => {
        //     // // console.log(r);
        //     return r;
        // }
        // ).catch((e: any) => Observable.throw(e || 'Server error'));
        return this.http.delete(apiPoint).pipe(map((r: Response) => {
            // // console.log(r);
            return r;
        }
        ), catchError((e: any) => {
            // // console.log(e);
            return Observable.throw(e);
        }));

    }
    loadFile(api: string, fileToLoad: IFileProcess): Observable<IFileProcess> {
        const apiPoint = api + 'api/FileAction?action=action';
        return this.http.post(apiPoint, fileToLoad).pipe(map((r: IFileProcess) => {
            // // console.log(r);
            return r;
        }
        ), catchError((e: any) => {
            // // console.log(e);
            return Observable.throw(e);
        }));

    }
    // loadFileToServer(api: string, fileToLoadToServer: string, servertabel: string): Observable<Object> {
    //     const apiPoint = api + 'api/fileservice/loadtoserver/' + fileToLoadToServer + '/' + servertabel;
    //     return this.http.post(apiPoint, servertabel).map((r: Response) => {
    //         return r;
    //     }
    //     ).catch((e: any) => Observable.throw(e || 'Server error'));
    // }
}
export interface IFileProcess {
    modulecaller: string;
    username: string;
    servertable: string;
    machine: string;
    shortfilename: string;
    fileextension: string;
    fullfilename: string;
    action: string;
    result: string;
    env: string;
    c: string;
    channel: string;
    eventname: string;
    signalr: string;
    as_of_yr: number;
    as_of_mm: number;
}
