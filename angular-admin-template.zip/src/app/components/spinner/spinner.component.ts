import { Component, Input, OnInit, Optional, SkipSelf } from '@angular/core';
import { SpinnerServices } from './spinner.service';

@Component({
  selector: './app-spinner',
  templateUrl: './spinner.html',
  styleUrls: ['./spinner.component.css']
})
export class SpinnerComponent implements OnInit {
  @Input() showspinner: boolean;

  constructor(@Optional() @SkipSelf() parentModule: SpinnerComponent,
              private fs: SpinnerServices
  ) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
  }
  ngOnInit() { }
}
