import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { SelectModule } from 'angular2-select';
import { ChartBaseComponent } from './chart-base/chart-base.component';
import { ChartServices } from './chart.services';


@NgModule({
    imports: [
        ReactiveFormsModule,
        FormsModule,
        CommonModule
    ],
    declarations: [ChartBaseComponent],
    providers: [ChartServices],
    exports: [
        ChartBaseComponent
    ]
})

export class ChartModule {

}
