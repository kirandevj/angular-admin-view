import { Injectable, Inject } from '@angular/core';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
export class SignalrWindow0 extends Window {
    $: any;
}
export enum ConnectionState0 {
    Connecting = 1,
    Connected = 2,
    Reconnecting = 3,
    Disconnected = 4
}

export class ChannelConfig0 {
    urlName: string;
    subUrlName: string;
    hubName: string;
    channelName: string;
    callerName: string;
}

export class ChannelEvent0 {
    Name: string;
    ChannelName: string;
    Timestamp: Date;
    Data: any;
    Json: string;
    constructor() {
        this.Timestamp = new Date();
    }
}

class ChannelSubject0 {
    channel: string;
    subject: Subject<ChannelEvent0>;
}
@Injectable()
export class ChannelService0 {
    private _hubName: string;
    private _urlName: string;
    private _channelName: string;
    private _callerName: string;
    /**
     * starting$ is an observable available to know if the signalr
     * connection is ready or not. On a successful connection this
     * stream will emit a value.
     */
    starting$: Observable<any>;
    /**
     * connectionState$ provides the current state of the underlying
     * connection as an observable stream.
     */
    connectionState$: Observable<ConnectionState0>;
    /**
     * error$ provides a stream of any error messages that occur on the
     * SignalR connection
     */
    error$: Observable<string>;
    // These are used to feed the public observables
    //
    private connectionStateSubject = new Subject<ConnectionState0>();
    private startingSubject = new Subject<any>();
    private errorSubject = new Subject<any>();

    // These are used to track the internal SignalR state
    //
    private hubConnection: any;
    private hubProxy: any;
    // An internal array to track what channel subscriptions exist
    //
    private subjects = new Array<ChannelSubject0>();

    constructor(
        @Inject(SignalrWindow0) private window: SignalrWindow0,
        @Inject('channel.config') private channelConfig: ChannelConfig0
    ) {
        if (this.window.$ === undefined || this.window.$.hubConnection === undefined) {
            throw new Error(`The variable \'$\' or the .hubConnection() function are not defined...please check the SignalR
            scripts have been loaded properly`);
        }
        // Set up our observables
        //
        this.connectionState$ = this.connectionStateSubject.asObservable();
        this.error$ = this.errorSubject.asObservable();
        this.starting$ = this.startingSubject.asObservable();

        this.hubConnection = this.window.$.hubConnection();
        this.hubConnection.url = channelConfig.urlName + channelConfig.subUrlName;
        this.hubProxy = this.hubConnection.createHubProxy(channelConfig.hubName);

        // Define handlers for the connection state events
        //
        this.hubConnection.stateChanged((state: any) => {
            // // console.log(state);
            let newState = ConnectionState0.Connecting;
            switch (state.newState) {
                case this.window.$.signalR.connectionState.connecting:
                    newState = ConnectionState0.Connecting;
                    break;
                case this.window.$.signalR.connectionState.connected:
                    newState = ConnectionState0.Connected;
                    break;
                case this.window.$.signalR.connectionState.reconnecting:
                    newState = ConnectionState0.Reconnecting;
                    break;
                case this.window.$.signalR.connectionState.disconnected:
                    newState = ConnectionState0.Disconnected;
                    break;
            }
            // Push the new state on our subject
            this.connectionStateSubject.next(newState);
        });

        // Define handlers for any errors
        this.hubConnection.error((error: any) => {
            // Push the error on our subject
            this.errorSubject.next(error);
        });

        this.hubProxy.on('onEvent', (channel: string, ev: ChannelEvent0) => {
            // This method acts like a broker for incoming messages. We
            //  check the interal array of subjects to see if one exists
            //  for the channel this came in on, and then emit the event
            //  on it. Otherwise we ignore the message.
            //
            const channelSub = this.subjects.find((x: ChannelSubject0) => {
                return x.channel === channel;
            }) as ChannelSubject0;
            // If we found a subject then emit the event on it
            if (channelSub !== undefined) {
                return channelSub.subject.next(ev);
            }
        });

        // Let's wire up to the signalr observables
        this.connectionState$ = this.connectionState$
            .pipe(map((state: ConnectionState0) => {
                // // console.log(state);
                return state;
            }));

        this.error$.subscribe(
            (error: any) => { console.warn(error); },
            (error: any) => { console.error('errors$ error', error); }
        );
        // Wire up a handler for the starting$ observable to log the
        //  success/fail result

        this.starting$.subscribe(
            () => {
                // console.log('signalr service has been started from signalr-service-api');
            },
            () => {
                console.warn('signalr service failed to start from signalr-service-api');
            }
        );

    }

    get(variableName: string): string {
        return this[variableName];
    }
    set(variableName: string, variableValue: string): string[] {
        const temp = this[variableName];
        this[variableName] = variableValue;
        return [temp, variableValue];
    }
    setHubUrl(url: string): void {
        this.hubConnection.url = url;
    }
    getHubUrl(): string {
        return this.hubConnection.url;
    }
    /**
     * Start the SignalR connection. The starting$ stream will emit an
     * event if the connection is established, otherwise it will emit an
     * error.
     */
    start(): Observable<ChannelEvent0> {
        // // console.log('Firing up signal R');
        // // console.log(ChannelEvent0);
        const obsr = Observable.create(observer => {
            // this.hubConnection.logging = true;
            this.hubConnection.start()
                .done(() => {
                    // const innerobsr = this.sub(this.channelConfig.channelName).subscribe(
                    this.sub(this.channelConfig.channelName).subscribe(
                        (x: ChannelEvent0) => {
                            // // console.log(x);
                            observer.next(x);
                            observer.complete();
                        },
                        (error: any) => {
                            observer.error(status);
                        }
                    );
                    this.startingSubject.next();
                    // // // console.log(innerobsr);
                    // return innerobsr;
                })
                .fail((error: any) => {
                    this.startingSubject.error(error);
                });
        });
        return obsr;
    }
    /**
     * Get an observable that will contain the data associated with a specific
     * channel
     */
    sub(channel: string): Observable<ChannelEvent0> {
        // Try to find an observable that we already created for the requested
        //  channel
        //
        // // console.log('sub called');
        // // console.log(this.subjects);
        let channelSub = this.subjects.find((x: ChannelSubject0) => {
            return x.channel === channel;
        }) as ChannelSubject0;

        // If we already have one for this event, then just return it
        //
        if (channelSub !== undefined) {
            // // console.log(`Found existing observable for ${channel} channel`);
            return channelSub.subject.asObservable();
        }

        //
        // If we're here then we don't already have the observable to provide the
        //  caller, so we need to call the server method to join the channel
        //  and then create an observable that the caller can use to received
        //  messages.
        //

        // Now we just create our internal object so we can track this subject
        //  in case someone else wants it too
        //
        channelSub = new ChannelSubject0();
        channelSub.channel = channel;
        channelSub.subject = new Subject<ChannelEvent0>();
        this.subjects.push(channelSub);

        // Now SignalR is asynchronous, so we need to ensure the connection is
        //  established before we call any server methods. So we'll subscribe to
        //  the starting$ stream since that won't emit a value until the connection
        //  is ready
        //
        this.starting$.subscribe(() => {
            this.hubProxy.invoke('Subscribe', channel)
                .done(() => {
                    // // console.log(`Successfully subscribed to ${channel} channel`);
                })
                .fail((error: any) => {
                    channelSub.subject.error(error);
                });
        },
            (error: any) => {
                channelSub.subject.error(error);
            });

        return channelSub.subject.asObservable();
    }

    // Not quite sure how to handle this (if at all) since there could be
    //  more than 1 caller subscribed to an observable we created
    //
    // unsubscribe(channel: string): Rx.Observable<any> {
    //     this.observables = this.observables.filter((x: ChannelObservable) => {
    //         return x.channel === channel;
    //     });
    // }

    /** publish provides a way for calles to emit events on any channel. In a
     * production app the server would ensure that only authorized clients can
     * actually emit the message, but here we're not concerned about that.
     */
    publish(ev: ChannelEvent0): void {
        this.hubProxy.invoke('Publish', ev);
    }

    invokeServerMethod(method: string, messageToBeSent: string): void {
        const connection = this.window.$.hubConnection();
        connection.url = this.channelConfig.urlName + this.channelConfig.subUrlName;
        const ChatHubProxy = connection.createHubProxy(this.channelConfig.hubName);
        ChatHubProxy.logging = true;
        ChatHubProxy.on(method, (name: string, message: string) => {
            // console.log(name + ' ' + message);
        });
        connection.start().done(() => {
            // console.log(connection);
            ChatHubProxy.invoke(method, 'name here', messageToBeSent);
        });
    }
}
