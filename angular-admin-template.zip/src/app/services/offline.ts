import { HostListener, Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { AsyncSubject } from 'rxjs';

@Injectable()
export class OfflineService {
    private offlineSource = new AsyncSubject();

    offline$ = this.offlineSource.asObservable();
    constructor() {
        try {
            window.addEventListener('online', (event) => this.onChange(event));
            window.addEventListener('offline', (event) => this.onChange(event));
            // // console.log('Initializing the class - called first time to attache observable function for offline/online event');
        }
        // tslint:disable-next-line:one-line
        catch (e) {
        }
    }
    onChange($event?: any) {

        // // console.log($event['type']);
        return $event['type'];
    }
}


