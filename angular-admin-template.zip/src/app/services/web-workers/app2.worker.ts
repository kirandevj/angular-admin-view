
// <reference lib="webworker" />
// addEventListener('message', ({ data }) => {
//   const response = `worker response to ${data}`;
//   // const m: UserInfo = data;
//   postMessage(data);
// });
// function fibonacci(n: UserInfo): number {
//   let r = 0;
//   if (n === 1 || n === 2) {
//     r = 1;
//   } else {
//     r = fibonacci(n - 1) + fibonacci(n - 2);
//     // // console.log(r);
//   }
//   return r;
// }
