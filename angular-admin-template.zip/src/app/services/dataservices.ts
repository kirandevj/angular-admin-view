
import { throwError as observableThrowError, Observable, from, BehaviorSubject, Subject, Subscription, AsyncSubject } from 'rxjs';
import { Injectable, Optional, SkipSelf } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Injectable({ providedIn: 'root' })
export class DataService {
    NAICS: NAICSInfo[] = [];
    private NAICSInit = new BehaviorSubject<NAICSInfo[]>(this.NAICS);
    currentNAICS = this.NAICSInit.asObservable();
    RATE_BOOK_II: RateBookInfo[] = [];

    private RATE_BOOK_IIInit = new BehaviorSubject<RateBookInfo[]>(this.RATE_BOOK_II);

    currentRATE_BOOK_II = this.RATE_BOOK_IIInit.asObservable();
    RATE_BOOK_III: RateBookInfo[] = [];

    private RATE_BOOK_IIIInit = new BehaviorSubject<RateBookInfo[]>(this.RATE_BOOK_III);

    currentRATE_BOOK_III = this.RATE_BOOK_IIIInit.asObservable();
    RATE_BOOK_IV: RateBookInfo[] = [];

    private RATE_BOOK_IVInit = new BehaviorSubject<RateBookInfo[]>(this.RATE_BOOK_IV);

    currentRATE_BOOK_IV = this.RATE_BOOK_IVInit.asObservable();
    getObservableObjects(keyname: string) {
        return JSON.stringify(this[keyname]);
    }
    fillObservableObjects(keyname: string, arrobj: string) {
        this[keyname] = JSON.parse(arrobj);
        if (typeof this[keyname + 'Init'] !== 'undefined') {
            this[keyname + 'Init'].next(this[keyname]);
        }
    }
}
export interface NAICSInfo {
    NAICS_CODE: string;
    NAICS_DESC: string;
}
export interface RateBookInfo {
    RATENUMBER: string;
    STATE: string;
    WCCODE: string;
    COMBO: string;
    INCREASERATE: number;
    MANUALRATE: number;
    RETAILRATE: number;
    NEWCOSTRATE: number;
}
export interface RateCalculator {
    FEIN: string;
    RISKID: string;
    CARRIER: string;
    EXCHANGESTR: string;
    STCODE: string;
    WAGES: number;
    BASERATE: number;
    ESTIMATEDAP: number;
    MOD_STR: number;
    TOTALSTATECOST: number;
    ESTIMATEDAP_MODIFIED: number;
    TOTALSTATECOSTPERCODE: number;
    MODIFIEDNETRATE: number;
    TRINETRETAILRATE: number;
    TRINETMODIFIEDRETAILRATE: number;
    DISCOUNTNEEDEDTOMATCH: number;
    ANNUALFEEATRETAIL: number;
    ANNUALFEEATMATCHEDRATE: number;
    STATETOTALINDICATOR: boolean;
    STATEFIRSTINDICATOR: boolean;
    STATETOTALSTRING: string;
    USERNAME: string;
    TIMEPERIOD: string;
    ORDER_ID: number;
}
