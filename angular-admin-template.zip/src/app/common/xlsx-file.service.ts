import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
// import * as XLSX from 'xlsx';
// import { read, IWorkBook, IWorkSheet, utils } from 'ts-xlsx';
import { Observable, Subject, Subscription } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()

export class ExcelServices {
    private filesSubject: Subject<File>;
    private subscription: Subscription;
    private _uploadedXls: Observable<UploadResult>;
    constructor(private http: HttpClient) { }

}
export interface UploadResult {
    result: 'failure' | 'success';
    payload: any;
}
