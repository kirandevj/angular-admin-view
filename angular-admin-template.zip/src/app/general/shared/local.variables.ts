import { Injectable } from '@angular/core';

@Injectable()
export class LocalVariables {
    public _getdata: Array<RunProcess> = [];
    get(key: string) {
        const r = this['_' + key];
        return r;
    }
    add(key: string, value: object, fingerprint: string): void {
        let exists = false;
        this['_' + key].forEach((e: RunProcess) => {
            if (e.object.fingerprint === fingerprint) {
                exists = true;
            }
        });
        if (!exists) {
            this['_' + key].push(value);
        }
    }
    remove(key: string, fingerprint: string): void {
        this['_' + key].forEach((e: RunProcess, i: number) => {
            if (e.object.fingerprint === fingerprint) {
                this['_' + key].splice(i, 1);
            }
        });
    }
}
export class RunProcess {
    name: string;
    run: boolean;
    object: RunProcessObject;
}

interface RunProcessObject {
    mmsback?: number;
    asofyr?: number;
    asofmm?: number;
    qryname?: string;
    states?: string;
    capping?: string;
    grouping?: string;
    deductopt?: string;
    sources?: string;
    pyfy?: string;
    levelanalysis?: string;
    monthlydata?: string;
    cappingamount?: number;
    name?: string;
    c?: string;
    fingerprint?: string;
    filename?: string;
    filenameshort?: string;
    imageprocess?: string;
    timeframe?: string;
    env?: string;
}

