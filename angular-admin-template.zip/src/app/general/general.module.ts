import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
// import { SelectModule } from 'angular2-select';
import { PreLoadedModule } from '../components/preloaded/pre-loaded.module';
import { GENNavBarComponent } from './nav/gen-navbar.component';
import { GENComponent } from './general.component';
import { GENRoutes } from './general.routes';
import { GENServices } from './shared/gen.services';
import { ApiServices } from '../../app/common/index';
import { LocalVariables } from './shared/local.variables';
import { FooterModule } from '../../app/common/index';
import { SpinnerModule } from '../../app/common/index';
import { SharedServices } from '../../app/common/index';
import { ESACComponent } from './esac/esac.component';
import { CanadaComponent } from './canada/canada.component';
import { PAWComponent } from './paw/paw.component';
// import { RiskFinanceServices } from '@app/riskfinance/shared/risk-finance.service';
import { ProgressInfoModule } from '../../app/components/progress-info/progress-info.module';

import { HttpClientModule } from '@angular/common/http';
import { GlobalVariables} from '../../app/common/shared.service';
import {ChannelService,SignalrWindow} from '../services/channel.sevice'
@NgModule({
  imports: [
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(GENRoutes),
    // SelectModule,
    FooterModule,
    SpinnerModule,
    PreLoadedModule,
    ProgressInfoModule
  ],
  declarations: [
    GENNavBarComponent,
    GENComponent,
    ESACComponent,
    PAWComponent,
    CanadaComponent
  ],
  providers: [
    GENServices,
    ApiServices,
    LocalVariables,
    SharedServices,
    GlobalVariables,
    ChannelService,
    SignalrWindow
    // RiskFinanceServices
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class GeneralModule {
  // selectedPro(): any {
  // }
}
