import { GENComponent } from './general.component';
import { ESACComponent } from './esac/esac.component';
import { PAWComponent } from './paw/paw.component';
import { CanadaComponent } from './canada/canada.component';
export const GENRoutes = [
    { path: '', component: GENComponent },
    { path: 'esac', component: ESACComponent },
    { path: 'canada', component: CanadaComponent },
    { path: 'paw', component: PAWComponent }
];
