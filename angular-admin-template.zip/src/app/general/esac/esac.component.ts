import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { GENServices } from '../shared/gen.services';
import { SharedServices, GlobalVariables } from '../../../app/common/index';
import { ActivatedRoute } from '@angular/router';
import { ESAC, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '../../../app/datamodels/index';
import { LocalVariables } from '../shared/local.variables';
@Component({
  templateUrl: './esac.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class ESACComponent implements OnInit {
  user: UserInfo;
  server: string;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Products: Array<Selection>;
  Actives: Array<Selection>;
  ActiveEmployees: Array<Selection>;
  Carveouts: Array<Selection>;
  PlaceholderProducts: string;
  PlaceholderActives: string;
  PlaceholderActiveEmployees: string;
  PlaceholderCarveouts: string;
  PlaceholderStates: string;
  PlaceholderCOIDs: string;
  image0: string;
  showspinner: boolean;
  constructor(private rfs: GENServices, private ss: SharedServices,
    private gv: GlobalVariables) { }
  ngOnInit() {
    this.showspinner = false;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.server = this.gv.get('api', 'api');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Active', new FormControl());
    this.form.addControl('ActiveEmployee', new FormControl());
    this.form.addControl('Carveout', new FormControl());
    this.form.addControl('State', new FormControl());
    this.form.addControl('COID', new FormControl());
    this.Products = this.ss.getProductsMedicalAll();
    this.Actives = this.ss.getYesNo();
    this.ActiveEmployees = this.ss.getYesNo();
    this.Carveouts = this.ss.getCarveOutOptions();
    this.PlaceholderProducts = this.Products[0].label;
    this.PlaceholderActives = this.Actives[0].label;
    this.PlaceholderActiveEmployees = this.ActiveEmployees[0].label;
    this.PlaceholderCarveouts = this.Carveouts[0].label;
    this.PlaceholderStates = '';
    this.PlaceholderCOIDs = '';
    document.getElementById('lastdate')['valueAsDate'] = new Date();
  }
  onSubmit(formValues: any) {
    const r: ESAC = {
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label'),
      active: this.ss.getFormValue(formValues.Active, this.PlaceholderActives, this.Actives, 'value', 'label'),
      activeemployees: this.ss.getFormValue(formValues.ActiveEmployee, this.PlaceholderActiveEmployees,
        this.ActiveEmployees, 'value', 'label'),
      carveout: this.ss.getFormValue(formValues.Carveout, this.PlaceholderCarveouts, this.Carveouts, 'value', 'label'),
      states: this.PlaceholderStates,
      coids: this.PlaceholderCOIDs,
      lastdate: this.ss.getDateFromHTMLInput(document.getElementById('lastdate')['value']),
      qryname: this.ss.getQueryName('E', 'C', 0),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      fileloaded: ''
    };
    // // console.log(r);
    this.showspinner = true;
    this.getFile(r);
  }
  getFile(v: ESAC) {
    this.rfs.getRiskESAC(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            () => {
              this.showspinner = false;
              // // console.log(res1);
              // // console.log(res);
              /////////////////////////// Cleaning server and web folder
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, () => { });
                }
              }
              /////////////////////////// Cleaning all - web and oracle - END
            }, () => {
              // // console.log(err);
            });
        },
        () => { });
  }
  updateInfo(v: string, e: string) {
    this[e] = v.toLocaleUpperCase().trim();
  }
}
