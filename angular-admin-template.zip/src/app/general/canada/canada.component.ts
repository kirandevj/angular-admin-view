import { Component, ViewEncapsulation, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, ValidatorFn } from '@angular/forms';
import { SharedServices, GlobalVariables } from '../../common/index';
import { Selection, UserInfo, FooterInfo, PreloadedIDsInfoProcess } from '../../datamodels/index';
// import { IPreLoadedProcess } from '../../components/preloaded/pre-loaded.services';
import { ChannelService, ChannelEvent } from '../../services/channel.sevice';
import { BehaviorSubject } from 'rxjs';
// import { RiskFinanceServices } from '../../riskfinance/shared/risk-finance.service';
// import { IOption } from 'ng-select';

@Component({
  templateUrl: './canada.html',
  styleUrls: ['./canada.css']
})
export class CanadaComponent implements OnInit {
  @Input() message: ChannelEvent = {
    Name: '',
    ChannelName: '',
    Timestamp: (new Date(Date.now() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, -1),
    Data: {
      State: 'Process info here',
      PercentComplete: 0,
      json: ''
    },
    Json: ''
  };
  items: ChannelEvent[] = [];
  items$ = new BehaviorSubject(this.items);
  env = '';
  items2: string[] = [];
  dataprogressinfo = 'Progress info here';
  sentToSignalRChannel = 'getcanadareport';
  receivedFromService = '';
  eventName: string;
  sendtofileloadermessages: any[] = ['', false];
  user: UserInfo;
  sendtofooter: FooterInfo;
  server: string;
  image0: string;
  image1: string;
  filenames: string[];
  showfile: boolean;
  // sentToService: IPreLoadedProcess;
  headerName: string;
  headerBackUrl: string;
  constructor(
    // private rfs: RiskFinanceServices,
    private ss: SharedServices,
    private gv: GlobalVariables,
    private formBuilder: FormBuilder,
    // private channelService: ChannelService,
    private cdr: ChangeDetectorRef
  ) {
    this.eventName = this.sentToSignalRChannel;
    this.headerName = 'Canada Report';
    this.headerBackUrl = 'general';
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.eventName = this.sentToSignalRChannel;
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    // this.sentToService = {
    //   product: '5',
    //   process: this.headerName,
    //   server: this.server,
    //   qryname: this.ss.getQueryNameDaily('GCR', 'T', 0),
    //   username: this.user.name,
    //   c: this.ss.getPass(),
    //   env: this.gv.get('excelfilesave', 'excelfilesave'),
    //   mmsback: 36,
    //   channel: this.eventName,
    //   eventname: this.eventName,
    //   signalr: this.channelService.connectionID$
    // };
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - ' + this.headerName + ' page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  ngOnInit() {
    this.items.push(this.message);
    console.warn('Sending');
    // console.log(this.sentToService);
  }
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
  }
  ////////////////// Data loads end here
  receiveFromFileServiceProgress($event: ChannelEvent) {
    this.items.push($event);
    // console.log($event);
    this.message = $event;
    this.cdr.detectChanges();
    if ($event.Data.FileNames.length > 0) {
      // console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
      const allowedfiles = ['xlsx', 'csv'];
      const env = this.gv.get('excelfiledownload', 'excelfiledownload');
      // console.log($event.Data.FileNames);
      this.ss.downloadFilesFromSignalRService($event.Data.FileNames, env, allowedfiles, true, this.server);
    }
  }
}


