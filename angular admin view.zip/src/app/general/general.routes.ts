import { GENComponent } from './general.component';
import { ESACComponent } from './esac/esac.component';
import { CanadaComponent } from './canada/canada.component';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

export const GENRoutes = [
    { path: '', component: GENComponent },
    { path: 'esac', component: ESACComponent },
    { path: 'canada', component: CanadaComponent },
];

@NgModule({
    imports: [RouterModule.forChild(GENRoutes)],
    exports: [RouterModule],
  })
  
  export class generalroutesModule {
}