import { Component, ViewEncapsulation, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, ValidatorFn } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';

// import { IOption } from 'ng-select';

@Component({
  templateUrl: './canada.html',
  styleUrls: ['./canada.css']
})
export class CanadaComponent implements OnInit {
  constructor()
  {
  }

  ngOnInit(): void {
  }

}


