import { Component, ViewEncapsulation, OnInit, ElementRef } from '@angular/core';

@Component({
  // encapsulation: ViewEncapsulation.None,
  templateUrl: './general.html',
  styleUrls: ['./general.component.css']
})
export class GENComponent implements OnInit {
  mapoption: string;
  constructor() {
  }
  ngOnInit() {
  }
}
