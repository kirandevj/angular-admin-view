import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { GENComponent } from './general.component';
import { GENRoutes } from './general.routes';

import { ESACComponent } from './esac/esac.component';
import { CanadaComponent } from './canada/canada.component';

import { generalroutesModule } from '../general/general.routes';

@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(GENRoutes),
    generalroutesModule
   
  ],
  declarations: [
    GENComponent,
    ESACComponent,
    CanadaComponent
  ],
  providers: [
   
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class GeneralModule {
  // selectedPro(): any {
  // }
}
