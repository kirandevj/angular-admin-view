﻿
namespace Report_RE_V1
{
    partial class frmReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Report_Generate = new System.Windows.Forms.Button();
            this.btn_Encrypt = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btn_Report_Generate
            // 
            this.btn_Report_Generate.Location = new System.Drawing.Point(103, 77);
            this.btn_Report_Generate.Name = "btn_Report_Generate";
            this.btn_Report_Generate.Size = new System.Drawing.Size(153, 40);
            this.btn_Report_Generate.TabIndex = 0;
            this.btn_Report_Generate.Text = "Get Report";
            this.btn_Report_Generate.UseVisualStyleBackColor = true;
            this.btn_Report_Generate.Click += new System.EventHandler(this.btn_Report_Generate_Clik);
            // 
            // btn_Encrypt
            // 
            this.btn_Encrypt.Location = new System.Drawing.Point(330, 77);
            this.btn_Encrypt.Name = "btn_Encrypt";
            this.btn_Encrypt.Size = new System.Drawing.Size(130, 40);
            this.btn_Encrypt.TabIndex = 1;
            this.btn_Encrypt.Text = "Encypt";
            this.btn_Encrypt.UseVisualStyleBackColor = true;
            this.btn_Encrypt.Click += new System.EventHandler(this.btn_Encrypt_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(89, 182);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(594, 371);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            // 
            // frmReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 565);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.btn_Encrypt);
            this.Controls.Add(this.btn_Report_Generate);
            this.Name = "frmReport";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Report_Generate;
        private System.Windows.Forms.Button btn_Encrypt;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

