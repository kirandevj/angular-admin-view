﻿using ClosedXML.Excel;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Report_RE_V1
{
    public partial class frmReport : Form
    {
        public static frmReport form = null;
        public delegate void EnableDelegate(bool enable);

        public frmReport()
        {
            InitializeComponent();
            form = this;
        }
        public void M1(string str)
        {
            richTextBox1.AppendText(str);
        }
        //client call
        public void btn_Report_Generate_Clik(object sender, EventArgs e)
        {

            var preloadedidsinfoprocess = "preloadedidsinfoprocess";
            var value = new ExcelServicesModels.PreloadedIDsInfoProcess { process = "Canada Report" };
            GenerateReport(preloadedidsinfoprocess, value);
        }

        //Web Api
        public List<string> GenerateReport(string preloadedidsinfoprocess, ExcelServicesModels.PreloadedIDsInfoProcess value)
        {
            var CEF = new CustomExcel();
            return CEF.GetPreloadedIDsInfoProcessSwitch(value);
        }

        private void btn_Encrypt_Click(object sender, EventArgs e)
        {

            EncryptStrings.StringCipher stringCipher = new EncryptStrings.StringCipher();
            string key = "Report_34_@!_GPU";
            string decrypt = ConfigurationManager.AppSettings["O_1"].ToString();
            //decrypt = stringCipher.Encrypt(decrypt, "Report_34_@!_GPU");

            OracleConnection Conn = new OracleConnection(decrypt);
            OracleCommand OraCommand = Conn.CreateCommand();
            Conn.Open();
            Conn.Close();

            //string encr_str = ConfigurationManager.ConnectionStrings["O_1"].ConnectionString;

            //string decr_str = stringCipher.Decrypt(encr_str, "Report_34_@!_GPU");

            //encr_str = stringCipher.Encrypt(decr_str, "Report_34_@!_GPU");

            //decr_str = stringCipher.Decrypt(encr_str, "Report_34_@!_GPU");



            // **************************Get PreloadedIDsInfoProcess*****************//
            // var values = new ExcelServicesModels.PreloadedIDsInfoProcess
            //{
            //    c = ConfigurationManager.AppSettings["c"].ToString(),
            //    channel = ConfigurationManager.AppSettings["channel"].ToString(),
            //    clientid = ConfigurationManager.AppSettings["clientid"].ToString(),
            //    enddate = ConfigurationManager.AppSettings["enddate"].ToString(),
            //    env = ConfigurationManager.AppSettings["env"].ToString(),
            //    eventname = ConfigurationManager.AppSettings["eventname"].ToString(),
            //    fileloaded = ConfigurationManager.AppSettings["fileloaded"].ToString(),
            //    process = ConfigurationManager.AppSettings["process"].ToString(),
            //    product = ConfigurationManager.AppSettings["product"].ToString(),
            //    qryname = ConfigurationManager.AppSettings["qryname"].ToString(),
            //    server = ConfigurationManager.AppSettings["server"].ToString(),
            //    signalr = ConfigurationManager.AppSettings["signalr"].ToString(),
            //    username = ConfigurationManager.AppSettings["username"].ToString()
            //};

        }
    }
    public class ExcelServicesModels
    {
        private static DateTime _dt = DateTime.Now;
        private static int _mm = _dt.Month;
        private static string _mmStr = ("00" + _mm.ToString()).Substring(Math.Max(0, ("00" + _mm.ToString()).Length - 2));
        private static int _yr = _dt.Year;
        private static string _yrStr = _yr.ToString();
        private static int _dd = _dt.Day;
        private static string _ddStr = ("00" + _dd.ToString()).Substring(Math.Max(0, ("00" + _dd.ToString()).Length - 2));
        private static string _trStr = _mmStr + "_" + _ddStr + "_" + _yrStr;
        private static string _month = DateTime.Now.ToString("MMMM");
        public string Get_SQL_All_Clients_Plus_TriNet(string dt)
        {
            string init = @"
            select ff.* from (
            select 
            TRIM(UPPER(a.PF_CLIENT)) as CLIENTID,
            TRIM(UPPER(a.COMPANY)) as COID,
            COALESCE(TRIM(UPPER(b.T2_LEGAL_NAME)),TRIM(UPPER(a.DESCR))) as ORACLECLIENT,
            COALESCE(TRIM(UPPER(a.DESCR)),TRIM(UPPER(b.T2_LEGAL_NAME))) as NAMES,
            COALESCE(TRIM(UPPER(b.T2_LEGAL_NAME)),TRIM(UPPER(a.DESCR))) as LEGALNAME,
            b.T2_COMP_LIVE_DT AS STDT, 
            b.T2_COMP_TERM_DT AS TERMDT, 
            a.EFF_STATUS AS STATUS,
            CASE WHEN TRIM(UPPER(b.T2_WC_COVRG_OPTN)) = 'Y' THEN 'N' ELSE 'Y' END as CARVEOUT,
            substr('000000' || REPLACE(REPLACE(REPLACE(TRIM(UPPER(c.NAICS)),'N/A','000'),'NA','00'),'.','0'),-6,6) as NAICS,
            '' as NAICSDESCR,
            '' AS SIC,
            '' AS SICDESCR,
            '' AS VERTICAL,
            TRIM(UPPER(a.PF_CORP)) as PFCORP,
            TRIM(UPPER(b.T2_PEO_ID)) as T2PEOID 
            from (
            select bb.* from (
            select a.*, MAX(a.EFFDT) OVER (PARTITION BY a.COMPANY) as MAXDT from PS_COMPANY_TBL a where a.EFFDT <= TO_DATE('REPLACEDATE','mm/dd/yyyy')
            ) bb
            where bb.EFFDT = bb.MAXDT
            ) a
            LEFT JOIN PS_T2_CLIENTOPTION b
            on TRIM(UPPER(a.COMPANY)) = TRIM(UPPER(b.COMPANY)) and TRIM(UPPER(a.PF_CLIENT)) = TRIM(UPPER(b.PF_CLIENT))
            LEFT JOIN (
            select dd.* from (
            select ddd.*,MAX(ddd.EFFDT) OVER (PARTITION BY ddd.ESTABID) as MAXDT from PS_ESTAB_TBL_USA ddd where ddd.EFFDT <= TO_DATE('REPLACEDATE','mm/dd/yyyy')
            ) dd where dd.EFFDT = dd.MAXDT
            ) c
            on TRIM(UPPER(a.COMPANY)) = TRIM(UPPER(c.ESTABID))
            ) ff ";
            return init.Replace("REPLACEDATE", dt);
        }
        public class PreloadedIDsInfoProcess
        {
            readonly EncryptStrings.StringCipher Encr = new EncryptStrings.StringCipher();

            public string process { get; set; }
            public string signalr { get; set; }
            public string channel { get; set; }
            public string eventname { get; set; }
            public string qryname { get; set; }
            public string env { get; set; }
            public string fileloaded { get; set; }
            public string c { get; set; }
            public string server { get; set; }
            public string clientid { get; set; }
            public string product { get; set; }
            public string enddate { get; set; }
            public string username { get; set; }
            public string hrproductionlink()
            {
                return Encr.Decrypt(ConfigurationManager.ConnectionStrings["O_LR"].ConnectionString, c);
            }
            public string hrdevlink()
            {
                return Encr.Decrypt(ConfigurationManager.ConnectionStrings["O_LR"].ConnectionString, c);
            }
            public string innternallink()
            {
                return Encr.Decrypt(ConfigurationManager.ConnectionStrings["O_1"].ConnectionString, c);
            }
            public string hrlink()
            {
                if (server == "HRPROD")
                {
                    return hrproductionlink();
                }
                else
                {
                    return hrdevlink();
                }
            }
            public string Get_Init_Clients_SQL_Plus_TriNet()
            {
                var ESM = new ExcelServicesModels();
                return ESM.Get_SQL_All_Clients_Plus_TriNet(enddate);

            }
            public string current_date()
            {
                return _trStr;
            }
        }
        public class LogActivitiesObject
        {
            public string username { get; set; }
            public string applicationname { get; set; }
            public string processname { get; set; }
            public string sqlstring1 { get; set; }
            public string sqlstring2 { get; set; }
            public string sqlstring3 { get; set; }
            public string sqlstring4 { get; set; }
            public string sqlstring5 { get; set; }
            public int totalseconds { get; set; }
            public string p()
            {
                return "Processes_Log_Activities";
            }
        }
    }
    public class CustomExcel
    {
        public List<string> GetPreloadedIDsInfoProcessSwitch(ExcelServicesModels.PreloadedIDsInfoProcess v)
        {
            try
            {
                switch (v.process)
                {
                    case "Actuarial - Admin Fee pull":
                    case "Actuarial - Rates Change pull":
                    case "Actuarial - WSE pull":
                    case "Risk - Rates changed":
                    case "Risk - WSE Comparison":
                    case "Risk - Work Hours":
                    case "Underwriting - Rates changed":
                    case "Underwriting Bill Rates Clients":
                    case "Underwriting Main Process":
                    case "Underwriting CCRR Process":
                    case "Payroll Compliance Main Process":
                    case "Canada Report":
                        return GetPreloadedIDsInfoProcess_GR_CanadaReport(v);
                    case "Payroll Compliance minimum wages and FLSA satus":
                    default:
                        return new List<string>();
                }
            }
            catch (Exception e)
            {
                return new List<string>()
                {
                  e.Message,
                  e.Source,
                  e.HelpLink
                };
            }
        }
        public List<string> GetPreloadedIDsInfoProcess_GR_CanadaReport(ExcelServicesModels.PreloadedIDsInfoProcess v)
        {
            List<string> ReturnArray = new List<string>();
            try
            {
                var GP = new GeneralProcesses();
                var OSPS = new OracleStoredProceduresServices();
                var PXMLP = new PublicXMLProcedures();
                var SRSD = new SignalRSendData();

                DateTime StartTime = DateTime.Now;
                DateTime dtlt = DateTime.Now;
                string uniquid = dtlt.Day.ToString() + dtlt.Hour.ToString() + dtlt.Minute.ToString() + dtlt.Second.ToString();
                SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Process " + v.process + " started", 0);

                List<string> runningasyncprocess(List<string> l)
                {
                    int splitclients = 500;
                    string idstable = v.qryname + "IDS";
                    string basetable = v.qryname + "B";
                    string pt_jobs = v.qryname + "PTJ";
                    string pt_employees = v.qryname + "PTE";
                    string pt_mailing = v.qryname + "PTM";
                    string pt_location = v.qryname + "PTL";
                    string pt_tax = v.qryname + "PTT";
                    string pt_tax2 = v.qryname + "PTT2";
                    int tables_c = 0;
                    string sql = "";
                    string filenameinitial = v.env.Replace("\\excel\\", "\\ManagedFiles\\") + v.fileloaded;
                    List<string> listIDs = new List<string>();
                    List<List<string>> stringListList = new List<List<string>>();
                    var tables = new List<string>
                    {
                        v.qryname,
                        idstable
                    };

                    Task[] tasks = new Task[9];

                    Task<string> task0 = Task.Factory.StartNew(() =>
                    {
                        sql = @"SELECT count(object_name) as x FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE') AND OWNER = 'RISK_ANALYTICS'
                               and object_name IN('" + v.qryname + @"', '" + idstable + @"', '" + basetable + @"')";
                        tables_c = OSPS.getDataCount(sql, v.innternallink());

                        if (tables_c != 3)
                        {
                            InitilizeClientIDs(v.innternallink(), v.hrlink(), v.qryname, idstable, basetable, tables,
                                    v.fileloaded, v.Get_Init_Clients_SQL_Plus_TriNet(), v.clientid, v.product, filenameinitial, false, true);
                        }

                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Initial tables for Company IDs were intilized", 1);

                        sql = "select distinct COID from " + basetable;
                        var tableids = OSPS.getDataTable(sql, v.innternallink());
                        listIDs = tableids.AsEnumerable().Select<DataRow, string>((Func<DataRow, string>)(r => r.Field<string>("COID"))).ToList<string>();
                        stringListList = GP.ChunkBy<string>(ref listIDs, splitclients);

                        sql = "select distinct CLIENTID from " + idstable;

                        return "0";
                    });
                    tasks[0] = task0;

                    ///////// Stage 1 PS_JOBS pt_jobs
                    Task<string> task1 = Task.Factory.StartNew(() =>
                    {
                        //--------------------------- Getting Jobs
                        string sqlS1C = @"SELECT count(object_name) as x FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE') AND OWNER = 'RISK_ANALYTICS'
                               and object_name IN('" + pt_jobs + @"')";
                        tables_c = OSPS.getDataCount(sqlS1C, v.innternallink());
                        if (tables_c != 1)
                        {
                            task0.Wait();
                            /////////////////////////// results table initialization
                            string sqlResultsCreationS1 = @"CREATE TABLE " + pt_jobs + @"     
                                                        (
                                                        EMPLID NVARCHAR2(250),
                                                        EMPL_RCD NVARCHAR2(250),
                                                        EFFDT NVARCHAR2(250),
                                                        EFFSEQ NVARCHAR2(250),
                                                        DEPTID NVARCHAR2(250),
                                                        JOBCODE NVARCHAR2(250),
                                                        POSITION_NBR NVARCHAR2(250),
                                                        APPT_TYPE NVARCHAR2(250),
                                                        MAIN_APPT_NUM_JPN NVARCHAR2(250),
                                                        POSITION_OVERRIDE NVARCHAR2(250),
                                                        POSN_CHANGE_RECORD NVARCHAR2(250),
                                                        EMPL_STATUS NVARCHAR2(250),
                                                        ACTION NVARCHAR2(250),
                                                        ACTION_DT NVARCHAR2(250),
                                                        ACTION_REASON NVARCHAR2(250),
                                                        LOCATION NVARCHAR2(250),
                                                        TAX_LOCATION_CD NVARCHAR2(250),
                                                        JOB_ENTRY_DT NVARCHAR2(250),
                                                        DEPT_ENTRY_DT NVARCHAR2(250),
                                                        POSITION_ENTRY_DT NVARCHAR2(250),
                                                        SHIFT NVARCHAR2(250),
                                                        REG_TEMP NVARCHAR2(250),
                                                        FULL_PART_TIME NVARCHAR2(250),
                                                        COMPANY NVARCHAR2(250),
                                                        PAYGROUP NVARCHAR2(250),
                                                        BAS_GROUP_ID NVARCHAR2(250),
                                                        ELIG_CONFIG1 NVARCHAR2(250),
                                                        ELIG_CONFIG2 NVARCHAR2(250),
                                                        ELIG_CONFIG3 NVARCHAR2(250),
                                                        ELIG_CONFIG4 NVARCHAR2(250),
                                                        ELIG_CONFIG5 NVARCHAR2(250),
                                                        ELIG_CONFIG6 NVARCHAR2(250),
                                                        ELIG_CONFIG7 NVARCHAR2(250),
                                                        ELIG_CONFIG8 NVARCHAR2(250),
                                                        ELIG_CONFIG9 NVARCHAR2(250),
                                                        BEN_STATUS NVARCHAR2(250),
                                                        BAS_ACTION NVARCHAR2(250),
                                                        COBRA_ACTION NVARCHAR2(250),
                                                        EMPL_TYPE NVARCHAR2(250),
                                                        HOLIDAY_SCHEDULE NVARCHAR2(250),
                                                        STD_HOURS NVARCHAR2(250),
                                                        STD_HRS_FREQUENCY NVARCHAR2(250),
                                                        OFFICER_CD NVARCHAR2(250),
                                                        EMPL_CLASS NVARCHAR2(250),
                                                        SAL_ADMIN_PLAN NVARCHAR2(250),
                                                        GRADE NVARCHAR2(250),
                                                        GRADE_ENTRY_DT NVARCHAR2(250),
                                                        STEP NVARCHAR2(250),
                                                        STEP_ENTRY_DT NVARCHAR2(250),
                                                        GL_PAY_TYPE NVARCHAR2(250),
                                                        ACCT_CD NVARCHAR2(250),
                                                        EARNS_DIST_TYPE NVARCHAR2(250),
                                                        COMP_FREQUENCY NVARCHAR2(250),
                                                        COMPRATE NVARCHAR2(250),
                                                        CHANGE_AMT NVARCHAR2(250),
                                                        CHANGE_PCT NVARCHAR2(250),
                                                        ANNUAL_RT NVARCHAR2(250),
                                                        MONTHLY_RT NVARCHAR2(250),
                                                        DAILY_RT NVARCHAR2(250),
                                                        HOURLY_RT NVARCHAR2(250),
                                                        ANNL_BENEF_BASE_RT NVARCHAR2(250),
                                                        SHIFT_RT NVARCHAR2(250),
                                                        SHIFT_FACTOR NVARCHAR2(250),
                                                        CURRENCY_CD NVARCHAR2(250),
                                                        BUSINESS_UNIT NVARCHAR2(250),
                                                        SETID_DEPT NVARCHAR2(250),
                                                        SETID_JOBCODE NVARCHAR2(250),
                                                        SETID_LOCATION NVARCHAR2(250),
                                                        SETID_SALARY NVARCHAR2(250),
                                                        REG_REGION NVARCHAR2(250),
                                                        DIRECTLY_TIPPED NVARCHAR2(250),
                                                        FLSA_STATUS NVARCHAR2(250),
                                                        EEO_CLASS NVARCHAR2(250),
                                                        FUNCTION_CD NVARCHAR2(250),
                                                        TARIFF_GER NVARCHAR2(250),
                                                        TARIFF_AREA_GER NVARCHAR2(250),
                                                        PERFORM_GROUP_GER NVARCHAR2(250),
                                                        LABOR_TYPE_GER NVARCHAR2(250),
                                                        SPK_COMM_ID_GER NVARCHAR2(250),
                                                        HOURLY_RT_FRA NVARCHAR2(250),
                                                        ACCDNT_CD_FRA NVARCHAR2(250),
                                                        VALUE_1_FRA NVARCHAR2(250),
                                                        VALUE_2_FRA NVARCHAR2(250),
                                                        VALUE_3_FRA NVARCHAR2(250),
                                                        VALUE_4_FRA NVARCHAR2(250),
                                                        VALUE_5_FRA NVARCHAR2(250),
                                                        CTG_RATE NVARCHAR2(250),
                                                        PAID_HOURS NVARCHAR2(250),
                                                        PAID_FTE NVARCHAR2(250),
                                                        PAID_HRS_FREQUENCY NVARCHAR2(250),
                                                        UNION_FULL_PART NVARCHAR2(250),
                                                        UNION_POS NVARCHAR2(250),
                                                        MATRICULA_NBR NVARCHAR2(250),
                                                        SOC_SEC_RISK_CODE NVARCHAR2(250),
                                                        UNION_FEE_AMOUNT NVARCHAR2(250),
                                                        UNION_FEE_START_DT NVARCHAR2(250),
                                                        UNION_FEE_END_DT NVARCHAR2(250),
                                                        EXEMPT_JOB_LBR NVARCHAR2(250),
                                                        EXEMPT_HOURS_MONTH NVARCHAR2(250),
                                                        WRKS_CNCL_FUNCTION NVARCHAR2(250),
                                                        INTERCTR_WRKS_CNCL NVARCHAR2(250),
                                                        CURRENCY_CD1 NVARCHAR2(250),
                                                        PAY_UNION_FEE NVARCHAR2(250),
                                                        UNION_CD NVARCHAR2(250),
                                                        BARG_UNIT NVARCHAR2(250),
                                                        UNION_SENIORITY_DT NVARCHAR2(250),
                                                        ENTRY_DATE NVARCHAR2(250),
                                                        LABOR_AGREEMENT NVARCHAR2(250),
                                                        EMPL_CTG NVARCHAR2(250),
                                                        EMPL_CTG_L1 NVARCHAR2(250),
                                                        EMPL_CTG_L2 NVARCHAR2(250),
                                                        SETID_LBR_AGRMNT NVARCHAR2(250),
                                                        GP_PAYGROUP NVARCHAR2(250),
                                                        GP_DFLT_ELIG_GRP NVARCHAR2(250),
                                                        GP_ELIG_GRP NVARCHAR2(250),
                                                        GP_DFLT_CURRTTYP NVARCHAR2(250),
                                                        CUR_RT_TYPE NVARCHAR2(250),
                                                        GP_DFLT_EXRTDT NVARCHAR2(250),
                                                        GP_ASOF_DT_EXG_RT NVARCHAR2(250),
                                                        ADDS_TO_FTE_ACTUAL NVARCHAR2(250),
                                                        CLASS_INDC NVARCHAR2(250),
                                                        ENCUMB_OVERRIDE NVARCHAR2(250),
                                                        FICA_STATUS_EE NVARCHAR2(250),
                                                        FTE NVARCHAR2(250),
                                                        PRORATE_CNT_AMT NVARCHAR2(250),
                                                        PAY_SYSTEM_FLG NVARCHAR2(250),
                                                        BORDER_WALKER NVARCHAR2(250),
                                                        LUMP_SUM_PAY NVARCHAR2(250),
                                                        CONTRACT_NUM NVARCHAR2(250),
                                                        JOB_INDICATOR NVARCHAR2(250),
                                                        WRKS_CNCL_ROLE_CHE NVARCHAR2(250),
                                                        BENEFIT_SYSTEM NVARCHAR2(250),
                                                        WORK_DAY_HOURS NVARCHAR2(250),
                                                        SUPERVISOR_ID NVARCHAR2(250),
                                                        REPORTS_TO NVARCHAR2(250),
                                                        FORCE_PUBLISH NVARCHAR2(250),
                                                        JOB_DATA_SRC_CD NVARCHAR2(250),
                                                        ESTABID NVARCHAR2(250),
                                                        PF_CLIENT NVARCHAR2(250),
                                                        PER_ORG NVARCHAR2(250),
                                                        HR_STATUS NVARCHAR2(250),
                                                        WPP_STOP_FLAG NVARCHAR2(250),
                                                        LABOR_FACILITY_ID NVARCHAR2(250),
                                                        LBR_FAC_ENTRY_DT NVARCHAR2(250),
                                                        LAYOFF_EXEMPT_FLAG NVARCHAR2(250),
                                                        LAYOFF_EXEMPT_RSN NVARCHAR2(250),
                                                        SUPV_LVL_ID NVARCHAR2(250),
                                                        SETID_SUPV_LVL NVARCHAR2(250),
                                                        ABSENCE_SYSTEM_CD NVARCHAR2(250),
                                                        POI_TYPE NVARCHAR2(250),
                                                        HIRE_DT NVARCHAR2(250),
                                                        LAST_HIRE_DT NVARCHAR2(250),
                                                        TERMINATION_DT NVARCHAR2(250),
                                                        ASGN_START_DT NVARCHAR2(250),
                                                        LST_ASGN_START_DT NVARCHAR2(250),
                                                        ASGN_END_DT NVARCHAR2(250),
                                                        LDW_OVR NVARCHAR2(250),
                                                        LAST_DATE_WORKED NVARCHAR2(250),
                                                        EXPECTED_RETURN_DT NVARCHAR2(250),
                                                        EXPECTED_END_DATE NVARCHAR2(250),
                                                        AUTO_END_FLG NVARCHAR2(250),
                                                        LASTUPDDTTM NVARCHAR2(250),
                                                        LASTUPDOPRID NVARCHAR2(250),
                                                        SETID_EMPL_CLASS NVARCHAR2(250),
                                                        MAXDT NVARCHAR2(250),
                                                        MAXSEQ NVARCHAR2(250),
                                                        MAXRCD NVARCHAR2(250),
                                                        CANADA_COID NVARCHAR2(250)
                                                        )";
                            OSPS.ExecuteSQL(sqlResultsCreationS1, v.innternallink());
                            try
                            {
                                string sqlS1P = @"
                                                select d.* from (
                                                select c.*, coalesce(bbb.COMPANY,bbbb.COMPANY,'MISSING') as CANADA_COID from ( 
                                                select b.* from (select a.*,MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT,MAX(a.EFFSEQ) OVER(PARTITION BY a.EMPLID, a.EFFDT) AS MAXSEQ,MAX(a.EMPL_RCD) OVER(PARTITION BY a.EMPLID, a.EFFDT, a.EFFSEQ) AS MAXRCD from PS_JOB a 
                                                where a.COMPANY IN (REPLACE) and a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') order by a.EMPLID asc) b WHERE b.MAXDT = b.EFFDT AND b.MAXSEQ = b.EFFSEQ AND b.MAXRCD = b.EMPL_RCD
                                                ) c
                                                left join (select distinct b.COMPANY  FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_DATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) bbb on trim(upper(c.COMPANY)) = trim(upper(bbb.COMPANY))
                                                left join (select distinct b.COMPANY  FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_PRVDATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) bbbb on trim(upper(c.COMPANY)) = trim(upper(bbbb.COMPANY))
                                                ) d where d.CANADA_COID <> 'MISSING' ";
                                Parallel.ForEach<List<string>>((IEnumerable<List<string>>)stringListList, new ParallelOptions { MaxDegreeOfParallelism = 8 }, id =>
                                {
                                    string sqlCreateS1 = "";
                                    try
                                    {
                                        string idsS1 = "'" + string.Join(",", id.ToArray()).Replace(",", "','") + "'";
                                        sqlCreateS1 = sqlS1P.Replace("REPLACE", idsS1) + " and trim(upper(d.COMPANY)) in (" + idsS1 + ")";
                                        DataTable dtCreateS1 = OSPS.getDataTable(sqlCreateS1, v.hrlink());
                                        if (dtCreateS1.Rows.Count > 0)
                                        {
                                            OSPS.PutDataTableWithArrayToDb(ref dtCreateS1, v.innternallink(), false, pt_jobs, 0, sqlCreateS1);
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients mailing see stage 2 parallel loop - " + e.Message + " | SQL - " + sqlCreateS1, 1);
                                    }
                                });
                            }
                            catch (Exception e)
                            {
                                SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients mailing see stage 2 - " + e.Message, 1);
                            }
                        }
                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Jobs Info for Clients was pulled", 1);
                        return "1";
                    });
                    tasks[1] = task1;

                    ///////// Stage 2 Mailing
                    Task<string> task2 = Task.Factory.StartNew(() =>
                    {
                        //--------------------------- Getting Mailing addresses
                        string sqlS2C = @"SELECT count(object_name) as x FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE') AND OWNER = 'RISK_ANALYTICS'
                               and object_name IN('" + pt_mailing + @"')";
                        tables_c = OSPS.getDataCount(sqlS2C, v.innternallink());
                        if (tables_c != 1)
                        {
                            task0.Wait();
                            /////////////////////////// results table initialization
                            string sqlResultsCreationS2 = @"CREATE TABLE " + pt_mailing + @"     
                                                        (
                                                        COMPANY NVARCHAR2(250), 
                                                        EFFDT DATE, 
                                                        EFF_STATUS NVARCHAR2(250), 
                                                        DESCR NVARCHAR2(250), 
                                                        DESCR_AC NVARCHAR2(250), 
                                                        DESCRSHORT NVARCHAR2(250), 
                                                        COUNTRY NVARCHAR2(250), 
                                                        ADDRESS1 NVARCHAR2(250), 
                                                        ADDRESS2 NVARCHAR2(250), 
                                                        ADDRESS3 NVARCHAR2(250), 
                                                        ADDRESS4 NVARCHAR2(250), 
                                                        CITY NVARCHAR2(250), 
                                                        NUM1 NVARCHAR2(250), 
                                                        NUM2 NVARCHAR2(250), 
                                                        HOUSE_TYPE NVARCHAR2(250), 
                                                        ADDR_FIELD1 NVARCHAR2(250), 
                                                        ADDR_FIELD2 NVARCHAR2(250), 
                                                        ADDR_FIELD3 NVARCHAR2(250), 
                                                        COUNTY NVARCHAR2(250), 
                                                        STATE NVARCHAR2(250), 
                                                        POSTAL NVARCHAR2(250), 
                                                        GEO_CODE NVARCHAR2(250), 
                                                        IN_CITY_LIMIT NVARCHAR2(250), 
                                                        FEDERAL_EIN NVARCHAR2(250), 
                                                        FICA_STATUS_EE NVARCHAR2(250), 
                                                        FICA_STATUS_ER NVARCHAR2(250), 
                                                        FUT_EXEMPT NVARCHAR2(250), 
                                                        SUT_EXEMPT NVARCHAR2(250), 
                                                        SDI_EXEMPT NVARCHAR2(250), 
                                                        PAYGROUP NVARCHAR2(250), 
                                                        DFLT_ERN_PROGRAM NVARCHAR2(250), 
                                                        TERMEE_PR_STOPDAYS NVARCHAR2(250), 
                                                        PAYSHEET_LINES NVARCHAR2(250), 
                                                        TAX_REPORT_TYPE NVARCHAR2(250), 
                                                        COMMON_PAY_ID NVARCHAR2(250), 
                                                        COMMON_OTH_ID NVARCHAR2(250), 
                                                        DED_PRIORITY_FED NUMBER(*,0), 
                                                        DED_PRIORITY_STATE NUMBER(*,0), 
                                                        FED_RSRV_BANK_ID NVARCHAR2(250), 
                                                        FED_RSRV_BANK_DIST NUMBER(*,0), 
                                                        FLSA_REQUIRED NVARCHAR2(250), 
                                                        FLSA_RULE NVARCHAR2(250), 
                                                        COMP_POINTS_VALUE NUMBER(*,0), 
                                                        CURRENCY_CD NVARCHAR2(250), 
                                                        TIPS_ESTBLSH_FLD NVARCHAR2(250), 
                                                        MIN_TIPS_PCT NUMBER(*,0), 
                                                        TIPS_ALLOC_METH NVARCHAR2(250), 
                                                        ERNCD_TIPS_ALLOC NVARCHAR2(250), 
                                                        TIPS_DELAY_WTHLD NVARCHAR2(250), 
                                                        TIPS_ADJUST NVARCHAR2(250), 
                                                        ERNCD_TIPS_ADJUST NVARCHAR2(250), 
                                                        ERNCD_TIPS_CRED NVARCHAR2(250), 
                                                        EEO_COMPANY_CD NVARCHAR2(250), 
                                                        COUNTRY_OTHER NVARCHAR2(250), 
                                                        ADDRESS1_OTHER NVARCHAR2(250), 
                                                        ADDRESS2_OTHER NVARCHAR2(250), 
                                                        ADDRESS3_OTHER NVARCHAR2(250), 
                                                        ADDRESS4_OTHER NVARCHAR2(250), 
                                                        CITY_OTHER NVARCHAR2(250), 
                                                        COUNTY_OTHER NVARCHAR2(250), 
                                                        STATE_OTHER NVARCHAR2(250), 
                                                        POSTAL_OTHER NVARCHAR2(250), 
                                                        NUM1_OTHER NVARCHAR2(250), 
                                                        NUM2_OTHER NVARCHAR2(250), 
                                                        HOUSE_TYPE_OTHER NVARCHAR2(250), 
                                                        ADDR_FIELD1_OTHER NVARCHAR2(250), 
                                                        ADDR_FIELD2_OTHER NVARCHAR2(250), 
                                                        ADDR_FIELD3_OTHER NVARCHAR2(250), 
                                                        IN_CITY_LMT_OTHER NVARCHAR2(250), 
                                                        GEO_CODE_OTHER NVARCHAR2(250), 
                                                        FACT_AGE_BEL NUMBER(*,0), 
                                                        FACT_CORRECT_BEL NUMBER(*,0), 
                                                        FACT_SERVT_BEL NUMBER(*,0), 
                                                        FACT_YEAR_BASE_BEL NUMBER(*,0), 
                                                        HY_FACT_BEL NUMBER(28,10), 
                                                        RIZIV_NUM_BEL NVARCHAR2(250), 
                                                        TERM_CORRECT_BEL NUMBER(*,0), 
                                                        WY_FACT_BEL NUMBER(28,10), 
                                                        MY_FACT_BEL NUMBER(28,10), 
                                                        YY_FACT_BEL NUMBER(28,10), 
                                                        RSZ_GEOCD_BEL NVARCHAR2(250), 
                                                        RSZ_EMPLR_BEL NVARCHAR2(250), 
                                                        RVP_NUM_BEL NVARCHAR2(250), 
                                                        DOSZ_NUM_BEL NVARCHAR2(250), 
                                                        NIS_NUM_BEL NVARCHAR2(250), 
                                                        TRADE_NAME_BEL NVARCHAR2(250), 
                                                        TRADE_REG_BEL NVARCHAR2(250), 
                                                        LEGAL_APPR_BEL NVARCHAR2(250), 
                                                        SALARY_LIMIT_BEL NVARCHAR2(250), 
                                                        IND_COMMITTEE_BEL NVARCHAR2(250), 
                                                        NACE_CD_BEL NVARCHAR2(250), 
                                                        OFFICIAL_LANG NVARCHAR2(250), 
                                                        CLAEYS_SAL_LMT_BEL NUMBER(*,0), 
                                                        FACT_CORRECT2_BEL NUMBER(*,0), 
                                                        CLAEYS_SALLMT2_BEL NUMBER(*,0), 
                                                        WCB_FIRM_NBR NVARCHAR2(250), 
                                                        WCB_RATE_NBR NVARCHAR2(250), 
                                                        ACCDNT_INS_NBR_CHE NVARCHAR2(250), 
                                                        COMP_AHV_CHE NVARCHAR2(250), 
                                                        TRADE_REG_NBR_CHE NVARCHAR2(250), 
                                                        MED_CHKUP_REQ NVARCHAR2(250), 
                                                        ACCIDENT_INS NVARCHAR2(250), 
                                                        SI_ACCIDENT_NUM NVARCHAR2(250), 
                                                        OECD_REQ NVARCHAR2(250), 
                                                        TAX_UNIT NVARCHAR2(250), 
                                                        SIREN_CD_FRA NVARCHAR2(250), 
                                                        CHECK_DIGIT NVARCHAR2(250), 
                                                        APE_INDSTRY_CD_FRA NVARCHAR2(250), 
                                                        BANK_CD NVARCHAR2(250), 
                                                        BRANCH_EC_CD NVARCHAR2(250), 
                                                        ACCOUNT_EC_ID NVARCHAR2(250), 
                                                        LABOR_AGREEMENT NVARCHAR2(250), 
                                                        BASE_SCHEME_FRA NVARCHAR2(250), 
                                                        COMPANY_OPTION_FRA NVARCHAR2(250), 
                                                        EMPLR_TAX_NUM_NLD NUMBER(*,0), 
                                                        BUSINESS_DESCR NVARCHAR2(250), 
                                                        FISCAL_ID_CD NVARCHAR2(250), 
                                                        DEFAULT_SETID NVARCHAR2(250), 
                                                        SETID_LOCATION NVARCHAR2(250), 
                                                        LOCATION NVARCHAR2(250), 
                                                        TIPS_PROCESSING NVARCHAR2(250), 
                                                        HP_STATS_INSTN_CD NUMBER(*,0), 
                                                        INDUSTRY NVARCHAR2(250), 
                                                        INDUSTRY_SECTOR NVARCHAR2(250), 
                                                        OPR_INDUSTRY_OVRD NVARCHAR2(250), 
                                                        SINGLE_CHECK NVARCHAR2(250), 
                                                        LEGAL_TYPE NVARCHAR2(250), 
                                                        PAY_TAXES_THRU_AP NVARCHAR2(250), 
                                                        SYSTEM_DATA_FLG NVARCHAR2(250), 
                                                        REG_REGION NVARCHAR2(250), 
                                                        INST_CODE_AUS NVARCHAR2(250), 
                                                        CLASS_UNIT_NZL NVARCHAR2(250), 
                                                        LIABLE_PAY_TAX NVARCHAR2(250), 
                                                        TEC_COMP_RATECD NVARCHAR2(250), 
                                                        TPV_COMP_RATECD NVARCHAR2(250), 
                                                        APS_AGENT_CD_AUS NUMBER(*,0), 
                                                        PF_CLIENT_EIN NUMBER(*,0), 
                                                        PF_DIV NUMBER(*,0), 
                                                        PF_CORP NVARCHAR2(250), 
                                                        PF_CLIENT NVARCHAR2(250), 
                                                        LASTUPDDTTM DATE, 
                                                        MAXDT DATE,
                                                        CANADA_COID NVARCHAR2(250)
                                                        )";
                            OSPS.ExecuteSQL(sqlResultsCreationS2, v.innternallink());
                            try
                            {
                                string sqlS2P = @"
                                                select d.* from (
                                                select c.*, coalesce(bbb.COMPANY,bbbb.COMPANY,'MISSING') as CANADA_COID from ( 
                                                select b.* FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.COMPANY) AS MAXDT from PS_COMPANY_TBL a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.COMPANY, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) c
                                                left join (select distinct b.COMPANY  FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_DATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) bbb on trim(upper(c.COMPANY)) = trim(upper(bbb.COMPANY))
                                                left join (select distinct b.COMPANY  FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_PRVDATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) bbbb on trim(upper(c.COMPANY)) = trim(upper(bbbb.COMPANY))
                                                ) d where d.CANADA_COID <> 'MISSING' ";
                                Parallel.ForEach<List<string>>((IEnumerable<List<string>>)stringListList, new ParallelOptions { MaxDegreeOfParallelism = 8 }, id =>
                                {
                                    string sqlCreateS2 = "";
                                    try
                                    {
                                        string idsS2 = "'" + string.Join(",", id.ToArray()).Replace(",", "','") + "'";
                                        sqlCreateS2 = sqlS2P + " and trim(upper(d.COMPANY)) in (" + idsS2 + ")";
                                        DataTable dtCreateS2 = OSPS.getDataTable(sqlCreateS2, v.hrlink());
                                        if (dtCreateS2.Rows.Count > 0)
                                        {
                                            OSPS.PutDataTableWithArrayToDb(ref dtCreateS2, v.innternallink(), false, pt_mailing, 0, sqlCreateS2);
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients mailing see stage 2 parallel loop - " + e.Message + " | SQL - " + sqlCreateS2, 2);
                                    }
                                });
                            }
                            catch (Exception e)
                            {
                                SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients mailing see stage 2 - " + e.Message, 2);
                            }
                        }
                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Mailing Info for Clients was pulled", 2);
                        return "2";
                    });
                    tasks[2] = task2;

                    ///////// Stage 3 Addresses
                    Task<string> task3 = Task.Factory.StartNew(() =>
                    {
                        //--------------------------- Getting PS_LOCATION_TBL snap shot
                        string sqlS3C = @"SELECT count(object_name) as x FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE') AND OWNER = 'RISK_ANALYTICS'
                               and object_name IN('" + pt_location + @"')";
                        tables_c = OSPS.getDataCount(sqlS3C, v.innternallink());
                        if (tables_c != 1)
                        {
                            task0.Wait();
                            /////////////////////////// results table initialization
                            string sqlResultsCreationS3 = @"CREATE TABLE " + pt_location + @"     
                                                        (
                                                        SETID nvarchar2(250),
                                                        LOCATION nvarchar2(250),
                                                        EFFDT date,
                                                        EFF_STATUS nvarchar2(250),
                                                        DESCR nvarchar2(250),
                                                        DESCR_AC nvarchar2(250),
                                                        DESCRSHORT nvarchar2(250),
                                                        BUILDING nvarchar2(250),
                                                        FLOOR nvarchar2(250),
                                                        SECTOR nvarchar2(250),
                                                        JURISDICTION nvarchar2(250),
                                                        ATTN_TO nvarchar2(250),
                                                        COUNTRY nvarchar2(250),
                                                        ADDRESS1 nvarchar2(250),
                                                        ADDRESS2 nvarchar2(250),
                                                        ADDRESS3 nvarchar2(250),
                                                        ADDRESS4 nvarchar2(250),
                                                        CITY nvarchar2(250),
                                                        NUM1 nvarchar2(250),
                                                        NUM2 nvarchar2(250),
                                                        HOUSE_TYPE nvarchar2(250),
                                                        ADDR_FIELD1 nvarchar2(250),
                                                        ADDR_FIELD2 nvarchar2(250),
                                                        ADDR_FIELD3 nvarchar2(250),
                                                        COUNTY nvarchar2(250),
                                                        STATE nvarchar2(250),
                                                        POSTAL nvarchar2(250),
                                                        GEO_CODE nvarchar2(250),
                                                        IN_CITY_LIMIT nvarchar2(250),
                                                        COUNTRY_CODE nvarchar2(250),
                                                        PHONE nvarchar2(250),
                                                        EXTENSION nvarchar2(250),
                                                        FAX nvarchar2(250),
                                                        SETID_SALARY nvarchar2(250),
                                                        SAL_ADMIN_PLAN nvarchar2(250),
                                                        LANG_CD nvarchar2(250),
                                                        REG_REGION nvarchar2(250),
                                                        HOLIDAY_SCHEDULE nvarchar2(250),
                                                        LOCALITY nvarchar2(250),
                                                        CAN_CMA nvarchar2(250),
                                                        CAN_OEE_AREACD nvarchar2(250),
                                                        GEOLOC_CODE nvarchar2(250),
                                                        OFFICE_TYPE nvarchar2(250),
                                                        NCR_SW_CAN nvarchar2(250),
                                                        TBS_OFFICE_CD_CAN nvarchar2(250),
                                                        SPK_COMM_ID_GER nvarchar2(250),
                                                        TARIFF_AREA_GER nvarchar2(250),
                                                        TARIFF_GER nvarchar2(250),
                                                        INDUST_INSP_ID_GER nvarchar2(250),
                                                        NI_REPORT_SW_UK nvarchar2(250),
                                                        GVT_GEOLOC_CD nvarchar2(250),
                                                        GVT_DESIG_AGENT nvarchar2(250),
                                                        MATRICULA_NBR nvarchar2(250),
                                                        LABEL_FORMAT_ID2 nvarchar2(250),
                                                        LABEL_FORMAT_ID3 nvarchar2(250),
                                                        USG_LBL_FORMAT_ID nvarchar2(250),
                                                        FON_ER_ID_MEX nvarchar2(250),
                                                        FON_OFFICE_MEX nvarchar2(250),
                                                        LOC_TAX_MEX nvarchar2(250),
                                                        LOC_TAX_SPCL_MEX nvarchar2(250),
                                                        ESTABID nvarchar2(250),
                                                        MESSAGE_TEXT2 nvarchar2(250),
                                                        PF_CLIENT nvarchar2(250),
                                                        TELE_LOCATION nvarchar2(250),
                                                        LASTUPDDTTM nvarchar2(250),
                                                        COMMENTS_2000 nvarchar2(250),
                                                        MAXDT date,
                                                        COMPANY nvarchar2(250),
                                                        CANADA_COID nvarchar2(250)
                                                        )";
                            OSPS.ExecuteSQL(sqlResultsCreationS3, v.innternallink());
                            try
                            {
                                string sqlS3P = @"select d.* from (
                                                select c.*, coalesce(bbb.COMPANY,bbbb.COMPANY,'MISSING') as CANADA_COID from (
                                                select b.* FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.LOCATION) AS MAXDT,
                                                bb.COMPANY
                                                from PS_LOCATION_TBL a 
                                                left join (
                                                select b.* FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.COMPANY) AS MAXDT from PS_COMPANY_TBL a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.COMPANY, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) bb on trim(upper(a.PF_CLIENT)) = trim(upper(bb.PF_CLIENT))
                                                where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.LOCATION, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) c
                                                left join (select distinct b.COMPANY  FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_DATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) bbb on trim(upper(c.COMPANY)) = trim(upper(bbb.COMPANY))
                                                left join (select distinct b.COMPANY  FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_PRVDATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) bbbb on trim(upper(c.COMPANY)) = trim(upper(bbbb.COMPANY))
                                                ) d
                                                where d.CANADA_COID <> 'MISSING'";
                                Parallel.ForEach<List<string>>((IEnumerable<List<string>>)stringListList, new ParallelOptions { MaxDegreeOfParallelism = 8 }, id =>
                                {
                                    string sqlCreateS3 = "";
                                    try
                                    {
                                        string idsS3 = "'" + string.Join(",", id.ToArray()).Replace(",", "','") + "'";
                                        sqlCreateS3 = sqlS3P + " and trim(upper(d.COMPANY)) in (" + idsS3 + ")";
                                        DataTable dtCreateS3 = OSPS.getDataTable(sqlCreateS3, v.hrlink());
                                        if (dtCreateS3.Rows.Count > 0)
                                        {
                                            OSPS.PutDataTableWithArrayToDb(ref dtCreateS3, v.innternallink(), false, pt_location, 0, sqlCreateS3);
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients addresses see stage 3 parallel loop - " + e.Message + " | SQL - " + sqlCreateS3, 3);
                                    }
                                });
                            }
                            catch (Exception e)
                            {
                                SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients addresses see stage 3 - " + e.Message, 3);
                            }
                        }
                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Addresses Info for Clients was pulled", 3);
                        return "3";
                    });
                    tasks[3] = task3;

                    ///////// Stage 4 Taxes Canada PS_CAN_TAX_DATA
                    Task<string> task4 = Task.Factory.StartNew(() =>
                    {
                        //--------------------------- Getting PS_CAN_TAX_DATA snap shot
                        string sqlS4C = @"SELECT count(object_name) as x FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE') AND OWNER = 'RISK_ANALYTICS'
                               and object_name IN('" + pt_tax + @"')";
                        tables_c = OSPS.getDataCount(sqlS4C, v.innternallink());
                        if (tables_c != 1)
                        {
                            task0.Wait();
                            /////////////////////////// results table initialization
                            string sqlResultsCreationS4 = @"CREATE TABLE " + pt_tax + @"     
                                                        (
                                                        EMPLID nvarchar2(250),
                                                        COMPANY nvarchar2(250),
                                                        EFFDT nvarchar2(250),
                                                        SPECIAL_CIT_STATUS nvarchar2(250),
                                                        CIT_ADDL_AMT nvarchar2(250),
                                                        CIT_ADDL_PCT nvarchar2(250),
                                                        CIT_NET_CLAIM_AMT nvarchar2(250),
                                                        TD1_ADJUST nvarchar2(250),
                                                        CIT_PRESCR_AREA nvarchar2(250),
                                                        CIT_TAX_CREDITS nvarchar2(250),
                                                        CIT_SPECIAL_LTRS nvarchar2(250),
                                                        CIT_FACTOR_Y nvarchar2(250),
                                                        CIT_FACTOR_TH nvarchar2(250),
                                                        SPECIAL_QIT_STATUS nvarchar2(250),
                                                        QIT_ADDL_AMT nvarchar2(250),
                                                        QIT_ADDL_PCT nvarchar2(250),
                                                        QIT_NET_CLAIM_AMT nvarchar2(250),
                                                        QIT_OTHER_DEDUCTS nvarchar2(250),
                                                        QIT_TAX_CREDITS nvarchar2(250),
                                                        QIT_SPECIAL_LTRS nvarchar2(250),
                                                        QIT_PRESCR_AREA nvarchar2(250),
                                                        CPP_SUBJECT_MONTHS nvarchar2(250),
                                                        UI_EXEMPT nvarchar2(250),
                                                        PAYROLL_TAX_EXEMPT nvarchar2(250),
                                                        WAGE_LOSS_PLAN nvarchar2(250),
                                                        LAST_ACTION nvarchar2(250),
                                                        CIT_ANNUAL_COMM nvarchar2(250),
                                                        CIT_ANNUAL_EXP nvarchar2(250),
                                                        QIT_ANNUAL_COMM nvarchar2(250),
                                                        QIT_ANNUAL_EXP nvarchar2(250),
                                                        LCF_AMT nvarchar2(250),
                                                        UI_YEARLY_AMT nvarchar2(250),
                                                        CIT_F_FACTOR_EE nvarchar2(250),
                                                        CROSS_PROVINCE nvarchar2(250),
                                                        USE_PROV_OF_RES nvarchar2(250),
                                                        PROVINCE nvarchar2(250),
                                                        STATUS_INDIAN nvarchar2(250),
                                                        NON_INDEX_AMT nvarchar2(250),
                                                        CREATION_DT nvarchar2(250),
                                                        QPIP_EXEMPT nvarchar2(250),
                                                        QC_HLTH_EXMPT nvarchar2(250),
                                                        HIST_CPP_NLGRS_YTD nvarchar2(250),
                                                        HIST_CPP_TAX_YTD nvarchar2(250),
                                                        HIST_CPP_TXGRS_YTD nvarchar2(250),
                                                        HIST_EI_TAX_YTD nvarchar2(250),
                                                        HIST_EI_TXGRS_YTD nvarchar2(250),
                                                        HIST_QPE_TAX_YTD nvarchar2(250),
                                                        HIST_QPE_TXGRS_YTD nvarchar2(250),
                                                        HIST_QPP_NLGRS_YTD nvarchar2(250),
                                                        HIST_QPP_TAX_YTD nvarchar2(250),
                                                        HIST_QPP_TXGRS_YTD nvarchar2(250),
                                                        PCT_EXEMPT nvarchar2(250),
                                                        SUBJECT_CPP nvarchar2(250),
                                                        USE_FOR_CPP nvarchar2(250),
                                                        MAXDT nvarchar2(250)
                                                        )";
                            OSPS.ExecuteSQL(sqlResultsCreationS4, v.innternallink());
                            try
                            {
                                string sqlS4P = @"select b.* FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_DATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT";
                                Parallel.ForEach<List<string>>((IEnumerable<List<string>>)stringListList, new ParallelOptions { MaxDegreeOfParallelism = 8 }, id =>
                                {
                                    string sqlCreateS4 = "";
                                    try
                                    {
                                        string idsS4 = "'" + string.Join(",", id.ToArray()).Replace(",", "','") + "'";
                                        sqlCreateS4 = sqlS4P + " and trim(upper(b.COMPANY)) in (" + idsS4 + ")";
                                        DataTable dtCreateS4 = OSPS.getDataTable(sqlCreateS4, v.hrlink());
                                        if (dtCreateS4.Rows.Count > 0)
                                        {
                                            OSPS.PutDataTableWithArrayToDb(ref dtCreateS4, v.innternallink(), false, pt_tax, 0, sqlCreateS4);
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients tax info see stage 4 parallel loop - " + e.Message + " | SQL - " + sqlCreateS4, 4);
                                    }
                                });
                            }
                            catch (Exception e)
                            {
                                SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients tax info see stage 4 - " + e.Message, 4);
                            }
                        }
                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Tax Info for Clients was pulled", 4);
                        return "4";
                    });
                    tasks[4] = task4;

                    ///////// Stage 5 Taxes 2 Canada PS_CAN_TAX_PRVDATA
                    Task<string> task5 = Task.Factory.StartNew(() =>
                    {
                        //--------------------------- GettingPS_CAN_TAX_PRVDATA snap shot
                        string sqlS5C = @"SELECT count(object_name) as x FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE') AND OWNER = 'RISK_ANALYTICS'
                               and object_name IN('" + pt_tax2 + @"')";
                        tables_c = OSPS.getDataCount(sqlS5C, v.innternallink());
                        if (tables_c != 1)
                        {
                            task0.Wait();
                            /////////////////////////// results table initialization
                            string sqlResultsCreationS5 = @"CREATE TABLE " + pt_tax2 + @"     
                                                        (
                                                        EMPLID nvarchar2(250),
                                                        COMPANY nvarchar2(250),
                                                        EFFDT nvarchar2(250),
                                                        PROVINCE nvarchar2(250),
                                                        CIT_NET_CLAIM_AMT nvarchar2(250),
                                                        TD1_ADJUST nvarchar2(250),
                                                        CIT_PRESCR_AREA nvarchar2(250),
                                                        CIT_TAX_CREDITS nvarchar2(250),
                                                        CIT_SPECIAL_LTRS nvarchar2(250),
                                                        CIT_FACTOR_Y nvarchar2(250),
                                                        CIT_FACTOR_TH nvarchar2(250),
                                                        LCF_AMT nvarchar2(250),
                                                        CIT_F_FACTOR_EE nvarchar2(250),
                                                        PIT_K3P_AMOUNT nvarchar2(250),
                                                        NON_INDEX_AMT nvarchar2(250),
                                                        CREATION_DT nvarchar2(250),
                                                        MAXDT nvarchar2(250)
                                                        )";
                            OSPS.ExecuteSQL(sqlResultsCreationS5, v.innternallink());
                            try
                            {
                                string sqlS5P = @"select b.* FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_PRVDATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT";
                                Parallel.ForEach<List<string>>((IEnumerable<List<string>>)stringListList, new ParallelOptions { MaxDegreeOfParallelism = 8 }, id =>
                                {
                                    string sqlCreateS5 = "";
                                    try
                                    {
                                        string idsS5 = "'" + string.Join(",", id.ToArray()).Replace(",", "','") + "'";
                                        sqlCreateS5 = sqlS5P + " and trim(upper(b.COMPANY)) in (" + idsS5 + ")";
                                        DataTable dtCreateS5 = OSPS.getDataTable(sqlCreateS5, v.hrlink());
                                        OSPS.PutDataTableWithArrayToDb(ref dtCreateS5, v.innternallink(), false, pt_tax2, 0, sqlCreateS5);
                                    }
                                    catch (Exception e)
                                    {
                                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients tax info 2 see stage 5  parallel loop - " + e.Message + " | SQL - " + sqlCreateS5, 5);
                                    }
                                });
                            }
                            catch (Exception e)
                            {
                                SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients tax info 2 see stage 5 - " + e.Message, 5);
                            }
                        }
                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Tax Info Table 2 for Clients was pulled", 5);
                        return "5";
                    });
                    tasks[5] = task5;

                    ///////// Stage 6 Employees
                    Task<string> task6 = Task.Factory.StartNew(() =>
                    {
                        //--------------------------- Getting PS_EMPLOYEES snap shot
                        string sqlS6C = @"SELECT count(object_name) as x FROM ALL_OBJECTS WHERE OBJECT_TYPE IN ('TABLE') AND OWNER = 'RISK_ANALYTICS'
                               and object_name IN('" + pt_employees + @"')";
                        tables_c = OSPS.getDataCount(sqlS6C, v.innternallink());
                        if (tables_c != 1)
                        {
                            task0.Wait();
                            /////////////////////////// results table initialization
                            string sqlResultsCreationS6 = @"CREATE TABLE " + pt_employees + @"     
                                                        (
                                                        EMPLID nvarchar2(250),
                                                        EMPL_RCD nvarchar2(250),
                                                        PF_CLIENT_EIN nvarchar2(250),
                                                        PF_DIV nvarchar2(250),
                                                        PF_CORP nvarchar2(250),
                                                        PF_CLIENT nvarchar2(250),
                                                        BIRTHDATE nvarchar2(250),
                                                        BIRTHPLACE nvarchar2(250),
                                                        DT_OF_DEATH nvarchar2(250),
                                                        COUNTRY_NM_FORMAT nvarchar2(250),
                                                        NAME nvarchar2(250),
                                                        NAME_INITIALS nvarchar2(250),
                                                        NAME_PREFIX nvarchar2(250),
                                                        NAME_SUFFIX nvarchar2(250),
                                                        NAME_ROYAL_PREFIX nvarchar2(250),
                                                        NAME_ROYAL_SUFFIX nvarchar2(250),
                                                        NAME_TITLE nvarchar2(250),
                                                        LAST_NAME_SRCH nvarchar2(250),
                                                        FIRST_NAME_SRCH nvarchar2(250),
                                                        LAST_NAME nvarchar2(250),
                                                        FIRST_NAME nvarchar2(250),
                                                        MIDDLE_NAME nvarchar2(250),
                                                        SECOND_LAST_SRCH nvarchar2(250),
                                                        SECOND_LAST_NAME nvarchar2(250),
                                                        NAME_AC nvarchar2(250),
                                                        PREF_FIRST_NAME nvarchar2(250),
                                                        LAST_NAME_PREF_NLD nvarchar2(250),
                                                        COUNTRY nvarchar2(250),
                                                        ADDRESS1 nvarchar2(250),
                                                        ADDRESS2 nvarchar2(250),
                                                        ADDRESS3 nvarchar2(250),
                                                        ADDRESS4 nvarchar2(250),
                                                        CITY nvarchar2(250),
                                                        NUM1 nvarchar2(250),
                                                        NUM2 nvarchar2(250),
                                                        HOUSE_TYPE nvarchar2(250),
                                                        ADDR_FIELD1 nvarchar2(250),
                                                        ADDR_FIELD2 nvarchar2(250),
                                                        ADDR_FIELD3 nvarchar2(250),
                                                        COUNTY nvarchar2(250),
                                                        STATE nvarchar2(250),
                                                        POSTAL nvarchar2(250),
                                                        GEO_CODE nvarchar2(250),
                                                        IN_CITY_LIMIT nvarchar2(250),
                                                        HOME_PHONE nvarchar2(250),
                                                        NATIONAL_ID_TYPE nvarchar2(250),
                                                        NATIONAL_ID nvarchar2(250),
                                                        SEX nvarchar2(250),
                                                        MAR_STATUS nvarchar2(250),
                                                        HIGHEST_EDUC_LVL nvarchar2(250),
                                                        FT_STUDENT nvarchar2(250),
                                                        MILITARY_STATUS nvarchar2(250),
                                                        US_WORK_ELIGIBILTY nvarchar2(250),
                                                        MILIT_SITUATN_FRA nvarchar2(250),
                                                        DISABLED nvarchar2(250),
                                                        DISABLED_VET nvarchar2(250),
                                                        ETHNIC_GROUP nvarchar2(250),
                                                        CITIZENSHIP_STATUS nvarchar2(250),
                                                        ORIG_HIRE_DT nvarchar2(250),
                                                        PER_ORG nvarchar2(250),
                                                        BENEFIT_RCD_NBR nvarchar2(250),
                                                        CMPNY_SENIORITY_DT nvarchar2(250),
                                                        SERVICE_DT nvarchar2(250),
                                                        HOME_HOST_CLASS nvarchar2(250),
                                                        LAST_INCREASE_DT nvarchar2(250),
                                                        OWN_5PERCENT_CO nvarchar2(250),
                                                        BUSINESS_TITLE nvarchar2(250),
                                                        PROBATION_DT nvarchar2(250),
                                                        EFFDT nvarchar2(250),
                                                        EFFSEQ nvarchar2(250),
                                                        HIRE_DT nvarchar2(250),
                                                        EXPECTED_RETURN_DT nvarchar2(250),
                                                        TERMINATION_DT nvarchar2(250),
                                                        LAST_DATE_WORKED nvarchar2(250),
                                                        REPORTS_TO nvarchar2(250),
                                                        SUPERVISOR_ID nvarchar2(250),
                                                        BUSINESS_UNIT nvarchar2(250),
                                                        DEPTID nvarchar2(250),
                                                        JOBCODE nvarchar2(250),
                                                        POSITION_NBR nvarchar2(250),
                                                        EMPL_STATUS nvarchar2(250),
                                                        ACTION nvarchar2(250),
                                                        ACTION_DT nvarchar2(250),
                                                        ACTION_REASON nvarchar2(250),
                                                        LOCATION nvarchar2(250),
                                                        JOB_ENTRY_DT nvarchar2(250),
                                                        DEPT_ENTRY_DT nvarchar2(250),
                                                        POSITION_ENTRY_DT nvarchar2(250),
                                                        SHIFT nvarchar2(250),
                                                        REG_TEMP nvarchar2(250),
                                                        FULL_PART_TIME nvarchar2(250),
                                                        FLSA_STATUS nvarchar2(250),
                                                        OFFICER_CD nvarchar2(250),
                                                        COMPANY nvarchar2(250),
                                                        PAYGROUP nvarchar2(250),
                                                        EMPL_TYPE nvarchar2(250),
                                                        HOLIDAY_SCHEDULE nvarchar2(250),
                                                        STD_HOURS nvarchar2(250),
                                                        STD_HRS_FREQUENCY nvarchar2(250),
                                                        REG_REGION nvarchar2(250),
                                                        PAID_HOURS nvarchar2(250),
                                                        PAID_FTE nvarchar2(250),
                                                        PAID_HRS_FREQUENCY nvarchar2(250),
                                                        FTE nvarchar2(250),
                                                        EEO_CLASS nvarchar2(250),
                                                        SAL_ADMIN_PLAN nvarchar2(250),
                                                        GRADE nvarchar2(250),
                                                        GRADE_ENTRY_DT nvarchar2(250),
                                                        STEP nvarchar2(250),
                                                        STEP_ENTRY_DT nvarchar2(250),
                                                        GL_PAY_TYPE nvarchar2(250),
                                                        COMP_FREQUENCY nvarchar2(250),
                                                        COMPRATE nvarchar2(250),
                                                        CHANGE_AMT nvarchar2(250),
                                                        CHANGE_PCT nvarchar2(250),
                                                        ANNUAL_RT nvarchar2(250),
                                                        MONTHLY_RT nvarchar2(250),
                                                        DAILY_RT nvarchar2(250),
                                                        HOURLY_RT nvarchar2(250),
                                                        ANNL_BENEF_BASE_RT nvarchar2(250),
                                                        SHIFT_RT nvarchar2(250),
                                                        SHIFT_FACTOR nvarchar2(250),
                                                        CURRENCY_CD nvarchar2(250),
                                                        DIRECTLY_TIPPED nvarchar2(250),
                                                        PAY_SYSTEM_FLG nvarchar2(250),
                                                        SETID_DEPT nvarchar2(250),
                                                        SETID_JOBCODE nvarchar2(250),
                                                        SETID_LOCATION nvarchar2(250),
                                                        SETID_SALARY nvarchar2(250),
                                                        GP_PAYGROUP nvarchar2(250),
                                                        GP_ELIG_GRP nvarchar2(250),
                                                        CUR_RT_TYPE nvarchar2(250),
                                                        GP_ASOF_DT_EXG_RT nvarchar2(250),
                                                        JOB_INDICATOR nvarchar2(250),
                                                        PAY_UNION_FEE nvarchar2(250),
                                                        UNION_CD nvarchar2(250),
                                                        BARG_UNIT nvarchar2(250),
                                                        UNION_SENIORITY_DT nvarchar2(250),
                                                        ENTRY_DATE nvarchar2(250),
                                                        LABOR_AGREEMENT nvarchar2(250),
                                                        EMPL_CTG nvarchar2(250),
                                                        EMPL_CTG_L1 nvarchar2(250),
                                                        EMPL_CTG_L2 nvarchar2(250),
                                                        SETID_LBR_AGRMNT nvarchar2(250),
                                                        WPP_STOP_FLAG nvarchar2(250),
                                                        LABOR_FACILITY_ID nvarchar2(250),
                                                        LBR_FAC_ENTRY_DT nvarchar2(250),
                                                        LAYOFF_EXEMPT_FLAG nvarchar2(250),
                                                        LAYOFF_EXEMPT_RSN nvarchar2(250),
                                                        VALUE_1_FRA nvarchar2(250),
                                                        VALUE_2_FRA nvarchar2(250),
                                                        VALUE_3_FRA nvarchar2(250),
                                                        VALUE_4_FRA nvarchar2(250),
                                                        VALUE_5_FRA nvarchar2(250),
                                                        GVT_SCD_RETIRE nvarchar2(250),
                                                        GVT_MAND_RET_DT nvarchar2(250),
                                                        GVT_SCD_TSP nvarchar2(250),
                                                        GVT_SCD_SEVPAY nvarchar2(250),
                                                        GVT_DT_LEI nvarchar2(250),
                                                        GVT_PAY_BASIS nvarchar2(250),
                                                        GVT_WGI_STATUS nvarchar2(250),
                                                        GVT_WGI_DUE_DATE nvarchar2(250),
                                                        GVT_INTRM_DAYS_WGI nvarchar2(250),
                                                        GVT_LOCALITY_ADJ nvarchar2(250),
                                                        GVT_WORK_SCHED nvarchar2(250),
                                                        GVT_SEVPAY_PRV_WKS nvarchar2(250),
                                                        GVT_BIWEEKLY_RT nvarchar2(250),
                                                        GVT_STEP nvarchar2(250),
                                                        GVT_RTND_PAY_PLAN nvarchar2(250),
                                                        GVT_RTND_SAL_PLAN nvarchar2(250),
                                                        GVT_RTND_GRADE nvarchar2(250),
                                                        GVT_RTND_STEP nvarchar2(250),
                                                        GVT_RTND_GVT_STEP nvarchar2(250),
                                                        GVT_RTND_GRADE_BEG nvarchar2(250),
                                                        GVT_RTND_GRADE_EXP nvarchar2(250),
                                                        GVT_TEMP_PRO_EXPIR nvarchar2(250),
                                                        GVT_TEMP_PSN_EXPIR nvarchar2(250),
                                                        GVT_DETAIL_EXPIRES nvarchar2(250),
                                                        GVT_SABBATIC_EXPIR nvarchar2(250),
                                                        GVT_TYPE_OF_APPT nvarchar2(250),
                                                        GVT_APPT_EXPIR_DT nvarchar2(250),
                                                        GVT_CAREER_CNV_DUE nvarchar2(250),
                                                        GVT_SUPV_PROB_DT nvarchar2(250),
                                                        GVT_SES_PROB_DT nvarchar2(250),
                                                        GVT_SEC_CLR_STATUS nvarchar2(250),
                                                        GVT_CLRNCE_STAT_DT nvarchar2(250),
                                                        EEO1CODE nvarchar2(250),
                                                        EEO4CODE nvarchar2(250),
                                                        EEO5CODE nvarchar2(250),
                                                        EEO6CODE nvarchar2(250),
                                                        EEO_JOB_GROUP nvarchar2(250),
                                                        JOB_FAMILY nvarchar2(250),
                                                        JOB_KNOWHOW_POINTS nvarchar2(250),
                                                        JOB_ACCNTAB_POINTS nvarchar2(250),
                                                        JOB_PROBSLV_POINTS nvarchar2(250),
                                                        JOB_POINTS_TOTAL nvarchar2(250),
                                                        JOB_KNOWHOW_PCT nvarchar2(250),
                                                        JOB_ACCNTAB_PCT nvarchar2(250),
                                                        JOB_PROBSLV_PCT nvarchar2(250),
                                                        IPEDSSCODE nvarchar2(250),
                                                        GVT_ORG_TTL_DESCR nvarchar2(250),
                                                        MANAGER_ID nvarchar2(250),
                                                        EEO4_FUNCTION nvarchar2(250),
                                                        ASOFDATE nvarchar2(250),
                                                        FROMDATE nvarchar2(250),
                                                        JOBTITLE nvarchar2(250),
                                                        JOBTITLE_ABBRV nvarchar2(250),
                                                        DEPTNAME nvarchar2(250),
                                                        DEPTNAME_ABBRV nvarchar2(250),
                                                        REHIRE_DT nvarchar2(250),
                                                        WORK_PHONE nvarchar2(250),
                                                        NID_COUNTRY nvarchar2(250),
                                                        GVT_OVERTIME_RT nvarchar2(250),
                                                        GVT_RTND_PAY_BASIS nvarchar2(250),
                                                        SEC_CLEARANCE_TYPE nvarchar2(250),
                                                        TWO_RACES_IND_USA nvarchar2(250),
                                                        MAXDT nvarchar2(250),
                                                        MAXSEQ nvarchar2(250),
                                                        MAXRCD nvarchar2(250),
                                                        CANADA_COID nvarchar2(250)
                                                        )";
                            OSPS.ExecuteSQL(sqlResultsCreationS6, v.innternallink());
                            try
                            {
                                string sqlS6P = @"
                                                select d.* from (
                                                select c.*, coalesce(bbb.COMPANY,bbbb.COMPANY,'MISSING') as CANADA_COID from ( 
                                                select b.* from (select a.*, 
                                                MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT,
                                                MAX(a.EFFSEQ) OVER(PARTITION BY a.EMPLID, a.EFFDT) AS MAXSEQ,
                                                MAX(a.EMPL_RCD) OVER(PARTITION BY a.EMPLID, a.EFFDT, a.EFFSEQ) AS MAXRCD FROM PS_EMPLOYEES a 
                                                where a.COMPANY IN (REPLACE)
                                                ) b WHERE b.MAXDT = b.EFFDT AND b.MAXSEQ = b.EFFSEQ AND b.MAXRCD = b.EMPL_RCD 
                                                ) c
                                                left join (select distinct b.COMPANY  FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_DATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) bbb on trim(upper(c.COMPANY)) = trim(upper(bbb.COMPANY))
                                                left join (select distinct b.COMPANY  FROM (select a.*, MAX(a.EFFDT) OVER(PARTITION BY a.EMPLID) AS MAXDT from PS_CAN_TAX_PRVDATA a where a.EFFDT <= TO_DATE('" + v.enddate + @"','mm/dd/yyyy') ORDER BY a.EMPLID, a.EFFDT DESC) b WHERE b.MAXDT = b.EFFDT
                                                ) bbbb on trim(upper(c.COMPANY)) = trim(upper(bbbb.COMPANY))
                                                ) d where d.CANADA_COID <> 'MISSING'";
                                Parallel.ForEach<List<string>>((IEnumerable<List<string>>)stringListList, new ParallelOptions { MaxDegreeOfParallelism = 8 }, id =>
                                {
                                    string sqlCreateS6 = "";
                                    try
                                    {
                                        string idsS6 = "'" + string.Join(",", id.ToArray()).Replace(",", "','") + "'";
                                        sqlCreateS6 = sqlS6P.Replace("REPLACE", idsS6) + " and trim(upper(d.COMPANY)) in (" + idsS6 + ")";
                                        DataTable dtCreateS6 = OSPS.getDataTable(sqlCreateS6, v.hrlink());
                                        if (dtCreateS6.Rows.Count > 0)
                                        {
                                            OSPS.PutDataTableWithArrayToDb(ref dtCreateS6, v.innternallink(), false, pt_employees, 0, sqlCreateS6);
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients addresses see stage 3 parallel loop - " + e.Message + " | SQL - " + sqlCreateS6, 6);
                                    }
                                });
                            }
                            catch (Exception e)
                            {
                                SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "There was an issue in pulling Clients addresses see stage 3 - " + e.Message, 6);
                            }
                        }
                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Employees Info for Clients was pulled", 6);
                        return "6";
                    });
                    tasks[6] = task6;

                    Task<string> task7 = Task.Factory.StartNew(() =>
                    {
                        task0.Wait();
                        task1.Wait();
                        task2.Wait();
                        task3.Wait();
                        task4.Wait();
                        task5.Wait();
                        task6.Wait();
                        string filename = v.env + "Canada_Report_" + v.username.Replace(" ", "_") + "_" + v.current_date() + ".xlsx";
                        string sheetname = "Canada_Report";
                        string sqlget = @"
                        select s0.* from (
                        select
                        i.PFCORP as ""PF Corp"",
                        l.COMPANY as ""Company ID"",
                        i.CLIENTID as ""Client ID"",
                        i.LEGALNAME as ""Client Legal Name"",
                        l.DESCR as ""Client DBA Name"",
                        case when trim(upper(coalesce(to_char(m.ADDRESS2), ''))) = '' then trim(to_char(m.ADDRESS1)) else trim(to_char(m.ADDRESS1)) || ', ' || trim(upper(to_char(m.ADDRESS2))) end as ""Client Mailing Address"",
                        trim(to_char(m.CITY)) as ""Mailing City"",
                        trim(to_char(m.STATE)) as ""Mailing State"",
                        trim(to_char(m.POSTAL)) as ""Postal Code"",
                        j.EMPLID as ""Employee ID"",
                        e.NAME as ""Employee Name"",
                        l.COUNTRY as ""Country"",
                        l.STATE as ""State"",
                        to_char(to_date(j.EFFDT, 'DD-MON-YY'), 'mm/dd/yyyy') as ""Effective Date"",
                        j.EMPL_STATUS as ""Employee Status"",
                        j.EMPL_CLASS as ""Employee Class"",
                        e.BUSINESS_TITLE as ""Bussiness Title"",
                        case when trim(upper(j.EMPL_CLASS)) in ('K1','K1D','K1E','U') then 'Yes' else 'No' end as ""Excluded"",
                        j.ACTION as ""Action"",
                        j.ACTION_REASON as ""Action Reason"",
                        j.LOCATION as ""Location"",
                        j.TAX_LOCATION_CD as ""Tax Location CD"",
                        to_char(to_date(j.JOB_ENTRY_DT, 'DD-MON-YY'), 'mm/dd/yyyy') as ""Job Entry Date"",
                        case when trim(upper(coalesce(to_char(l.ADDRESS1),''))) = '' then trim(coalesce(to_char(e.ADDRESS1),'')) || ' ' || trim(coalesce(to_char(e.ADDRESS2), '')) else trim(coalesce(to_char(l.ADDRESS1), '')) || ' ' || trim(coalesce(to_char(l.ADDRESS2), '')) end as ""Work Location Address"",
                        case when trim(upper(coalesce(to_char(l.ADDRESS1),''))) = '' then e.CITY else l.CITY end as ""Work City"",
                        case when trim(upper(coalesce(to_char(l.ADDRESS1),''))) = '' then e.STATE else l.STATE end as ""Work Province"",
                        case when trim(upper(coalesce(to_char(l.ADDRESS1),''))) = '' then e.POSTAL else l.POSTAL end as ""Work Postal Code""
                        from " + pt_jobs + @" j
                        left
                        join " + pt_location + @" l on trim(upper(j.location)) = trim(upper(l.location))
                        left
                        join " + idstable + @" i on trim(upper(j.company)) = trim(upper(i.coid))
                        left
                        join " + pt_mailing + @" m on trim(upper(j.company)) = trim(upper(m.company))
                        left
                        join " + pt_employees + @" e on trim(upper(j.emplid)) = trim(upper(e.emplid)) and trim(upper(j.company)) = trim(upper(e.company))
                        ) s0
                        where trim(upper(s0.""Country"")) in ('CAN')
                        and trim(upper(s0.""Employee Status"")) in ('A')
                        and trim(upper(s0.""Action Reason"")) Not In('NON')
                        order by s0.""Company ID"" ";
                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Starting to create excel file now", 7);
                        DataTable dataTable = OSPS.getDataTable(sqlget, v.innternallink());
                        PXMLP.ExportDataTableToExcel(ref dataTable, filename, sheetname, false, true, 2, 1);
                        PXMLP.ExcelFixWorkBook(filename, sheetname, 87, 224, 89, "Times New Roman", 14, dataTable.Columns.Count);
                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Excel file was created and ready for download", 7);
                        l.Add(filename);
                        SRSD.sendInfoToClient(v.signalr, v.channel, v.eventname, "Downloading file now", 7, l);
                        return "7";
                    });
                    tasks[7] = task7;

                    Task<string> task8 = Task.Factory.StartNew(() =>
                    {
                        ///////////////////////// Log addition
                        try
                        {
                            OSPS.LogActivities(new ExcelServicesModels.LogActivitiesObject()
                            {
                                username = v.username,
                                applicationname = "risk website",
                                processname = "process:excel; name: Canada Report; file:",
                                sqlstring1 = "|",
                                sqlstring2 = "|",
                                sqlstring3 = "|",
                                sqlstring4 = "|",
                                sqlstring5 = "|",
                                totalseconds = Convert.ToInt32((DateTime.Now - StartTime).TotalSeconds)
                            }, v.innternallink());
                        }
                        catch
                        {
                            l.Add("Issue with log");
                        }
                        return "8";
                    });
                    tasks[8] = task8;
                    Task.WaitAll(tasks.ToArray());
                    return l;
                }
                ReturnArray = runningasyncprocess(ReturnArray);
                return ReturnArray;
            }
            catch (Exception e)
            {
                ReturnArray.Add(e.Message);
                ReturnArray.Add(e.Source);
                ReturnArray.Add(e.HelpLink);
                return ReturnArray;
            }
        }
        public string DeleteExcelFile(string filename)
        {
            if (!File.Exists(filename))
                return "f";
            try
            {
                Thread.Sleep(5000);
                File.Delete(filename);
                return "t";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        void InitilizeClientIDs(string innternallink, string hrlink, string qryname, string idstable, string basetable,
                List<string> tables, string fileloaded, string sql_clients, string clientid, string product, string filenameinitial, bool activeonly, bool includetrinet = false)
        {
            string ids_column_name = "CLIENT";
            Task<string> task0 = Task.Factory.StartNew(() =>
            {
                var REF = new ReadExcelFile();
                var CEF = new CustomExcel();
                var OSPS = new OracleStoredProceduresServices();

                Task[] tasks_inner_0 = new Task[4];
                Task<string> ti_0 = Task.Run(() =>
                {
                    try
                    {
                        Parallel.ForEach(tables, t =>
                        {
                            OSPS.RemoveTableViewTrailingServer(t, innternallink);
                        });
                    }
                    catch
                    {

                    }
                    return "0-0";
                });
                tasks_inner_0[0] = ti_0;
                ti_0.Wait();

                Task<string> ti_1 = Task.Run(() =>
                {
                    ti_0.Wait();
                    ///////////// Step 0-1 loaded all clients
                    string sql = sql_clients;
                    if (fileloaded == null || fileloaded == String.Empty)
                    {
                        if (clientid == null || clientid == String.Empty)
                        {
                            switch (product)
                            {
                                case "TriNet III – Passport":
                                    sql = "select final.* from (" + sql + ") final where final.T2PEOID = 'PAS' and final.STDT is not null";
                                    break;
                                case "TriNet II – SOI":
                                    sql = "select final.* from (" + sql + ") final where final.T2PEOID = 'SOI' and final.STDT is not null";
                                    break;
                                case "TriNet I – Accord":
                                    sql = "select final.* from (" + sql + ") final where final.T2PEOID = 'ACD' and final.STDT is not null";
                                    break;
                                case "TriNet IV – Ambrose":
                                    sql = "select final.* from (" + sql + ") final where final.T2PEOID = 'AMB' and final.STDT is not null";
                                    break;
                                case "TriNet XI – None medical":
                                    sql = "select final.* from (" + sql + ") final where final.T2PEOID = 'ALP' and final.STDT is not null";
                                    break;
                                case "All":
                                    sql = "select final.* from (" + sql + ") final where final.STDT is not null";
                                    break;
                                default:
                                    sql = "select final.* from (" + sql + ") final where final.T2PEOID = 'ALP' and final.STDT is not null";
                                    break;
                            }
                        }
                        else
                        {
                            sql = "select final.* from (" + sql + ") final where final.COID = '" + clientid + "' or final.CLIENTID = '" + clientid + "'";
                        }
                        /////////////////////////////// Data from HRLITER for CLIENTS INFO
                        if (activeonly == true)
                        {
                            sql += " and final.TERMDT is null";
                        }
                        DataTable dataTable = OSPS.getDataTable(sql, hrlink);
                        OSPS.PutDataTableWithArrayToDb(ref dataTable, innternallink, true, idstable, 0, "test");
                        OSPS.PutDataTableWithArrayToDb(ref dataTable, innternallink, false, idstable, 0, "test");
                    }
                    else
                    {
                        /////////////////////////////// Data from ADPROD for CLIENTS INFO
                        if (includetrinet != true)
                        {
                            sql = "create table " + idstable + " as select * from ps_clients_final where COID is not null and lower(legalname) not like '%trinet%'";
                        }
                        else
                        {
                            sql = "create table " + idstable + " as select * from ps_clients_final where COID is not null";
                        }
                        if (activeonly == true)
                        {
                            sql += " and trim(TERMDT) is null";
                        }
                        ////// // // ////// // //Trace.WriteLine(sql);
                        OSPS.ExecuteSQL(sql, innternallink);
                    }
                    return "0-1";
                });
                tasks_inner_0[1] = ti_1;
                ti_1.Wait();

                Task<string> ti_2 = Task.Run(() =>
                {
                    ///////////////// Step 0-2 processing clients inputs file, id or product into qryname
                    if (fileloaded == null || fileloaded == String.Empty)
                    {
                        ////////// processing only Product, need to wait on the load
                        if (clientid == null || clientid == String.Empty)
                        {
                            ////////////////////// Essential needs to wait to proceeed forward
                            string sql_Create_IDs = "";
                            switch (product)
                            {
                                case "TriNet III – Passport":
                                    sql_Create_IDs = "insert into " + qryname + " select CLIENTID as CLIENT, COID as REALIDS from " + idstable + " where T2PEOID = 'PAS'";
                                    break;
                                case "TriNet II – SOI":
                                    sql_Create_IDs = "insert into " + qryname + " select CLIENTID as CLIENT, COID as REALIDS from " + idstable + " where T2PEOID = 'SOI'";
                                    break;
                                case "TriNet I – Accord":
                                    sql_Create_IDs = "insert into " + qryname + " select CLIENTID as CLIENT, COID as REALIDS from " + idstable + " where T2PEOID = 'ACD'";
                                    break;
                                case "TriNet IV – Ambrose":
                                    sql_Create_IDs = "insert into " + qryname + " select CLIENTID as CLIENT, COID as REALIDS from " + idstable + " where T2PEOID = 'AMB'";
                                    break;
                                case "TriNet XI – None medical":
                                    sql_Create_IDs = "insert into " + qryname + " select CLIENTID as CLIENT, COID as REALIDS from " + idstable + " where T2PEOID = 'ALP'";
                                    break;
                                case "All":
                                    sql_Create_IDs = "insert into " + qryname + " select CLIENTID as CLIENT, COID as REALIDS from " + idstable;
                                    break;
                                default:
                                    /////// defualting to None medical
                                    sql_Create_IDs = "insert into " + qryname + " select CLIENTID as CLIENT, COID as REALIDS from " + idstable + " where T2PEOID = 'ALP'";
                                    break;
                            }
                            DataTable dataTable = new DataTable();
                            dataTable.Columns.Add(ids_column_name, typeof(String));
                            dataTable.Columns.Add("REALIDS", typeof(String));
                            dataTable.Rows.Add(clientid, "");
                            OSPS.PutDataTableWithArrayToDb(ref dataTable, innternallink, true, qryname, 0, "test");
                            OSPS.ExecuteSQL(sql_Create_IDs, innternallink);
                        }
                        ////////// processing only ID here ignoring Product
                        else
                        {
                            //////// // // ////// // //Trace.WriteLine("I need to ignore selection");
                            DataTable dataTable = new DataTable();
                            dataTable.Columns.Add(ids_column_name, typeof(String));
                            dataTable.Columns.Add("REALIDS", typeof(String));
                            dataTable.Rows.Add(clientid, clientid);
                            OSPS.PutDataTableWithArrayToDb(ref dataTable, innternallink, true, qryname, 0, "test");
                            OSPS.PutDataTableWithArrayToDb(ref dataTable, innternallink, false, qryname, 0, "test");
                        }
                    }
                    //////////// processing only file plus ID if there
                    else
                    {
                        DataTable dataTable = REF.ImportExcelFirstSheetToDataTable(filenameinitial);
                        dataTable.Columns[0].ColumnName = ids_column_name;
                        dataTable.AcceptChanges();
                        dataTable.Columns.Add("REALIDS", typeof(String));
                        if (clientid != null || clientid != String.Empty || clientid.Length != 0)
                        {
                            dataTable.Rows.Add(clientid);
                        }
                        OSPS.PutDataTableWithArrayToDb(ref dataTable, innternallink, true, qryname, 0, "test");
                        OSPS.PutDataTableWithArrayToDb(ref dataTable, innternallink, false, qryname, 0, "test");
                        OSPS.ExecuteSQL("update " + qryname + " set REALIDS = trim(upper(CLIENT))", innternallink);
                        OSPS.ExecuteSQL("delete from " + qryname + " where client is null", innternallink);
                        CEF.DeleteExcelFile(filenameinitial);
                    }
                    return "0-2";
                });
                tasks_inner_0[2] = ti_2;
                ti_2.Wait();
                Task<string> ti_3 = Task.Run(() =>
                {
                    ti_0.Wait();
                    ti_1.Wait();
                    ti_2.Wait();
                    //////////////// normalizing into new table
                    string sql = "create table " + basetable + " as select distinct REALIDS as COID, 0 as PROCESSED  from " + qryname + " where CLIENT is not null";
                    //////// // // ////// // //Trace.WriteLine(sql);
                    OSPS.ExecuteSQL(sql, innternallink);
                    //////// // // ////// // //Trace.WriteLine("Normalizing IDs in table " + basetable);
                    //////// // // ////// // //Trace.WriteLine(sql);
                    ///
                    if (includetrinet != true)
                    {
                        sql = @"delete from " + basetable + @" where COID IN ( 
                                    select distinct COID from so_CLIENTS_FINAL where UPPER(LEGALNAME) like '%TRINET%'
                                    union
                                    select distinct COID from am_CLIENTS_FINAL where UPPER(LEGALNAME) like '%TRINET%'
                                    union
                                    select distinct COID from ac_CLIENTS_FINAL where UPPER(LEGALNAME) like '%TRINET%'
                                    union
                                    select distinct COID from ps_CLIENTS_FINAL where UPPER(LEGALNAME) like '%TRINET%'
                                    )";
                        OSPS.ExecuteSQL(sql, innternallink);
                    }
                    return "0-3";
                });
                ti_3.Wait();
                tasks_inner_0[3] = ti_3;
                Task.WaitAll(tasks_inner_0);
                return "0";
            });
            task0.Wait();
        }
        public class ReadExcelFile
        {
            public DataTable ImportExcelFirstSheetToDataTable(string filePath)
            {
                //Create a new DataTable.
                DataTable dt = new DataTable();
                using (XLWorkbook workBook = new XLWorkbook(filePath))
                {
                    try
                    {
                        //Read the first Sheet from Excel file.
                        IXLWorksheet workSheet = workBook.Worksheet(1);
                        //Loop through the Worksheet rows.
                        bool firstRow = true;
                        foreach (IXLRow row in workSheet.Rows())
                        {
                            //Use the first row to add columns to DataTable.
                            if (firstRow)
                            {
                                foreach (IXLCell cell in row.Cells())
                                {
                                    if (cell.Value.ToString() != null && cell.Value.ToString().Count() > 0)
                                    {
                                        dt.Columns.Add(cell.Value.ToString());
                                    }
                                }
                                firstRow = false;
                            }
                            else
                            {
                                ////Add rows to DataTable.
                                dt.Rows.Add();
                                int i = 0;
                                foreach (IXLCell cell in row.Cells())
                                {

                                    dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();
                                    i++;
                                }
                            }
                        }
                        return dt;
                    }
                    catch (Exception e)
                    {
                        // // // // ////// // //Trace.WriteLine(e.Message);
                        // // // // ////// // //Trace.WriteLine(e.Source);
                        // // // // ////// // //Trace.WriteLine(e.HelpLink);
                        // // // // ////// // //Trace.WriteLine(ex.InnerException);
                        // // // // ////// // //Trace.WriteLine(ex.StackTrace);
                        return dt;

                    }
                }
            }
        }
    }
    public class GeneralProcesses
    {
        public List<List<T>> ChunkBy<T>(ref List<T> source, int chunkSize)
        {
            return source
                .Select((x, i) => new { Index = i, Value = x })
                .GroupBy(x => x.Index / chunkSize)
                .Select(x => x.Select(v => v.Value).ToList())
                .ToList();
        }
    }
    public class OracleStoredProceduresServices
    {
        private int tryings = 10;
        private int sleeptime = 3000;

        public int getDataCount(string sql, string c)
        {
            int trynow = 0;
            int r = -1;
            OracleConnection Conn = new OracleConnection(c);
            OracleCommand OraCommand = Conn.CreateCommand();
            OraCommand.CommandText = sql;
            OraCommand.CommandType = CommandType.Text;
        label:
            trynow++;
            try
            {
                Conn.Open();
                r = Convert.ToInt32(OraCommand.ExecuteScalar());
                Conn.Close();
                Conn.Dispose();
            }
            catch
            {
                Conn.Close();
                if (trynow < tryings)
                {
                    Thread.Sleep(sleeptime);
                    goto label;
                }
                else
                {
                    return -1;
                }
            }
            return r;
        }
        public DataTable getDataTable(string ss, string c)
        {
            int trynow = 0;
            DataTable dt = new DataTable();
            string SQLstr = ss;

            using (OracleConnection Conn = new OracleConnection(c))
            {
                OracleConnection.ClearAllPools();
                using (OracleCommand OraCommand = new OracleCommand(SQLstr, Conn))
                {
                //DataSet ds = new DataSet();
                label:
                    trynow++;
                    try
                    {

                        Conn.Open();
                        OracleDataAdapter OraAdapter = new OracleDataAdapter(SQLstr, Conn);
                        OraAdapter.Fill(dt);
                        Conn.Close();
                        Conn.Dispose();
                        OraAdapter.Dispose();
                        //dt = ds.Tables[0];
                        ////// // ////// //Trace.WriteLine("Data pulled " + SQLstr);
                    }
                    catch (Exception ex)
                    {
                        Conn.Close();
                        ////// // ////// //Trace.WriteLine("Data issue " + SQLstr);
                        ////// // ////// //Trace.WriteLine("Data issue here " + ex.Message);
                        if (trynow < tryings)
                        {
                            Thread.Sleep(sleeptime);
                            goto label;
                        }
                        else
                        {
                            DataTable dataTable2 = new DataTable("returnInfo");
                            dataTable2.Columns.Add(new DataColumn()
                            {
                                DataType = Type.GetType("System.String"),
                                ColumnName = "returnInfo",
                                AutoIncrement = false,
                                Caption = "returnInfo",
                                ReadOnly = false,
                                Unique = false
                            });
                            DataRow row = dataTable2.NewRow();
                            row["returnInfo"] = ex.Message;
                            dataTable2.Rows.Add(row);
                            return dataTable2;
                        }
                    }
                }
            }
            return dt;
        }

        public string RemoveTableViewTrailingServer(string tableview, string c)
        {
            int trynow = 0;
            string ReturnInfo = "f";
            OracleConnection Conn = new OracleConnection(c);
            OracleCommand OraCommand = Conn.CreateCommand();
            OraCommand.CommandText = "RemoveTemporaryObjectsTV";
            OraCommand.CommandType = CommandType.StoredProcedure;
            OracleParameter TV = new OracleParameter();
            TV.ParameterName = "TV";
            TV.OracleDbType = OracleDbType.Varchar2;
            TV.Direction = ParameterDirection.Input;
            TV.Value = tableview;
            OraCommand.Parameters.Add(TV);
        label:
            trynow++;
            try
            {
                Conn.Open();
                OraCommand.ExecuteNonQuery();
                ReturnInfo = "t";
                ////////// // ////// //Trace.WriteLine("Done Deleting");
                Conn.Close();
                Conn.Dispose();
            }
            catch (Exception ex)
            {
                Conn.Close();
                //////////// // ////// //Trace.WriteLine(ex.Message);
                if (trynow < tryings)
                {
                    Thread.Sleep(sleeptime);
                    goto label;
                }
                else
                {
                    return ex.Message;
                }
            }
            return ReturnInfo;
        }

        public string PutDataTableWithArrayToDb(ref DataTable dt, string c, Boolean init, string TableName, int processcount, string sql)
        {
            //////string dumpfile = HttpContext.Current.Server.MapPath("~/ManagedFiles") + "/" + TableName + ".txt";
            //////////////// // ////// //Trace.WriteLine(dumpfile);
            //////CustomExcel.DeleteExcelFile(dumpfile);
            int trynow = 0;
            int multiplicator = 1;
            ///////// recreate table here
            ////////////////// // ////// //Trace.WriteLine("????????????????????????????????????");
            if (init == true)
            {
                //////////////// // ////// //Trace.WriteLine("OKOKOKOKOKO");
                return CreateDataTableInServer(ref dt, c, TableName);
            }
            else
            {
            //////////////// // ////// //Trace.WriteLine("!!!!!!!");
            label:
                trynow++;
                if (dt.Rows.Count > 0)
                {
                    // create and open connection object
                    OracleConnection Conn = new OracleConnection(c);
                    Conn.Close();
                    Conn.Open();
                    try
                    {

                        ////http://www.oracle.com/technetwork/issue-archive/2009/09-sep/o59odpnet-085168.html
                        OracleCommand cmd = Conn.CreateCommand();
                        //////// Dictionary<string, dynamic> d = new Dictionary<string, dynamic>();
                        int arr_counter = 0;
                        string sql_command = "INSERT /*+ NOLOGGING PARALLEL(p,21) */ INTO " + TableName + " p (";
                        string temp_sql_command_coloumns = "";
                        string temp_sql_command_arraies = " VALUES (";
                        foreach (DataColumn col in dt.Columns)
                        {
                            arr_counter++;
                            OracleParameter orac_p = new OracleParameter();
                            temp_sql_command_coloumns = temp_sql_command_coloumns + "\"" + col.ColumnName.ToString() + "\"" + ",";
                            temp_sql_command_arraies = temp_sql_command_arraies + ":" + arr_counter + ", ";
                            // //////////////// // ////// //Trace.WriteLine(col.DataType.FullName.ToString().ToUpper());
                            //string[] stringTest = dt.AsEnumerable().Select(r => r.Field<string>(col.ColumnName.ToString())).ToArray();
                            switch (col.DataType.FullName.ToString().ToUpper())
                            {
                                case "SYSTEM.STRING":
                                    string[] stringArrStr = dt.AsEnumerable().Select(r => r.Field<string>(col.ColumnName.ToString())).ToArray();
                                    // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrStr, Formatting.Indented));
                                    orac_p.OracleDbType = OracleDbType.Varchar2;
                                    orac_p.Value = stringArrStr;
                                    if (arr_counter == 1)
                                    {
                                        cmd.ArrayBindCount = stringArrStr.Length;
                                    }
                                    break;
                                case "SYSTEM.DATETIME":
                                    DateTime?[] stringArrDateTime = dt.AsEnumerable().Select(r => r.Field<DateTime?>(col.ColumnName.ToString())).ToArray();
                                    orac_p.OracleDbType = OracleDbType.Date;
                                    orac_p.Value = stringArrDateTime;
                                    // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrDateTime, Formatting.Indented));
                                    if (arr_counter == 1)
                                    {
                                        cmd.ArrayBindCount = stringArrDateTime.Length;
                                    }
                                    break;
                                case "SYSTEM.INT16":
                                    Int16?[] stringArrInt16 = dt.AsEnumerable().Select(r => r.Field<Int16?>(col.ColumnName.ToString())).ToArray();
                                    orac_p.OracleDbType = OracleDbType.Int16;
                                    orac_p.Value = stringArrInt16;
                                    if (arr_counter == 1)
                                    {
                                        cmd.ArrayBindCount = stringArrInt16.Length;
                                    }
                                    break;
                                case "SYSTEM.INT32":
                                    Int32?[] stringArrInt32 = dt.AsEnumerable().Select(r => r.Field<Int32?>(col.ColumnName.ToString())).ToArray();
                                    orac_p.OracleDbType = OracleDbType.Int32;
                                    orac_p.Value = stringArrInt32;
                                    // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrInt32, Formatting.Indented));
                                    if (arr_counter == 1)
                                    {
                                        cmd.ArrayBindCount = stringArrInt32.Length;
                                    }
                                    break;
                                case "SYSTEM.INT64":
                                    Int64?[] stringArrInt64 = dt.AsEnumerable().Select(r => r.Field<Int64?>(col.ColumnName.ToString())).ToArray();
                                    orac_p.OracleDbType = OracleDbType.Int64;
                                    orac_p.Value = stringArrInt64;
                                    // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrInt64, Formatting.Indented));
                                    if (arr_counter == 1)
                                    {
                                        cmd.ArrayBindCount = stringArrInt64.Length;
                                    }
                                    break;
                                case "SYSTEM.DOUBLE":
                                    Double?[] stringArrDouble = dt.AsEnumerable().Select(r => r.Field<Double?>(col.ColumnName.ToString())).ToArray();
                                    orac_p.OracleDbType = OracleDbType.Double;
                                    orac_p.Value = stringArrDouble;
                                    // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrDouble, Formatting.Indented));
                                    if (arr_counter == 1)
                                    {
                                        cmd.ArrayBindCount = stringArrDouble.Length;
                                    }
                                    break;
                                case "SYSTEM.DECIMAL":
                                    Decimal?[] stringArrDecimal = dt.AsEnumerable().Select(r => r.Field<Decimal?>(col.ColumnName.ToString())).ToArray();
                                    orac_p.OracleDbType = OracleDbType.Decimal;
                                    orac_p.Value = stringArrDecimal;
                                    // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrDecimal, Formatting.Indented));
                                    if (arr_counter == 1)
                                    {
                                        cmd.ArrayBindCount = stringArrDecimal.Length;
                                    }
                                    break;
                                case "SYSTEM.SINGLE":
                                    Single?[] stringArrSingle = dt.AsEnumerable().Select(r => r.Field<Single?>(col.ColumnName.ToString())).ToArray();
                                    orac_p.OracleDbType = OracleDbType.Decimal;
                                    orac_p.Value = stringArrSingle;
                                    ////////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrSingle, Formatting.Indented));
                                    if (arr_counter == 1)
                                    {
                                        cmd.ArrayBindCount = stringArrSingle.Length;
                                    }
                                    break;
                                default:
                                    string[] stringArrStrDef = dt.AsEnumerable().Select(r => r.Field<string>(col.ColumnName.ToString())).ToArray();
                                    orac_p.OracleDbType = OracleDbType.Varchar2;
                                    orac_p.Value = stringArrStrDef;
                                    // //////////////// // ////// //Trace.WriteLine(JsonConvert.SerializeObject(stringArrStrDef, Formatting.Indented));
                                    if (arr_counter == 1)
                                    {
                                        cmd.ArrayBindCount = stringArrStrDef.Length;
                                    }
                                    break;
                            }
                            cmd.Parameters.Add(orac_p);
                        }
                        sql_command = sql_command + temp_sql_command_coloumns;
                        sql_command = sql_command.Substring(0, sql_command.Length - 1) + ")";
                        sql_command = sql_command + temp_sql_command_arraies;
                        sql_command = sql_command.Substring(0, sql_command.Length - 2) + ")";
                        cmd.CommandText = sql_command;
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();
                        Conn.Close();
                        Conn.Dispose();
                        return "t";
                    }
                    catch (Exception ex)
                    {
                        if (trynow < (tryings * multiplicator))
                        {
                            goto label;
                        }
                        else
                        {
                            // //Trace.WriteLine(ex.Message);
                            // //Trace.WriteLine("------" + trynow + " Retrial --------");
                            // //Trace.WriteLine(sql);
                            Conn.Close();
                            Conn.Dispose();
                            return ex.Message;
                        }
                    }
                }
                return "done";
            }
        }
        public string CreateDataTableInServer(ref DataTable dt, string c, string TableName)
        {
            ////////// // ////// //Trace.WriteLine("!!!!!!!!!!!!!!!!!!!!!!!!!!! INSIDE");
            int trynow = 0;
            string ReturnInfo = "f";
            string procedureStr = "CREATETABLEFROMMIDLAYER";
            string tablename = TableName;
            string options = "";
            foreach (DataColumn col in dt.Columns)
            {
                options = options + col.ColumnName.ToString() + ":" + col.DataType.FullName.ToString() + "|";
            }
            //Trace.WriteLine(options);
            options = options.Trim().TrimEnd();
            OracleConnection Conn = new OracleConnection(c);
            OracleCommand OraCommand = Conn.CreateCommand();
            OraCommand.CommandText = procedureStr;
            OraCommand.CommandType = CommandType.StoredProcedure;
            OraCommand.Parameters.Add(new OracleParameter("tablename", OracleDbType.Varchar2)).Value = tablename;
            OraCommand.Parameters.Add(new OracleParameter("options", OracleDbType.Varchar2)).Value = options;
        label:
            trynow++;
            try
            {
                Conn.Open();
                //Trace.WriteLine("Table creation started ");
                OraCommand.ExecuteNonQuery();
                ReturnInfo = "t";
                //Trace.WriteLine("Table created");
                Conn.Close();
                Conn.Dispose();
            }
            catch (Exception ex)
            {
                //Trace.WriteLine(ex.Message);
                //Trace.WriteLine(ex.Source);
                //Trace.WriteLine(ex.HelpLink);
                Conn.Close();
                if (trynow < tryings)
                {
                    Thread.Sleep(sleeptime);
                    goto label;
                }
                else
                {
                    return ex.Message;
                }
            }
            return ReturnInfo;
        }
        public string ExecuteSQL(string sql, string c)
        {
            int trynow = 0;
            string ReturnInfo = "f";
            OracleConnection Conn = new OracleConnection(c);
            OracleCommand OraCommand = Conn.CreateCommand();
            OraCommand.CommandText = "EXECUTESQL";
            OraCommand.CommandType = CommandType.StoredProcedure;

            OracleParameter strSQL = new OracleParameter();
            strSQL.ParameterName = "strSQL";
            strSQL.OracleDbType = OracleDbType.Varchar2;
            strSQL.Direction = ParameterDirection.Input;
            strSQL.Value = sql;
            OraCommand.Parameters.Add(strSQL);
        label:
            trynow++;
            try
            {
                Conn.Open();
                OraCommand.ExecuteNonQuery();
                ReturnInfo = "t";
                Conn.Close();
                Conn.Dispose();
            }
            catch (Exception ex)
            {
                Conn.Close();
                if (trynow < tryings)
                {
                    Thread.Sleep(sleeptime);
                    goto label;
                }
                else
                {
                    ////// // ////// //Trace.WriteLine(ex.Message);
                    return ex.Message;
                }
            }
            return ReturnInfo;
        }
        public string LogActivities(ExcelServicesModels.LogActivitiesObject v, string c)
        {
            int trynow = 0;
            string ReturnInfo = "f";
            OracleConnection Conn = new OracleConnection(c);
            OracleCommand OraCommand = Conn.CreateCommand();
            OraCommand.CommandText = v.p();
            OraCommand.CommandType = CommandType.StoredProcedure;

            OracleParameter paramusername = new OracleParameter();
            paramusername.ParameterName = "username";
            paramusername.OracleDbType = OracleDbType.Varchar2;
            paramusername.Direction = ParameterDirection.Input;
            paramusername.Value = v.username;
            OraCommand.Parameters.Add(paramusername);

            OracleParameter paramapplicationname = new OracleParameter();
            paramapplicationname.ParameterName = "applicationname";
            paramapplicationname.OracleDbType = OracleDbType.Varchar2;
            paramapplicationname.Direction = ParameterDirection.Input;
            paramapplicationname.Value = v.applicationname;
            OraCommand.Parameters.Add(paramapplicationname);

            OracleParameter paramprocessname = new OracleParameter();
            paramprocessname.ParameterName = "processname";
            paramprocessname.OracleDbType = OracleDbType.Varchar2;
            paramprocessname.Direction = ParameterDirection.Input;
            paramprocessname.Value = v.processname;
            OraCommand.Parameters.Add(paramprocessname);

            OracleParameter paramsqlstring1 = new OracleParameter();
            paramsqlstring1.ParameterName = "sqlstring1";
            paramsqlstring1.OracleDbType = OracleDbType.Varchar2;
            paramsqlstring1.Direction = ParameterDirection.Input;
            paramsqlstring1.Value = v.sqlstring1;
            OraCommand.Parameters.Add(paramsqlstring1);

            OracleParameter paramsqlstring2 = new OracleParameter();
            paramsqlstring2.ParameterName = "sqlstring2";
            paramsqlstring2.OracleDbType = OracleDbType.Varchar2;
            paramsqlstring2.Direction = ParameterDirection.Input;
            paramsqlstring2.Value = v.sqlstring2;
            OraCommand.Parameters.Add(paramsqlstring2);

            OracleParameter paramsqlstring3 = new OracleParameter();
            paramsqlstring3.ParameterName = "sqlstring3";
            paramsqlstring3.OracleDbType = OracleDbType.Varchar2;
            paramsqlstring3.Direction = ParameterDirection.Input;
            paramsqlstring3.Value = v.sqlstring3;
            OraCommand.Parameters.Add(paramsqlstring3);

            OracleParameter paramsqlstring4 = new OracleParameter();
            paramsqlstring4.ParameterName = "sqlstring4";
            paramsqlstring4.OracleDbType = OracleDbType.Varchar2;
            paramsqlstring4.Direction = ParameterDirection.Input;
            paramsqlstring4.Value = v.sqlstring4;
            OraCommand.Parameters.Add(paramsqlstring4);

            OracleParameter paramsqlstring5 = new OracleParameter();
            paramsqlstring5.ParameterName = "sqlstring5";
            paramsqlstring5.OracleDbType = OracleDbType.Varchar2;
            paramsqlstring5.Direction = ParameterDirection.Input;
            paramsqlstring5.Value = v.sqlstring5;
            OraCommand.Parameters.Add(paramsqlstring5);

            OracleParameter paramtotalseconds = new OracleParameter();
            paramtotalseconds.ParameterName = "totalseconds";
            paramtotalseconds.OracleDbType = OracleDbType.Int32;
            paramtotalseconds.Direction = ParameterDirection.Input;
            paramtotalseconds.Value = v.totalseconds;
            OraCommand.Parameters.Add(paramtotalseconds);
        label:
            trynow++;
            try
            {
                Conn.Open();
                OraCommand.ExecuteNonQuery();
                Conn.Close();
                Conn.Dispose();
            }
            catch (Exception ex)
            {
                Conn.Close();
                if (trynow < tryings)
                {
                    Thread.Sleep(sleeptime);
                    goto label;
                }
                else
                {
                    return ex.Message;
                }
            }
            return ReturnInfo;
        }
    }
    public class PublicXMLProcedures
    {
        public string ExportDataTableToExcel(ref DataTable dt, string filepath, string sheetname, bool initilizesheet, bool headers, int rownumber, int columnnumber)
        {
            string r = "t";
            try
            {
                int rc = rownumber;
                int cc = columnnumber;
                if (initilizesheet == true)
                {
                    using (var wb = new XLWorkbook(filepath, XLEventTracking.Disabled))
                    {
                        IXLWorksheet ws = wb.Worksheets.Add(sheetname);
                        foreach (DataColumn col in dt.Columns)
                        {
                            if (headers)
                            {
                                //ws.Cell(rownumber - 1, cc).Value = col.ColumnName;
                                ws.Cell(rownumber - 1, cc).SetValue(col.ColumnName);
                            }
                            foreach (DataRow row in dt.Rows)
                            {
                                //ws.Cell(rc, cc).Value = row[col.ColumnName];
                                ws.Cell(rc, cc).SetValue(row[col.ColumnName]);
                                rc += 1;
                            }
                            rc = rownumber;
                            cc += 1;
                        }
                        wb.SaveAs(filepath, false);
                        wb.Dispose();
                    }
                }
                else
                {
                    var wb = new XLWorkbook();
                    bool e = false;
                    foreach (IXLWorksheet s in wb.Worksheets)
                    {
                        if (s.Name == sheetname)
                        {
                            e = true;
                            foreach (DataColumn col in dt.Columns)
                            {
                                if (headers)
                                {
                                    s.Cell(rownumber - 1, cc).Value = col.ColumnName;
                                    //s.Cell(rownumber - 1, cc).SetValue(col.ColumnName);
                                }
                                foreach (DataRow row in dt.Rows)
                                {
                                    //s.Cell(rc, cc).Value = row[col.ColumnName];
                                    s.Cell(rc, cc).SetValue(row[col.ColumnName]);
                                    rc += 1;
                                }
                                rc = rownumber;
                                cc += 1;
                            }
                            wb.SaveAs(filepath, false);
                            wb.Dispose();
                        }
                    }
                    if (e == false)
                    {
                        var wss = wb.Worksheets.Add(sheetname);
                        foreach (DataColumn col in dt.Columns)
                        {
                            if (headers)
                            {
                                wss.Cell(rownumber - 1, cc).Value = col.ColumnName;
                                //wss.Cell(rc, cc).SetValue(col.ColumnName);
                            }
                            foreach (DataRow row in dt.Rows)
                            {
                                //wss.Cell(rc, cc).Value = row[col.ColumnName];
                                wss.Cell(rc, cc).SetValue(row[col.ColumnName]);
                                rc += 1;
                                //r = r + row[col.ColumnName].ToString() + " | ";
                            }
                            rc = rownumber;
                            cc += 1;
                        }
                        wb.SaveAs(filepath, false);
                        wb.Dispose();
                    }
                    else
                    {
                        wb.SaveAs(filepath, false);
                        wb.Dispose();
                    }
                }
                return r;
            }
            catch (Exception ex)
            {
                //// Trace.WriteLine(ex.Message);
                return "f";
            }
        }
        public string ExcelFixWorkBook(string filepath, string sheetname, int RGB_R, int RGB_G, int RGB_B, string fn, int fs, int collnumbers)
        {
            try
            {
                if (File.Exists(filepath))
                {
                    //// StopProcess("EXCEL");
                    using (var wb = new XLWorkbook(filepath, XLEventTracking.Disabled))
                    {
                        IXLWorksheets ws = wb.Worksheets;
                        foreach (IXLWorksheet s in ws)
                        {
                            if (s.Name == sheetname)
                            {
                                s.TabColor = XLColor.FromArgb(RGB_R, RGB_G, RGB_B);
                                s.Style.Font.FontSize = fs;
                                s.Style.Font.FontName = fn;
                                var range = s.Range(1, 1, 1, collnumbers);
                                range.SetAutoFilter();
                                s.Columns().AdjustToContents();
                                s.Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
                                s.Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
                                s.SheetView.FreezeRows(1);
                                wb.SaveAs(filepath, false);
                                wb.Dispose();
                                break;
                            }
                        }
                    }
                }
                return "t";
            }
            catch
            {
                return "f";
            }
        }
    }
    public class SignalRSendData
    {

        public void sendInfoToClient(string connectionid, string channel, string eventname, string statusstate, int percentcomplete, List<string> filenames = null)
        {
            //MIG
            
            //log to form
            for (int i = 1; i <= 100; i++)
            {
                frmReport.form.M1(i.ToString());
                frmReport.form.M1("\n");
            }
            
            //********** log to text file ******************/
            //StringBuilder sb = new StringBuilder();
            //sb.AppendLine("log starts");
            //string filePath = ConfigurationManager.AppSettings["filePath"].ToString();
            //sb.AppendLine("Trinet");
            //sb.AppendLine("Reverse Enginnering");
            //sb.AppendLine("Documentation");

            //filePath = filePath + "log.txt";
            //if (File.Exists(filePath))
            //{
            //    File.Delete(filePath);
            //}
            //File.AppendAllText(filePath, sb.ToString());
            //sb.Clear();
        }
    }
    public class EncryptStrings
    {
        public class StringCipher
        {
            // This constant is used to determine the keysize of the encryption algorithm in bits.
            // We divide this by 8 within the code below to get the equivalent number of bytes.
            private const int Keysize = 256;

            // This constant determines the number of iterations for the password bytes generation function.
            private const int DerivationIterations = 1000;

            public string Encrypt(string plainText, string passPhrase)
            {
                // Salt and IV is randomly generated each time, but is preprended to encrypted cipher text
                // so that the same Salt and IV values can be used when decrypting.  
                var saltStringBytes = Generate256BitsOfRandomEntropy();
                var ivStringBytes = Generate256BitsOfRandomEntropy();
                var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
                using (var password = new Rfc2898DeriveBytes(passPhrase, saltStringBytes, DerivationIterations))
                {
                    var keyBytes = password.GetBytes(Keysize / 8);
                    using (var symmetricKey = new RijndaelManaged())
                    {
                        symmetricKey.BlockSize = 256;
                        symmetricKey.Mode = CipherMode.CBC;
                        symmetricKey.Padding = PaddingMode.PKCS7;
                        using (var encryptor = symmetricKey.CreateEncryptor(keyBytes, ivStringBytes))
                        {
                            using (var memoryStream = new MemoryStream())
                            {
                                using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                                {
                                    cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
                                    cryptoStream.FlushFinalBlock();
                                    // Create the final bytes as a concatenation of the random salt bytes, the random iv bytes and the cipher bytes.
                                    var cipherTextBytes = saltStringBytes;
                                    cipherTextBytes = cipherTextBytes.Concat(ivStringBytes).ToArray();
                                    cipherTextBytes = cipherTextBytes.Concat(memoryStream.ToArray()).ToArray();
                                    memoryStream.Close();
                                    cryptoStream.Close();
                                    return Convert.ToBase64String(cipherTextBytes);
                                }
                            }
                        }
                    }
                }
            }

            public string Decrypt(string cipherText, string passPhrase)
            {   // 
                string passPhrase2 = passPhrase.Trim();
                try
                {
                    // Get the complete stream of bytes that represent:
                    // [32 bytes of Salt] + [32 bytes of IV] + [n bytes of CipherText]
                    var cipherTextBytesWithSaltAndIv = Convert.FromBase64String(cipherText);
                    // Get the saltbytes by extracting the first 32 bytes from the supplied cipherText bytes.
                    var saltStringBytes = cipherTextBytesWithSaltAndIv.Take(Keysize / 8).ToArray();
                    // Get the IV bytes by extracting the next 32 bytes from the supplied cipherText bytes.
                    var ivStringBytes = cipherTextBytesWithSaltAndIv.Skip(Keysize / 8).Take(Keysize / 8).ToArray();
                    // Get the actual cipher text bytes by removing the first 64 bytes from the cipherText string.
                    var cipherTextBytes = cipherTextBytesWithSaltAndIv.Skip((Keysize / 8) * 2).Take(cipherTextBytesWithSaltAndIv.Length - ((Keysize / 8) * 2)).ToArray();

                    using (var password = new Rfc2898DeriveBytes(passPhrase2, saltStringBytes, DerivationIterations))
                    {
                        var keyBytes = password.GetBytes(Keysize / 8);
                        using (var symmetricKey = new RijndaelManaged())
                        {
                            symmetricKey.BlockSize = 256;
                            symmetricKey.Mode = CipherMode.CBC;
                            symmetricKey.Padding = PaddingMode.PKCS7;
                            using (var decryptor = symmetricKey.CreateDecryptor(keyBytes, ivStringBytes))
                            {
                                using (var memoryStream = new MemoryStream(cipherTextBytes))
                                {
                                    using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                                    {
                                        var plainTextBytes = new byte[cipherTextBytes.Length];
                                        var decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                                        memoryStream.Close();
                                        cryptoStream.Close();
                                        return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
                                    }
                                }
                            }
                        }
                    }
                }
                catch
                {
                    return cipherText;
                }
            }

            private byte[] Generate256BitsOfRandomEntropy()
            {
                var randomBytes = new byte[32]; // 32 Bytes will give us 256 bits.
                using (var rngCsp = new RNGCryptoServiceProvider())
                {
                    // Fill the array with cryptographically secure random bytes.
                    rngCsp.GetBytes(randomBytes);
                }
                return randomBytes;
            }
        }
    }

}